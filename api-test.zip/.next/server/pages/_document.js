(function() {
var exports = {};
exports.id = "pages/_document";
exports.ids = ["pages/_document"];
exports.modules = {

/***/ "./node_modules/@babel/runtime/helpers/extends.js":
/*!********************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/extends.js ***!
  \********************************************************/
/***/ (function(module) {

function _extends() {
  module.exports = _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/***/ (function(module) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js ***!
  \*****************************************************************************/
/***/ (function(module) {

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

module.exports = _objectWithoutPropertiesLoose;

/***/ }),

/***/ "./node_modules/next/dist/client/head-manager.js":
/*!*******************************************************!*\
  !*** ./node_modules/next/dist/client/head-manager.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";


exports.__esModule = true;
exports.default = initHeadManager;
exports.DOMAttributeNames = void 0;
const DOMAttributeNames = {
  acceptCharset: 'accept-charset',
  className: 'class',
  htmlFor: 'for',
  httpEquiv: 'http-equiv',
  noModule: 'noModule'
};
exports.DOMAttributeNames = DOMAttributeNames;

function reactElementToDOM({
  type,
  props
}) {
  const el = document.createElement(type);

  for (const p in props) {
    if (!props.hasOwnProperty(p)) continue;
    if (p === 'children' || p === 'dangerouslySetInnerHTML') continue; // we don't render undefined props to the DOM

    if (props[p] === undefined) continue;
    const attr = DOMAttributeNames[p] || p.toLowerCase();

    if (type === 'script' && (attr === 'async' || attr === 'defer' || attr === 'noModule')) {
      ;
      el[attr] = !!props[p];
    } else {
      el.setAttribute(attr, props[p]);
    }
  }

  const {
    children,
    dangerouslySetInnerHTML
  } = props;

  if (dangerouslySetInnerHTML) {
    el.innerHTML = dangerouslySetInnerHTML.__html || '';
  } else if (children) {
    el.textContent = typeof children === 'string' ? children : Array.isArray(children) ? children.join('') : '';
  }

  return el;
}

function updateElements(type, components) {
  const headEl = document.getElementsByTagName('head')[0];
  const headCountEl = headEl.querySelector('meta[name=next-head-count]');

  if (true) {
    if (!headCountEl) {
      console.error('Warning: next-head-count is missing. https://nextjs.org/docs/messages/next-head-count-missing');
      return;
    }
  }

  const headCount = Number(headCountEl.content);
  const oldTags = [];

  for (let i = 0, j = headCountEl.previousElementSibling; i < headCount; i++, j = j.previousElementSibling) {
    if (j.tagName.toLowerCase() === type) {
      oldTags.push(j);
    }
  }

  const newTags = components.map(reactElementToDOM).filter(newTag => {
    for (let k = 0, len = oldTags.length; k < len; k++) {
      const oldTag = oldTags[k];

      if (oldTag.isEqualNode(newTag)) {
        oldTags.splice(k, 1);
        return false;
      }
    }

    return true;
  });
  oldTags.forEach(t => t.parentNode.removeChild(t));
  newTags.forEach(t => headEl.insertBefore(t, headCountEl));
  headCountEl.content = (headCount - oldTags.length + newTags.length).toString();
}

function initHeadManager() {
  let updatePromise = null;
  return {
    mountedInstances: new Set(),
    updateHead: head => {
      const promise = updatePromise = Promise.resolve().then(() => {
        if (promise !== updatePromise) return;
        updatePromise = null;
        const tags = {};
        head.forEach(h => {
          if ( // If the font tag is loaded only on client navigation
          // it won't be inlined. In this case revert to the original behavior
          h.type === 'link' && h.props['data-optimized-fonts'] && !document.querySelector(`style[data-href="${h.props['data-href']}"]`)) {
            h.props.href = h.props['data-href'];
            h.props['data-href'] = undefined;
          }

          const components = tags[h.type] || [];
          components.push(h);
          tags[h.type] = components;
        });
        const titleComponent = tags.title ? tags.title[0] : null;
        let title = '';

        if (titleComponent) {
          const {
            children
          } = titleComponent.props;
          title = typeof children === 'string' ? children : Array.isArray(children) ? children.join('') : '';
        }

        if (title !== document.title) document.title = title;
        ['meta', 'base', 'link', 'style', 'script'].forEach(type => {
          updateElements(type, tags[type] || []);
        });
      });
    }
  };
}

/***/ }),

/***/ "./node_modules/next/dist/client/request-idle-callback.js":
/*!****************************************************************!*\
  !*** ./node_modules/next/dist/client/request-idle-callback.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";


exports.__esModule = true;
exports.cancelIdleCallback = exports.requestIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "./node_modules/next/dist/client/script.js":
/*!*************************************************!*\
  !*** ./node_modules/next/dist/client/script.js ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.initScriptLoader = initScriptLoader;
exports.default = void 0;

var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/extends.js"));

var _objectWithoutPropertiesLoose2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/objectWithoutPropertiesLoose */ "./node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js"));

var _react = __webpack_require__(/*! react */ "react");

var _headManagerContext = __webpack_require__(/*! ../next-server/lib/head-manager-context */ "../next-server/lib/head-manager-context");

var _headManager = __webpack_require__(/*! ./head-manager */ "./node_modules/next/dist/client/head-manager.js");

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

const ScriptCache = new Map();
const LoadCache = new Set();
const ignoreProps = ['onLoad', 'dangerouslySetInnerHTML', 'children', 'onError', 'strategy'];

const loadScript = props => {
  const {
    src,
    id,
    onLoad = () => {},
    dangerouslySetInnerHTML,
    children = '',
    onError
  } = props;
  const cacheKey = id || src;

  if (ScriptCache.has(src)) {
    if (!LoadCache.has(cacheKey)) {
      LoadCache.add(cacheKey); // Execute onLoad since the script loading has begun

      ScriptCache.get(src).then(onLoad, onError);
    }

    return;
  }

  const el = document.createElement('script');
  const loadPromise = new Promise((resolve, reject) => {
    el.addEventListener('load', function () {
      resolve();

      if (onLoad) {
        onLoad.call(this);
      }
    });
    el.addEventListener('error', function () {
      reject();

      if (onError) {
        onError();
      }
    });
  });

  if (src) {
    ScriptCache.set(src, loadPromise);
    LoadCache.add(cacheKey);
  }

  if (dangerouslySetInnerHTML) {
    el.innerHTML = dangerouslySetInnerHTML.__html || '';
  } else if (children) {
    el.textContent = typeof children === 'string' ? children : Array.isArray(children) ? children.join('') : '';
  } else if (src) {
    el.src = src;
  }

  for (const [k, value] of Object.entries(props)) {
    if (value === undefined || ignoreProps.includes(k)) {
      continue;
    }

    const attr = _headManager.DOMAttributeNames[k] || k.toLowerCase();
    el.setAttribute(attr, value);
  }

  document.body.appendChild(el);
};

function handleClientScriptLoad(props) {
  const {
    strategy = 'afterInteractive'
  } = props;

  if (strategy === 'afterInteractive') {
    loadScript(props);
  } else if (strategy === 'lazyOnload') {
    window.addEventListener('load', () => {
      (0, _requestIdleCallback.requestIdleCallback)(() => loadScript(props));
    });
  }
}

function loadLazyScript(props) {
  if (document.readyState === 'complete') {
    (0, _requestIdleCallback.requestIdleCallback)(() => loadScript(props));
  } else {
    window.addEventListener('load', () => {
      (0, _requestIdleCallback.requestIdleCallback)(() => loadScript(props));
    });
  }
}

function initScriptLoader(scriptLoaderItems) {
  scriptLoaderItems.forEach(handleClientScriptLoad);
}

function Script(props) {
  const {
    src = '',
    onLoad = () => {},
    strategy = 'afterInteractive',
    onError
  } = props,
        restProps = (0, _objectWithoutPropertiesLoose2.default)(props, ["src", "onLoad", "dangerouslySetInnerHTML", "strategy", "onError"]); // Context is available only during SSR

  const {
    updateScripts,
    scripts
  } = (0, _react.useContext)(_headManagerContext.HeadManagerContext);
  (0, _react.useEffect)(() => {
    if (strategy === 'afterInteractive') {
      loadScript(props);
    } else if (strategy === 'lazyOnload') {
      loadLazyScript(props);
    }
  }, [props, strategy]);

  if (strategy === 'beforeInteractive') {
    if (updateScripts) {
      scripts.beforeInteractive = (scripts.beforeInteractive || []).concat([(0, _extends2.default)({
        src,
        onLoad,
        onError
      }, restProps)]);
      updateScripts(scripts);
    }
  }

  return null;
}

var _default = Script;
exports.default = _default;

/***/ }),

/***/ "./node_modules/next/dist/pages/_document.js":
/*!***************************************************!*\
  !*** ./node_modules/next/dist/pages/_document.js ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

exports.__esModule = true;
exports.Html = Html;
exports.Main = Main;
exports.NextScript = exports.Head = exports.default = void 0;

var _propTypes = _interopRequireDefault(__webpack_require__(/*! prop-types */ "prop-types"));

var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));

var _server = _interopRequireDefault(__webpack_require__(/*! styled-jsx/server */ "styled-jsx/server"));

var _constants = __webpack_require__(/*! ../next-server/lib/constants */ "../next-server/lib/constants");

var _documentContext = __webpack_require__(/*! ../next-server/lib/document-context */ "../next-server/lib/document-context");

var _utils = __webpack_require__(/*! ../next-server/lib/utils */ "../next-server/lib/utils");

exports.DocumentContext = _utils.DocumentContext;
exports.DocumentInitialProps = _utils.DocumentInitialProps;
exports.DocumentProps = _utils.DocumentProps;

var _getPageFiles = __webpack_require__(/*! ../next-server/server/get-page-files */ "../next-server/server/get-page-files");

var _utils2 = __webpack_require__(/*! ../next-server/server/utils */ "../next-server/server/utils");

var _htmlescape = __webpack_require__(/*! ../server/htmlescape */ "./node_modules/next/dist/server/htmlescape.js");

var _script = _interopRequireDefault(__webpack_require__(/*! ../client/script */ "./node_modules/next/dist/client/script.js"));

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

function getDocumentFiles(buildManifest, pathname, inAmpMode) {
  const sharedFiles = (0, _getPageFiles.getPageFiles)(buildManifest, '/_app');
  const pageFiles = inAmpMode ? [] : (0, _getPageFiles.getPageFiles)(buildManifest, pathname);
  return {
    sharedFiles,
    pageFiles,
    allFiles: [...new Set([...sharedFiles, ...pageFiles])]
  };
}

function getPolyfillScripts(context, props) {
  // polyfills.js has to be rendered as nomodule without async
  // It also has to be the first script to load
  const {
    assetPrefix,
    buildManifest,
    devOnlyCacheBusterQueryString,
    disableOptimizedLoading
  } = context;
  return buildManifest.polyfillFiles.filter(polyfill => polyfill.endsWith('.js') && !polyfill.endsWith('.module.js')).map(polyfill => /*#__PURE__*/_react.default.createElement("script", {
    key: polyfill,
    defer: !disableOptimizedLoading,
    nonce: props.nonce,
    crossOrigin: props.crossOrigin || undefined,
    noModule: true,
    src: `${assetPrefix}/_next/${polyfill}${devOnlyCacheBusterQueryString}`
  }));
}

function getPreNextScripts(context, props) {
  const {
    scriptLoader,
    disableOptimizedLoading
  } = context;
  return (scriptLoader.beforeInteractive || []).map(file => {
    const {
      strategy
    } = file,
          scriptProps = _objectWithoutProperties(file, ["strategy"]);

    return /*#__PURE__*/_react.default.createElement("script", Object.assign({}, scriptProps, {
      defer: !disableOptimizedLoading,
      nonce: props.nonce,
      crossOrigin: props.crossOrigin || undefined
    }));
  });
}

function getDynamicChunks(context, props, files) {
  const {
    dynamicImports,
    assetPrefix,
    isDevelopment,
    devOnlyCacheBusterQueryString,
    disableOptimizedLoading
  } = context;
  return dynamicImports.map(file => {
    if (!file.endsWith('.js') || files.allFiles.includes(file)) return null;
    return /*#__PURE__*/_react.default.createElement("script", {
      async: !isDevelopment && disableOptimizedLoading,
      defer: !disableOptimizedLoading,
      key: file,
      src: `${assetPrefix}/_next/${encodeURI(file)}${devOnlyCacheBusterQueryString}`,
      nonce: props.nonce,
      crossOrigin: props.crossOrigin || undefined
    });
  });
}

function getScripts(context, props, files) {
  var _buildManifest$lowPri;

  const {
    assetPrefix,
    buildManifest,
    isDevelopment,
    devOnlyCacheBusterQueryString,
    disableOptimizedLoading
  } = context;
  const normalScripts = files.allFiles.filter(file => file.endsWith('.js'));
  const lowPriorityScripts = (_buildManifest$lowPri = buildManifest.lowPriorityFiles) == null ? void 0 : _buildManifest$lowPri.filter(file => file.endsWith('.js'));
  return [...normalScripts, ...lowPriorityScripts].map(file => {
    return /*#__PURE__*/_react.default.createElement("script", {
      key: file,
      src: `${assetPrefix}/_next/${encodeURI(file)}${devOnlyCacheBusterQueryString}`,
      nonce: props.nonce,
      async: !isDevelopment && disableOptimizedLoading,
      defer: !disableOptimizedLoading,
      crossOrigin: props.crossOrigin || undefined
    });
  });
}
/**
* `Document` component handles the initial `document` markup and renders only on the server side.
* Commonly used for implementing server side rendering for `css-in-js` libraries.
*/


class Document extends _react.Component {
  /**
  * `getInitialProps` hook returns the context object with the addition of `renderPage`.
  * `renderPage` callback executes `React` rendering logic synchronously to support server-rendering wrappers
  */
  static async getInitialProps(ctx) {
    const enhanceApp = App => {
      return props => /*#__PURE__*/_react.default.createElement(App, props);
    };

    const {
      html,
      head
    } = await ctx.renderPage({
      enhanceApp
    });
    const styles = [...(0, _server.default)()];
    return {
      html,
      head,
      styles
    };
  }

  static renderDocument(DocumentComponent, props) {
    return /*#__PURE__*/_react.default.createElement(_documentContext.DocumentContext.Provider, {
      value: props
    }, /*#__PURE__*/_react.default.createElement(DocumentComponent, props));
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(Html, null, /*#__PURE__*/_react.default.createElement(Head, null), /*#__PURE__*/_react.default.createElement("body", null, /*#__PURE__*/_react.default.createElement(Main, null), /*#__PURE__*/_react.default.createElement(NextScript, null)));
  }

}

exports.default = Document;

function Html(props) {
  const {
    inAmpMode,
    docComponentsRendered,
    locale
  } = (0, _react.useContext)(_documentContext.DocumentContext);
  docComponentsRendered.Html = true;
  return /*#__PURE__*/_react.default.createElement("html", Object.assign({}, props, {
    lang: props.lang || locale || undefined,
    amp: inAmpMode ? '' : undefined,
    "data-ampdevmode": inAmpMode && true ? '' : undefined
  }));
}

class Head extends _react.Component {
  constructor(...args) {
    super(...args);
    this.context = void 0;
  }

  getCssLinks(files) {
    const {
      assetPrefix,
      devOnlyCacheBusterQueryString,
      dynamicImports
    } = this.context;
    const cssFiles = files.allFiles.filter(f => f.endsWith('.css'));
    const sharedFiles = new Set(files.sharedFiles); // Unmanaged files are CSS files that will be handled directly by the
    // webpack runtime (`mini-css-extract-plugin`).

    let unmangedFiles = new Set([]);
    let dynamicCssFiles = Array.from(new Set(dynamicImports.filter(file => file.endsWith('.css'))));

    if (dynamicCssFiles.length) {
      const existing = new Set(cssFiles);
      dynamicCssFiles = dynamicCssFiles.filter(f => !(existing.has(f) || sharedFiles.has(f)));
      unmangedFiles = new Set(dynamicCssFiles);
      cssFiles.push(...dynamicCssFiles);
    }

    let cssLinkElements = [];
    cssFiles.forEach(file => {
      const isSharedFile = sharedFiles.has(file);

      if (true) {
        cssLinkElements.push( /*#__PURE__*/_react.default.createElement("link", {
          key: `${file}-preload`,
          nonce: this.props.nonce,
          rel: "preload",
          href: `${assetPrefix}/_next/${encodeURI(file)}${devOnlyCacheBusterQueryString}`,
          as: "style",
          crossOrigin: this.props.crossOrigin || undefined
        }));
      }

      const isUnmanagedFile = unmangedFiles.has(file);
      cssLinkElements.push( /*#__PURE__*/_react.default.createElement("link", {
        key: file,
        nonce: this.props.nonce,
        rel: "stylesheet",
        href: `${assetPrefix}/_next/${encodeURI(file)}${devOnlyCacheBusterQueryString}`,
        crossOrigin: this.props.crossOrigin || undefined,
        "data-n-g": isUnmanagedFile ? undefined : isSharedFile ? '' : undefined,
        "data-n-p": isUnmanagedFile ? undefined : isSharedFile ? undefined : ''
      }));
    });

    if (false) {}

    return cssLinkElements.length === 0 ? null : cssLinkElements;
  }

  getPreloadDynamicChunks() {
    const {
      dynamicImports,
      assetPrefix,
      devOnlyCacheBusterQueryString
    } = this.context;
    return dynamicImports.map(file => {
      if (!file.endsWith('.js')) {
        return null;
      }

      return /*#__PURE__*/_react.default.createElement("link", {
        rel: "preload",
        key: file,
        href: `${assetPrefix}/_next/${encodeURI(file)}${devOnlyCacheBusterQueryString}`,
        as: "script",
        nonce: this.props.nonce,
        crossOrigin: this.props.crossOrigin || undefined
      });
    }) // Filter out nulled scripts
    .filter(Boolean);
  }

  getPreloadMainLinks(files) {
    const {
      assetPrefix,
      devOnlyCacheBusterQueryString,
      scriptLoader
    } = this.context;
    const preloadFiles = files.allFiles.filter(file => {
      return file.endsWith('.js');
    });
    return [...(scriptLoader.beforeInteractive || []).map(file => /*#__PURE__*/_react.default.createElement("link", {
      key: file.src,
      nonce: this.props.nonce,
      rel: "preload",
      href: file.src,
      as: "script",
      crossOrigin: this.props.crossOrigin || undefined
    })), ...preloadFiles.map(file => /*#__PURE__*/_react.default.createElement("link", {
      key: file,
      nonce: this.props.nonce,
      rel: "preload",
      href: `${assetPrefix}/_next/${encodeURI(file)}${devOnlyCacheBusterQueryString}`,
      as: "script",
      crossOrigin: this.props.crossOrigin || undefined
    }))];
  }

  getDynamicChunks(files) {
    return getDynamicChunks(this.context, this.props, files);
  }

  getPreNextScripts() {
    return getPreNextScripts(this.context, this.props);
  }

  getScripts(files) {
    return getScripts(this.context, this.props, files);
  }

  getPolyfillScripts() {
    return getPolyfillScripts(this.context, this.props);
  }

  handleDocumentScriptLoaderItems(children) {
    const {
      scriptLoader
    } = this.context;
    const scriptLoaderItems = [];
    const filteredChildren = [];

    _react.default.Children.forEach(children, child => {
      if (child.type === _script.default) {
        if (child.props.strategy === 'beforeInteractive') {
          scriptLoader.beforeInteractive = (scriptLoader.beforeInteractive || []).concat([_objectSpread({}, child.props)]);
          return;
        } else if (['lazyOnload', 'afterInteractive'].includes(child.props.strategy)) {
          scriptLoaderItems.push(child.props);
          return;
        }
      }

      filteredChildren.push(child);
    });

    this.context.__NEXT_DATA__.scriptLoader = scriptLoaderItems;
    return filteredChildren;
  }

  makeStylesheetInert(node) {
    return _react.default.Children.map(node, c => {
      if (c.type === 'link' && c.props['href'] && _constants.OPTIMIZED_FONT_PROVIDERS.some(({
        url
      }) => c.props['href'].startsWith(url))) {
        const newProps = _objectSpread({}, c.props || {});

        newProps['data-href'] = newProps['href'];
        newProps['href'] = undefined;
        return /*#__PURE__*/_react.default.cloneElement(c, newProps);
      } else if (c.props && c.props['children']) {
        c.props['children'] = this.makeStylesheetInert(c.props['children']);
      }

      return c;
    });
  }

  render() {
    var _this$props$nonce, _this$props$nonce2;

    const {
      styles,
      ampPath,
      inAmpMode,
      hybridAmp,
      canonicalBase,
      __NEXT_DATA__,
      dangerousAsPath,
      headTags,
      unstable_runtimeJS,
      unstable_JsPreload,
      disableOptimizedLoading
    } = this.context;
    const disableRuntimeJS = unstable_runtimeJS === false;
    const disableJsPreload = unstable_JsPreload === false || !disableOptimizedLoading;
    this.context.docComponentsRendered.Head = true;
    let {
      head
    } = this.context;
    let cssPreloads = [];
    let otherHeadElements = [];

    if (head) {
      head.forEach(c => {
        if (c && c.type === 'link' && c.props['rel'] === 'preload' && c.props['as'] === 'style') {
          cssPreloads.push(c);
        } else {
          c && otherHeadElements.push(c);
        }
      });
      head = cssPreloads.concat(otherHeadElements);
    }

    let children = _react.default.Children.toArray(this.props.children).filter(Boolean); // show a warning if Head contains <title> (only in development)


    if (true) {
      children = _react.default.Children.map(children, child => {
        var _child$props;

        const isReactHelmet = child == null ? void 0 : (_child$props = child.props) == null ? void 0 : _child$props['data-react-helmet'];

        if (!isReactHelmet) {
          var _child$props2;

          if ((child == null ? void 0 : child.type) === 'title') {
            console.warn("Warning: <title> should not be used in _document.js's <Head>. https://nextjs.org/docs/messages/no-document-title");
          } else if ((child == null ? void 0 : child.type) === 'meta' && (child == null ? void 0 : (_child$props2 = child.props) == null ? void 0 : _child$props2.name) === 'viewport') {
            console.warn("Warning: viewport meta tags should not be used in _document.js's <Head>. https://nextjs.org/docs/messages/no-document-viewport-meta");
          }
        }

        return child;
      });
      if (this.props.crossOrigin) console.warn('Warning: `Head` attribute `crossOrigin` is deprecated. https://nextjs.org/docs/messages/doc-crossorigin-deprecated');
    }

    if (false) {}

    children = this.handleDocumentScriptLoaderItems(children);
    let hasAmphtmlRel = false;
    let hasCanonicalRel = false; // show warning and remove conflicting amp head tags

    head = _react.default.Children.map(head || [], child => {
      if (!child) return child;
      const {
        type,
        props
      } = child;

      if (inAmpMode) {
        let badProp = '';

        if (type === 'meta' && props.name === 'viewport') {
          badProp = 'name="viewport"';
        } else if (type === 'link' && props.rel === 'canonical') {
          hasCanonicalRel = true;
        } else if (type === 'script') {
          // only block if
          // 1. it has a src and isn't pointing to ampproject's CDN
          // 2. it is using dangerouslySetInnerHTML without a type or
          // a type of text/javascript
          if (props.src && props.src.indexOf('ampproject') < -1 || props.dangerouslySetInnerHTML && (!props.type || props.type === 'text/javascript')) {
            badProp = '<script';
            Object.keys(props).forEach(prop => {
              badProp += ` ${prop}="${props[prop]}"`;
            });
            badProp += '/>';
          }
        }

        if (badProp) {
          console.warn(`Found conflicting amp tag "${child.type}" with conflicting prop ${badProp} in ${__NEXT_DATA__.page}. https://nextjs.org/docs/messages/conflicting-amp-tag`);
          return null;
        }
      } else {
        // non-amp mode
        if (type === 'link' && props.rel === 'amphtml') {
          hasAmphtmlRel = true;
        }
      }

      return child;
    }); // try to parse styles from fragment for backwards compat

    const curStyles = Array.isArray(styles) ? styles : [];

    if (inAmpMode && styles && // @ts-ignore Property 'props' does not exist on type ReactElement
    styles.props && // @ts-ignore Property 'props' does not exist on type ReactElement
    Array.isArray(styles.props.children)) {
      const hasStyles = el => {
        var _el$props, _el$props$dangerously;

        return el == null ? void 0 : (_el$props = el.props) == null ? void 0 : (_el$props$dangerously = _el$props.dangerouslySetInnerHTML) == null ? void 0 : _el$props$dangerously.__html;
      }; // @ts-ignore Property 'props' does not exist on type ReactElement


      styles.props.children.forEach(child => {
        if (Array.isArray(child)) {
          child.forEach(el => hasStyles(el) && curStyles.push(el));
        } else if (hasStyles(child)) {
          curStyles.push(child);
        }
      });
    }

    const files = getDocumentFiles(this.context.buildManifest, this.context.__NEXT_DATA__.page, inAmpMode);
    return /*#__PURE__*/_react.default.createElement("head", this.props, this.context.isDevelopment && /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("style", {
      "data-next-hide-fouc": true,
      "data-ampdevmode": inAmpMode ? 'true' : undefined,
      dangerouslySetInnerHTML: {
        __html: `body{display:none}`
      }
    }), /*#__PURE__*/_react.default.createElement("noscript", {
      "data-next-hide-fouc": true,
      "data-ampdevmode": inAmpMode ? 'true' : undefined
    }, /*#__PURE__*/_react.default.createElement("style", {
      dangerouslySetInnerHTML: {
        __html: `body{display:block}`
      }
    }))), children,  false && /*#__PURE__*/0, head, /*#__PURE__*/_react.default.createElement("meta", {
      name: "next-head-count",
      content: _react.default.Children.count(head || []).toString()
    }), inAmpMode && /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("meta", {
      name: "viewport",
      content: "width=device-width,minimum-scale=1,initial-scale=1"
    }), !hasCanonicalRel && /*#__PURE__*/_react.default.createElement("link", {
      rel: "canonical",
      href: canonicalBase + (0, _utils2.cleanAmpPath)(dangerousAsPath)
    }), /*#__PURE__*/_react.default.createElement("link", {
      rel: "preload",
      as: "script",
      href: "https://cdn.ampproject.org/v0.js"
    }), styles && /*#__PURE__*/_react.default.createElement("style", {
      "amp-custom": "",
      dangerouslySetInnerHTML: {
        __html: curStyles.map(style => style.props.dangerouslySetInnerHTML.__html).join('').replace(/\/\*# sourceMappingURL=.*\*\//g, '').replace(/\/\*@ sourceURL=.*?\*\//g, '')
      }
    }), /*#__PURE__*/_react.default.createElement("style", {
      "amp-boilerplate": "",
      dangerouslySetInnerHTML: {
        __html: `body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}`
      }
    }), /*#__PURE__*/_react.default.createElement("noscript", null, /*#__PURE__*/_react.default.createElement("style", {
      "amp-boilerplate": "",
      dangerouslySetInnerHTML: {
        __html: `body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}`
      }
    })), /*#__PURE__*/_react.default.createElement("script", {
      async: true,
      src: "https://cdn.ampproject.org/v0.js"
    })), !inAmpMode && /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, !hasAmphtmlRel && hybridAmp && /*#__PURE__*/_react.default.createElement("link", {
      rel: "amphtml",
      href: canonicalBase + getAmpPath(ampPath, dangerousAsPath)
    }),  true && this.getCssLinks(files),  true && /*#__PURE__*/_react.default.createElement("noscript", {
      "data-n-css": (_this$props$nonce = this.props.nonce) != null ? _this$props$nonce : ''
    }),  false && /*#__PURE__*/0, !disableRuntimeJS && !disableJsPreload && this.getPreloadDynamicChunks(), !disableRuntimeJS && !disableJsPreload && this.getPreloadMainLinks(files), !disableOptimizedLoading && !disableRuntimeJS && this.getPolyfillScripts(), !disableOptimizedLoading && !disableRuntimeJS && this.getPreNextScripts(), !disableOptimizedLoading && !disableRuntimeJS && this.getDynamicChunks(files), !disableOptimizedLoading && !disableRuntimeJS && this.getScripts(files),  false && 0,  false && /*#__PURE__*/0, this.context.isDevelopment &&
    /*#__PURE__*/
    // this element is used to mount development styles so the
    // ordering matches production
    // (by default, style-loader injects at the bottom of <head />)
    _react.default.createElement("noscript", {
      id: "__next_css__DO_NOT_USE__"
    }), styles || null), /*#__PURE__*/_react.default.createElement(_react.default.Fragment, {}, ...(headTags || [])));
  }

}

exports.Head = Head;
Head.contextType = _documentContext.DocumentContext;
Head.propTypes = {
  nonce: _propTypes.default.string,
  crossOrigin: _propTypes.default.string
};

function Main() {
  const {
    inAmpMode,
    html,
    docComponentsRendered
  } = (0, _react.useContext)(_documentContext.DocumentContext);
  docComponentsRendered.Main = true;
  if (inAmpMode) return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, _constants.AMP_RENDER_TARGET);
  return /*#__PURE__*/_react.default.createElement("div", {
    id: "__next",
    dangerouslySetInnerHTML: {
      __html: html
    }
  });
}

class NextScript extends _react.Component {
  constructor(...args) {
    super(...args);
    this.context = void 0;
  }

  getDynamicChunks(files) {
    return getDynamicChunks(this.context, this.props, files);
  }

  getPreNextScripts() {
    return getPreNextScripts(this.context, this.props);
  }

  getScripts(files) {
    return getScripts(this.context, this.props, files);
  }

  getPolyfillScripts() {
    return getPolyfillScripts(this.context, this.props);
  }

  static getInlineScriptSource(documentProps) {
    const {
      __NEXT_DATA__
    } = documentProps;

    try {
      const data = JSON.stringify(__NEXT_DATA__);
      return (0, _htmlescape.htmlEscapeJsonString)(data);
    } catch (err) {
      if (err.message.indexOf('circular structure')) {
        throw new Error(`Circular structure in "getInitialProps" result of page "${__NEXT_DATA__.page}". https://nextjs.org/docs/messages/circular-structure`);
      }

      throw err;
    }
  }

  render() {
    const {
      assetPrefix,
      inAmpMode,
      buildManifest,
      unstable_runtimeJS,
      docComponentsRendered,
      devOnlyCacheBusterQueryString,
      disableOptimizedLoading
    } = this.context;
    const disableRuntimeJS = unstable_runtimeJS === false;
    docComponentsRendered.NextScript = true;

    if (inAmpMode) {
      if (false) {}

      const ampDevFiles = [...buildManifest.devFiles, ...buildManifest.polyfillFiles, ...buildManifest.ampDevFiles];
      return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, disableRuntimeJS ? null : /*#__PURE__*/_react.default.createElement("script", {
        id: "__NEXT_DATA__",
        type: "application/json",
        nonce: this.props.nonce,
        crossOrigin: this.props.crossOrigin || undefined,
        dangerouslySetInnerHTML: {
          __html: NextScript.getInlineScriptSource(this.context)
        },
        "data-ampdevmode": true
      }), ampDevFiles.map(file => /*#__PURE__*/_react.default.createElement("script", {
        key: file,
        src: `${assetPrefix}/_next/${file}${devOnlyCacheBusterQueryString}`,
        nonce: this.props.nonce,
        crossOrigin: this.props.crossOrigin || undefined,
        "data-ampdevmode": true
      })));
    }

    if (true) {
      if (this.props.crossOrigin) console.warn('Warning: `NextScript` attribute `crossOrigin` is deprecated. https://nextjs.org/docs/messages/doc-crossorigin-deprecated');
    }

    const files = getDocumentFiles(this.context.buildManifest, this.context.__NEXT_DATA__.page, inAmpMode);
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, !disableRuntimeJS && buildManifest.devFiles ? buildManifest.devFiles.map(file => /*#__PURE__*/_react.default.createElement("script", {
      key: file,
      src: `${assetPrefix}/_next/${encodeURI(file)}${devOnlyCacheBusterQueryString}`,
      nonce: this.props.nonce,
      crossOrigin: this.props.crossOrigin || undefined
    })) : null, disableRuntimeJS ? null : /*#__PURE__*/_react.default.createElement("script", {
      id: "__NEXT_DATA__",
      type: "application/json",
      nonce: this.props.nonce,
      crossOrigin: this.props.crossOrigin || undefined,
      dangerouslySetInnerHTML: {
        __html: NextScript.getInlineScriptSource(this.context)
      }
    }), disableOptimizedLoading && !disableRuntimeJS && this.getPolyfillScripts(), disableOptimizedLoading && !disableRuntimeJS && this.getPreNextScripts(), disableOptimizedLoading && !disableRuntimeJS && this.getDynamicChunks(files), disableOptimizedLoading && !disableRuntimeJS && this.getScripts(files));
  }

}

exports.NextScript = NextScript;
NextScript.contextType = _documentContext.DocumentContext;
NextScript.propTypes = {
  nonce: _propTypes.default.string,
  crossOrigin: _propTypes.default.string
};
NextScript.safariNomoduleFix = '!function(){var e=document,t=e.createElement("script");if(!("noModule"in t)&&"onbeforeload"in t){var n=!1;e.addEventListener("beforeload",function(e){if(e.target===t)n=!0;else if(!e.target.hasAttribute("nomodule")||!n)return;e.preventDefault()},!0),t.type="module",t.src=".",e.head.appendChild(t),t.remove()}}();';

function getAmpPath(ampPath, asPath) {
  return ampPath || `${asPath}${asPath.includes('?') ? '&' : '?'}amp=1`;
}

/***/ }),

/***/ "./node_modules/next/dist/server/htmlescape.js":
/*!*****************************************************!*\
  !*** ./node_modules/next/dist/server/htmlescape.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";
exports.__esModule=true;exports.htmlEscapeJsonString=htmlEscapeJsonString;// This utility is based on https://github.com/zertosh/htmlescape
// License: https://github.com/zertosh/htmlescape/blob/0527ca7156a524d256101bb310a9f970f63078ad/LICENSE
const ESCAPE_LOOKUP={'&':'\\u0026','>':'\\u003e','<':'\\u003c','\u2028':'\\u2028','\u2029':'\\u2029'};const ESCAPE_REGEX=/[&><\u2028\u2029]/g;function htmlEscapeJsonString(str){return str.replace(ESCAPE_REGEX,match=>ESCAPE_LOOKUP[match]);}
//# sourceMappingURL=htmlescape.js.map

/***/ }),

/***/ "../next-server/lib/constants":
/*!*********************************************************!*\
  !*** external "next/dist/next-server/lib/constants.js" ***!
  \*********************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/constants.js");;

/***/ }),

/***/ "../next-server/lib/document-context":
/*!****************************************************************!*\
  !*** external "next/dist/next-server/lib/document-context.js" ***!
  \****************************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/document-context.js");;

/***/ }),

/***/ "../next-server/lib/head-manager-context":
/*!********************************************************************!*\
  !*** external "next/dist/next-server/lib/head-manager-context.js" ***!
  \********************************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/head-manager-context.js");;

/***/ }),

/***/ "../next-server/lib/utils":
/*!*****************************************************!*\
  !*** external "next/dist/next-server/lib/utils.js" ***!
  \*****************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/utils.js");;

/***/ }),

/***/ "../next-server/server/get-page-files":
/*!*****************************************************************!*\
  !*** external "next/dist/next-server/server/get-page-files.js" ***!
  \*****************************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/server/get-page-files.js");;

/***/ }),

/***/ "../next-server/server/utils":
/*!********************************************************!*\
  !*** external "next/dist/next-server/server/utils.js" ***!
  \********************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/server/utils.js");;

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ (function(module) {

"use strict";
module.exports = require("prop-types");;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ "styled-jsx/server":
/*!************************************!*\
  !*** external "styled-jsx/server" ***!
  \************************************/
/***/ (function(module) {

"use strict";
module.exports = require("styled-jsx/server");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./node_modules/next/dist/pages/_document.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hcGktdGVzdC8uL25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2V4dGVuZHMuanMiLCJ3ZWJwYWNrOi8vYXBpLXRlc3QvLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHQuanMiLCJ3ZWJwYWNrOi8vYXBpLXRlc3QvLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlLmpzIiwid2VicGFjazovL2FwaS10ZXN0Ly4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvaGVhZC1tYW5hZ2VyLmpzIiwid2VicGFjazovL2FwaS10ZXN0Ly4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvcmVxdWVzdC1pZGxlLWNhbGxiYWNrLmpzIiwid2VicGFjazovL2FwaS10ZXN0Ly4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvc2NyaXB0LmpzIiwid2VicGFjazovL2FwaS10ZXN0Ly4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9wYWdlcy9fZG9jdW1lbnQuanMiLCJ3ZWJwYWNrOi8vYXBpLXRlc3QvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L3NlcnZlci9odG1sZXNjYXBlLmpzIiwid2VicGFjazovL2FwaS10ZXN0L2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9jb25zdGFudHMuanNcIiIsIndlYnBhY2s6Ly9hcGktdGVzdC9leHRlcm5hbCBcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvZG9jdW1lbnQtY29udGV4dC5qc1wiIiwid2VicGFjazovL2FwaS10ZXN0L2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9oZWFkLW1hbmFnZXItY29udGV4dC5qc1wiIiwid2VicGFjazovL2FwaS10ZXN0L2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi91dGlscy5qc1wiIiwid2VicGFjazovL2FwaS10ZXN0L2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci9nZXQtcGFnZS1maWxlcy5qc1wiIiwid2VicGFjazovL2FwaS10ZXN0L2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci91dGlscy5qc1wiIiwid2VicGFjazovL2FwaS10ZXN0L2V4dGVybmFsIFwicHJvcC10eXBlc1wiIiwid2VicGFjazovL2FwaS10ZXN0L2V4dGVybmFsIFwicmVhY3RcIiIsIndlYnBhY2s6Ly9hcGktdGVzdC9leHRlcm5hbCBcInN0eWxlZC1qc3gvc2VydmVyXCIiXSwibmFtZXMiOlsiZXhwb3J0cyIsImluaXRIZWFkTWFuYWdlciIsIkRPTUF0dHJpYnV0ZU5hbWVzIiwiYWNjZXB0Q2hhcnNldCIsImNsYXNzTmFtZSIsImh0bWxGb3IiLCJodHRwRXF1aXYiLCJub01vZHVsZSIsInJlYWN0RWxlbWVudFRvRE9NIiwidHlwZSIsInByb3BzIiwiZWwiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJwIiwiaGFzT3duUHJvcGVydHkiLCJ1bmRlZmluZWQiLCJhdHRyIiwidG9Mb3dlckNhc2UiLCJzZXRBdHRyaWJ1dGUiLCJjaGlsZHJlbiIsImRhbmdlcm91c2x5U2V0SW5uZXJIVE1MIiwiaW5uZXJIVE1MIiwiX19odG1sIiwidGV4dENvbnRlbnQiLCJBcnJheSIsImlzQXJyYXkiLCJqb2luIiwidXBkYXRlRWxlbWVudHMiLCJjb21wb25lbnRzIiwiaGVhZEVsIiwiZ2V0RWxlbWVudHNCeVRhZ05hbWUiLCJoZWFkQ291bnRFbCIsInF1ZXJ5U2VsZWN0b3IiLCJjb25zb2xlIiwiZXJyb3IiLCJoZWFkQ291bnQiLCJOdW1iZXIiLCJjb250ZW50Iiwib2xkVGFncyIsImkiLCJqIiwicHJldmlvdXNFbGVtZW50U2libGluZyIsInRhZ05hbWUiLCJwdXNoIiwibmV3VGFncyIsIm1hcCIsImZpbHRlciIsIm5ld1RhZyIsImsiLCJsZW4iLCJsZW5ndGgiLCJvbGRUYWciLCJpc0VxdWFsTm9kZSIsInNwbGljZSIsImZvckVhY2giLCJ0IiwicGFyZW50Tm9kZSIsInJlbW92ZUNoaWxkIiwiaW5zZXJ0QmVmb3JlIiwidG9TdHJpbmciLCJ1cGRhdGVQcm9taXNlIiwibW91bnRlZEluc3RhbmNlcyIsIlNldCIsInVwZGF0ZUhlYWQiLCJoZWFkIiwicHJvbWlzZSIsIlByb21pc2UiLCJyZXNvbHZlIiwidGhlbiIsInRhZ3MiLCJoIiwiaHJlZiIsInRpdGxlQ29tcG9uZW50IiwidGl0bGUiLCJyZXF1ZXN0SWRsZUNhbGxiYWNrIiwic2VsZiIsImNiIiwic3RhcnQiLCJEYXRlIiwibm93Iiwic2V0VGltZW91dCIsImRpZFRpbWVvdXQiLCJ0aW1lUmVtYWluaW5nIiwiTWF0aCIsIm1heCIsImNhbmNlbElkbGVDYWxsYmFjayIsImlkIiwiY2xlYXJUaW1lb3V0IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsInJlcXVpcmUiLCJpbml0U2NyaXB0TG9hZGVyIiwiX2V4dGVuZHMyIiwiX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UyIiwiX3JlYWN0IiwiX2hlYWRNYW5hZ2VyQ29udGV4dCIsIl9oZWFkTWFuYWdlciIsIl9yZXF1ZXN0SWRsZUNhbGxiYWNrIiwiU2NyaXB0Q2FjaGUiLCJNYXAiLCJMb2FkQ2FjaGUiLCJpZ25vcmVQcm9wcyIsImxvYWRTY3JpcHQiLCJzcmMiLCJvbkxvYWQiLCJvbkVycm9yIiwiY2FjaGVLZXkiLCJoYXMiLCJhZGQiLCJnZXQiLCJsb2FkUHJvbWlzZSIsInJlamVjdCIsImFkZEV2ZW50TGlzdGVuZXIiLCJjYWxsIiwic2V0IiwidmFsdWUiLCJPYmplY3QiLCJlbnRyaWVzIiwiaW5jbHVkZXMiLCJib2R5IiwiYXBwZW5kQ2hpbGQiLCJoYW5kbGVDbGllbnRTY3JpcHRMb2FkIiwic3RyYXRlZ3kiLCJ3aW5kb3ciLCJsb2FkTGF6eVNjcmlwdCIsInJlYWR5U3RhdGUiLCJzY3JpcHRMb2FkZXJJdGVtcyIsIlNjcmlwdCIsInJlc3RQcm9wcyIsImRlZmF1bHQiLCJ1cGRhdGVTY3JpcHRzIiwic2NyaXB0cyIsInVzZUNvbnRleHQiLCJIZWFkTWFuYWdlckNvbnRleHQiLCJ1c2VFZmZlY3QiLCJiZWZvcmVJbnRlcmFjdGl2ZSIsImNvbmNhdCIsIl9kZWZhdWx0IiwiSHRtbCIsIk1haW4iLCJfcHJvcFR5cGVzIiwiX2ludGVyb3BSZXF1aXJlV2lsZGNhcmQiLCJfc2VydmVyIiwiX2NvbnN0YW50cyIsIl9kb2N1bWVudENvbnRleHQiLCJfdXRpbHMiLCJEb2N1bWVudENvbnRleHQiLCJEb2N1bWVudEluaXRpYWxQcm9wcyIsIkRvY3VtZW50UHJvcHMiLCJfZ2V0UGFnZUZpbGVzIiwiX3V0aWxzMiIsIl9odG1sZXNjYXBlIiwiX3NjcmlwdCIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsIldlYWtNYXAiLCJjYWNoZSIsIm9iaiIsIl9fZXNNb2R1bGUiLCJuZXdPYmoiLCJoYXNQcm9wZXJ0eURlc2NyaXB0b3IiLCJkZWZpbmVQcm9wZXJ0eSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsImtleSIsInByb3RvdHlwZSIsImRlc2MiLCJnZXREb2N1bWVudEZpbGVzIiwiYnVpbGRNYW5pZmVzdCIsInBhdGhuYW1lIiwiaW5BbXBNb2RlIiwic2hhcmVkRmlsZXMiLCJnZXRQYWdlRmlsZXMiLCJwYWdlRmlsZXMiLCJhbGxGaWxlcyIsImdldFBvbHlmaWxsU2NyaXB0cyIsImNvbnRleHQiLCJhc3NldFByZWZpeCIsImRldk9ubHlDYWNoZUJ1c3RlclF1ZXJ5U3RyaW5nIiwiZGlzYWJsZU9wdGltaXplZExvYWRpbmciLCJwb2x5ZmlsbEZpbGVzIiwicG9seWZpbGwiLCJlbmRzV2l0aCIsImRlZmVyIiwibm9uY2UiLCJjcm9zc09yaWdpbiIsInByb2Nlc3MiLCJnZXRQcmVOZXh0U2NyaXB0cyIsInNjcmlwdExvYWRlciIsImZpbGUiLCJzY3JpcHRQcm9wcyIsImFzc2lnbiIsIl9fTkVYVF9DUk9TU19PUklHSU4iLCJnZXREeW5hbWljQ2h1bmtzIiwiZmlsZXMiLCJkeW5hbWljSW1wb3J0cyIsImlzRGV2ZWxvcG1lbnQiLCJhc3luYyIsImVuY29kZVVSSSIsImdldFNjcmlwdHMiLCJfYnVpbGRNYW5pZmVzdCRsb3dQcmkiLCJub3JtYWxTY3JpcHRzIiwibG93UHJpb3JpdHlTY3JpcHRzIiwibG93UHJpb3JpdHlGaWxlcyIsIkRvY3VtZW50IiwiQ29tcG9uZW50IiwiZ2V0SW5pdGlhbFByb3BzIiwiY3R4IiwiZW5oYW5jZUFwcCIsIkFwcCIsImh0bWwiLCJyZW5kZXJQYWdlIiwic3R5bGVzIiwicmVuZGVyRG9jdW1lbnQiLCJEb2N1bWVudENvbXBvbmVudCIsIlByb3ZpZGVyIiwicmVuZGVyIiwiSGVhZCIsIk5leHRTY3JpcHQiLCJkb2NDb21wb25lbnRzUmVuZGVyZWQiLCJsb2NhbGUiLCJsYW5nIiwiYW1wIiwiY29uc3RydWN0b3IiLCJhcmdzIiwiZ2V0Q3NzTGlua3MiLCJjc3NGaWxlcyIsImYiLCJ1bm1hbmdlZEZpbGVzIiwiZHluYW1pY0Nzc0ZpbGVzIiwiZnJvbSIsImV4aXN0aW5nIiwiY3NzTGlua0VsZW1lbnRzIiwiaXNTaGFyZWRGaWxlIiwicmVsIiwiYXMiLCJpc1VubWFuYWdlZEZpbGUiLCJnZXRQcmVsb2FkRHluYW1pY0NodW5rcyIsIkJvb2xlYW4iLCJnZXRQcmVsb2FkTWFpbkxpbmtzIiwicHJlbG9hZEZpbGVzIiwiaGFuZGxlRG9jdW1lbnRTY3JpcHRMb2FkZXJJdGVtcyIsImZpbHRlcmVkQ2hpbGRyZW4iLCJDaGlsZHJlbiIsImNoaWxkIiwiX19ORVhUX0RBVEFfXyIsIm1ha2VTdHlsZXNoZWV0SW5lcnQiLCJub2RlIiwiYyIsIk9QVElNSVpFRF9GT05UX1BST1ZJREVSUyIsInNvbWUiLCJ1cmwiLCJzdGFydHNXaXRoIiwibmV3UHJvcHMiLCJjbG9uZUVsZW1lbnQiLCJfdGhpcyRwcm9wcyRub25jZSIsIl90aGlzJHByb3BzJG5vbmNlMiIsImFtcFBhdGgiLCJoeWJyaWRBbXAiLCJjYW5vbmljYWxCYXNlIiwiZGFuZ2Vyb3VzQXNQYXRoIiwiaGVhZFRhZ3MiLCJ1bnN0YWJsZV9ydW50aW1lSlMiLCJ1bnN0YWJsZV9Kc1ByZWxvYWQiLCJkaXNhYmxlUnVudGltZUpTIiwiZGlzYWJsZUpzUHJlbG9hZCIsImNzc1ByZWxvYWRzIiwib3RoZXJIZWFkRWxlbWVudHMiLCJ0b0FycmF5IiwiX2NoaWxkJHByb3BzIiwiaXNSZWFjdEhlbG1ldCIsIl9jaGlsZCRwcm9wczIiLCJ3YXJuIiwibmFtZSIsImhhc0FtcGh0bWxSZWwiLCJoYXNDYW5vbmljYWxSZWwiLCJiYWRQcm9wIiwiaW5kZXhPZiIsImtleXMiLCJwcm9wIiwicGFnZSIsImN1clN0eWxlcyIsImhhc1N0eWxlcyIsIl9lbCRwcm9wcyIsIl9lbCRwcm9wcyRkYW5nZXJvdXNseSIsIkZyYWdtZW50IiwiY291bnQiLCJjbGVhbkFtcFBhdGgiLCJzdHlsZSIsInJlcGxhY2UiLCJnZXRBbXBQYXRoIiwiY29udGV4dFR5cGUiLCJwcm9wVHlwZXMiLCJzdHJpbmciLCJBTVBfUkVOREVSX1RBUkdFVCIsImdldElubGluZVNjcmlwdFNvdXJjZSIsImRvY3VtZW50UHJvcHMiLCJkYXRhIiwiSlNPTiIsInN0cmluZ2lmeSIsImh0bWxFc2NhcGVKc29uU3RyaW5nIiwiZXJyIiwibWVzc2FnZSIsIkVycm9yIiwiYW1wRGV2RmlsZXMiLCJkZXZGaWxlcyIsInNhZmFyaU5vbW9kdWxlRml4IiwiYXNQYXRoIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0EsbUJBQW1CLHNCQUFzQjtBQUN6Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBLDBCOzs7Ozs7Ozs7O0FDbEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsd0M7Ozs7Ozs7Ozs7QUNOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLGFBQWEsdUJBQXVCO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEsK0M7Ozs7Ozs7Ozs7O0FDZmE7O0FBQUFBLGtCQUFBLEdBQW1CLElBQW5CO0FBQXdCQSxlQUFBLEdBQWdCQyxlQUFoQjtBQUFnQ0QseUJBQUEsR0FBMEIsS0FBSyxDQUEvQjtBQUFpQyxNQUFNRSxpQkFBaUIsR0FBQztBQUFDQyxlQUFhLEVBQUMsZ0JBQWY7QUFBZ0NDLFdBQVMsRUFBQyxPQUExQztBQUFrREMsU0FBTyxFQUFDLEtBQTFEO0FBQWdFQyxXQUFTLEVBQUMsWUFBMUU7QUFBdUZDLFVBQVEsRUFBQztBQUFoRyxDQUF4QjtBQUFvSVAseUJBQUEsR0FBMEJFLGlCQUExQjs7QUFBNEMsU0FBU00saUJBQVQsQ0FBMkI7QUFBQ0MsTUFBRDtBQUFNQztBQUFOLENBQTNCLEVBQXdDO0FBQUMsUUFBTUMsRUFBRSxHQUFDQyxRQUFRLENBQUNDLGFBQVQsQ0FBdUJKLElBQXZCLENBQVQ7O0FBQXNDLE9BQUksTUFBTUssQ0FBVixJQUFlSixLQUFmLEVBQXFCO0FBQUMsUUFBRyxDQUFDQSxLQUFLLENBQUNLLGNBQU4sQ0FBcUJELENBQXJCLENBQUosRUFBNEI7QUFBUyxRQUFHQSxDQUFDLEtBQUcsVUFBSixJQUFnQkEsQ0FBQyxLQUFHLHlCQUF2QixFQUFpRCxTQUF2RixDQUFnRzs7QUFDMWQsUUFBR0osS0FBSyxDQUFDSSxDQUFELENBQUwsS0FBV0UsU0FBZCxFQUF3QjtBQUFTLFVBQU1DLElBQUksR0FBQ2YsaUJBQWlCLENBQUNZLENBQUQsQ0FBakIsSUFBc0JBLENBQUMsQ0FBQ0ksV0FBRixFQUFqQzs7QUFBaUQsUUFBR1QsSUFBSSxLQUFHLFFBQVAsS0FBa0JRLElBQUksS0FBRyxPQUFQLElBQWdCQSxJQUFJLEtBQUcsT0FBdkIsSUFBZ0NBLElBQUksS0FBRyxVQUF6RCxDQUFILEVBQXdFO0FBQUM7QUFBQ04sUUFBRSxDQUFDTSxJQUFELENBQUYsR0FBUyxDQUFDLENBQUNQLEtBQUssQ0FBQ0ksQ0FBRCxDQUFoQjtBQUFxQixLQUEvRixNQUFtRztBQUFDSCxRQUFFLENBQUNRLFlBQUgsQ0FBZ0JGLElBQWhCLEVBQXFCUCxLQUFLLENBQUNJLENBQUQsQ0FBMUI7QUFBZ0M7QUFBQzs7QUFBQSxRQUFLO0FBQUNNLFlBQUQ7QUFBVUM7QUFBVixNQUFtQ1gsS0FBeEM7O0FBQThDLE1BQUdXLHVCQUFILEVBQTJCO0FBQUNWLE1BQUUsQ0FBQ1csU0FBSCxHQUFhRCx1QkFBdUIsQ0FBQ0UsTUFBeEIsSUFBZ0MsRUFBN0M7QUFBaUQsR0FBN0UsTUFBa0YsSUFBR0gsUUFBSCxFQUFZO0FBQUNULE1BQUUsQ0FBQ2EsV0FBSCxHQUFlLE9BQU9KLFFBQVAsS0FBa0IsUUFBbEIsR0FBMkJBLFFBQTNCLEdBQW9DSyxLQUFLLENBQUNDLE9BQU4sQ0FBY04sUUFBZCxJQUF3QkEsUUFBUSxDQUFDTyxJQUFULENBQWMsRUFBZCxDQUF4QixHQUEwQyxFQUE3RjtBQUFpRzs7QUFBQSxTQUFPaEIsRUFBUDtBQUFXOztBQUFBLFNBQVNpQixjQUFULENBQXdCbkIsSUFBeEIsRUFBNkJvQixVQUE3QixFQUF3QztBQUFDLFFBQU1DLE1BQU0sR0FBQ2xCLFFBQVEsQ0FBQ21CLG9CQUFULENBQThCLE1BQTlCLEVBQXNDLENBQXRDLENBQWI7QUFBc0QsUUFBTUMsV0FBVyxHQUFDRixNQUFNLENBQUNHLGFBQVAsQ0FBcUIsNEJBQXJCLENBQWxCOztBQUFxRSxZQUF1QztBQUFDLFFBQUcsQ0FBQ0QsV0FBSixFQUFnQjtBQUFDRSxhQUFPLENBQUNDLEtBQVIsQ0FBYywrRkFBZDtBQUErRztBQUFRO0FBQUM7O0FBQUEsUUFBTUMsU0FBUyxHQUFDQyxNQUFNLENBQUNMLFdBQVcsQ0FBQ00sT0FBYixDQUF0QjtBQUE0QyxRQUFNQyxPQUFPLEdBQUMsRUFBZDs7QUFBaUIsT0FBSSxJQUFJQyxDQUFDLEdBQUMsQ0FBTixFQUFRQyxDQUFDLEdBQUNULFdBQVcsQ0FBQ1Usc0JBQTFCLEVBQWlERixDQUFDLEdBQUNKLFNBQW5ELEVBQTZESSxDQUFDLElBQUdDLENBQUMsR0FBQ0EsQ0FBQyxDQUFDQyxzQkFBckUsRUFBNEY7QUFBQyxRQUFHRCxDQUFDLENBQUNFLE9BQUYsQ0FBVXpCLFdBQVYsT0FBMEJULElBQTdCLEVBQWtDO0FBQUM4QixhQUFPLENBQUNLLElBQVIsQ0FBYUgsQ0FBYjtBQUFpQjtBQUFDOztBQUFBLFFBQU1JLE9BQU8sR0FBQ2hCLFVBQVUsQ0FBQ2lCLEdBQVgsQ0FBZXRDLGlCQUFmLEVBQWtDdUMsTUFBbEMsQ0FBeUNDLE1BQU0sSUFBRTtBQUFDLFNBQUksSUFBSUMsQ0FBQyxHQUFDLENBQU4sRUFBUUMsR0FBRyxHQUFDWCxPQUFPLENBQUNZLE1BQXhCLEVBQStCRixDQUFDLEdBQUNDLEdBQWpDLEVBQXFDRCxDQUFDLEVBQXRDLEVBQXlDO0FBQUMsWUFBTUcsTUFBTSxHQUFDYixPQUFPLENBQUNVLENBQUQsQ0FBcEI7O0FBQXdCLFVBQUdHLE1BQU0sQ0FBQ0MsV0FBUCxDQUFtQkwsTUFBbkIsQ0FBSCxFQUE4QjtBQUFDVCxlQUFPLENBQUNlLE1BQVIsQ0FBZUwsQ0FBZixFQUFpQixDQUFqQjtBQUFvQixlQUFPLEtBQVA7QUFBYztBQUFDOztBQUFBLFdBQU8sSUFBUDtBQUFhLEdBQW5NLENBQWQ7QUFBbU5WLFNBQU8sQ0FBQ2dCLE9BQVIsQ0FBZ0JDLENBQUMsSUFBRUEsQ0FBQyxDQUFDQyxVQUFGLENBQWFDLFdBQWIsQ0FBeUJGLENBQXpCLENBQW5CO0FBQWdEWCxTQUFPLENBQUNVLE9BQVIsQ0FBZ0JDLENBQUMsSUFBRTFCLE1BQU0sQ0FBQzZCLFlBQVAsQ0FBb0JILENBQXBCLEVBQXNCeEIsV0FBdEIsQ0FBbkI7QUFBdURBLGFBQVcsQ0FBQ00sT0FBWixHQUFvQixDQUFDRixTQUFTLEdBQUNHLE9BQU8sQ0FBQ1ksTUFBbEIsR0FBeUJOLE9BQU8sQ0FBQ00sTUFBbEMsRUFBMENTLFFBQTFDLEVBQXBCO0FBQTBFOztBQUFBLFNBQVMzRCxlQUFULEdBQTBCO0FBQUMsTUFBSTRELGFBQWEsR0FBQyxJQUFsQjtBQUF1QixTQUFNO0FBQUNDLG9CQUFnQixFQUFDLElBQUlDLEdBQUosRUFBbEI7QUFBNEJDLGNBQVUsRUFBQ0MsSUFBSSxJQUFFO0FBQUMsWUFBTUMsT0FBTyxHQUFDTCxhQUFhLEdBQUNNLE9BQU8sQ0FBQ0MsT0FBUixHQUFrQkMsSUFBbEIsQ0FBdUIsTUFBSTtBQUFDLFlBQUdILE9BQU8sS0FBR0wsYUFBYixFQUEyQjtBQUFPQSxxQkFBYSxHQUFDLElBQWQ7QUFBbUIsY0FBTVMsSUFBSSxHQUFDLEVBQVg7QUFBY0wsWUFBSSxDQUFDVixPQUFMLENBQWFnQixDQUFDLElBQUU7QUFBQyxlQUFHO0FBQzdtRDtBQUNBQSxXQUFDLENBQUM5RCxJQUFGLEtBQVMsTUFBVCxJQUFpQjhELENBQUMsQ0FBQzdELEtBQUYsQ0FBUSxzQkFBUixDQUFqQixJQUFrRCxDQUFDRSxRQUFRLENBQUNxQixhQUFULENBQXdCLG9CQUFtQnNDLENBQUMsQ0FBQzdELEtBQUYsQ0FBUSxXQUFSLENBQXFCLElBQWhFLENBRnVqRCxFQUVsL0M7QUFBQzZELGFBQUMsQ0FBQzdELEtBQUYsQ0FBUThELElBQVIsR0FBYUQsQ0FBQyxDQUFDN0QsS0FBRixDQUFRLFdBQVIsQ0FBYjtBQUFrQzZELGFBQUMsQ0FBQzdELEtBQUYsQ0FBUSxXQUFSLElBQXFCTSxTQUFyQjtBQUFnQzs7QUFBQSxnQkFBTWEsVUFBVSxHQUFDeUMsSUFBSSxDQUFDQyxDQUFDLENBQUM5RCxJQUFILENBQUosSUFBYyxFQUEvQjtBQUFrQ29CLG9CQUFVLENBQUNlLElBQVgsQ0FBZ0IyQixDQUFoQjtBQUFtQkQsY0FBSSxDQUFDQyxDQUFDLENBQUM5RCxJQUFILENBQUosR0FBYW9CLFVBQWI7QUFBeUIsU0FGZzFDO0FBRTkwQyxjQUFNNEMsY0FBYyxHQUFDSCxJQUFJLENBQUNJLEtBQUwsR0FBV0osSUFBSSxDQUFDSSxLQUFMLENBQVcsQ0FBWCxDQUFYLEdBQXlCLElBQTlDO0FBQW1ELFlBQUlBLEtBQUssR0FBQyxFQUFWOztBQUFhLFlBQUdELGNBQUgsRUFBa0I7QUFBQyxnQkFBSztBQUFDckQ7QUFBRCxjQUFXcUQsY0FBYyxDQUFDL0QsS0FBL0I7QUFBcUNnRSxlQUFLLEdBQUMsT0FBT3RELFFBQVAsS0FBa0IsUUFBbEIsR0FBMkJBLFFBQTNCLEdBQW9DSyxLQUFLLENBQUNDLE9BQU4sQ0FBY04sUUFBZCxJQUF3QkEsUUFBUSxDQUFDTyxJQUFULENBQWMsRUFBZCxDQUF4QixHQUEwQyxFQUFwRjtBQUF3Rjs7QUFBQSxZQUFHK0MsS0FBSyxLQUFHOUQsUUFBUSxDQUFDOEQsS0FBcEIsRUFBMEI5RCxRQUFRLENBQUM4RCxLQUFULEdBQWVBLEtBQWY7QUFBcUIsU0FBQyxNQUFELEVBQVEsTUFBUixFQUFlLE1BQWYsRUFBc0IsT0FBdEIsRUFBOEIsUUFBOUIsRUFBd0NuQixPQUF4QyxDQUFnRDlDLElBQUksSUFBRTtBQUFDbUIsd0JBQWMsQ0FBQ25CLElBQUQsRUFBTTZELElBQUksQ0FBQzdELElBQUQsQ0FBSixJQUFZLEVBQWxCLENBQWQ7QUFBcUMsU0FBNUY7QUFBK0YsT0FGaTVCLENBQTVCO0FBRWwzQjtBQUZvMEIsR0FBTjtBQUUzekIsQzs7Ozs7Ozs7Ozs7QUNIbG1COztBQUFBVCxrQkFBQSxHQUFtQixJQUFuQjtBQUF3QkEsMEJBQUEsR0FBMkJBLDJCQUFBLEdBQTRCLEtBQUssQ0FBNUQ7O0FBQThELE1BQU0yRSxtQkFBbUIsR0FBQyxPQUFPQyxJQUFQLEtBQWMsV0FBZCxJQUEyQkEsSUFBSSxDQUFDRCxtQkFBaEMsSUFBcUQsVUFBU0UsRUFBVCxFQUFZO0FBQUMsTUFBSUMsS0FBSyxHQUFDQyxJQUFJLENBQUNDLEdBQUwsRUFBVjtBQUFxQixTQUFPQyxVQUFVLENBQUMsWUFBVTtBQUFDSixNQUFFLENBQUM7QUFBQ0ssZ0JBQVUsRUFBQyxLQUFaO0FBQWtCQyxtQkFBYSxFQUFDLFlBQVU7QUFBQyxlQUFPQyxJQUFJLENBQUNDLEdBQUwsQ0FBUyxDQUFULEVBQVcsTUFBSU4sSUFBSSxDQUFDQyxHQUFMLEtBQVdGLEtBQWYsQ0FBWCxDQUFQO0FBQTBDO0FBQXJGLEtBQUQsQ0FBRjtBQUE0RixHQUF4RyxFQUF5RyxDQUF6RyxDQUFqQjtBQUE4SCxDQUEvTzs7QUFBZ1A5RSwyQkFBQSxHQUE0QjJFLG1CQUE1Qjs7QUFBZ0QsTUFBTVcsa0JBQWtCLEdBQUMsT0FBT1YsSUFBUCxLQUFjLFdBQWQsSUFBMkJBLElBQUksQ0FBQ1Usa0JBQWhDLElBQW9ELFVBQVNDLEVBQVQsRUFBWTtBQUFDLFNBQU9DLFlBQVksQ0FBQ0QsRUFBRCxDQUFuQjtBQUF5QixDQUFuSDs7QUFBb0h2RiwwQkFBQSxHQUEyQnNGLGtCQUEzQixDOzs7Ozs7Ozs7OztBQ0ExZTs7QUFBQSxJQUFJRyxzQkFBc0IsR0FBQ0MsbUJBQU8sQ0FBQyxvSEFBRCxDQUFsQzs7QUFBbUYxRixrQkFBQSxHQUFtQixJQUFuQjtBQUF3QkEsd0JBQUEsR0FBeUIyRixnQkFBekI7QUFBMEMzRixlQUFBLEdBQWdCLEtBQUssQ0FBckI7O0FBQXVCLElBQUk0RixTQUFTLEdBQUNILHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLHdGQUFELENBQVIsQ0FBcEM7O0FBQWdGLElBQUlHLDhCQUE4QixHQUFDSixzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyxrSUFBRCxDQUFSLENBQXpEOztBQUEwSCxJQUFJSSxNQUFNLEdBQUNKLG1CQUFPLENBQUMsb0JBQUQsQ0FBbEI7O0FBQTRCLElBQUlLLG1CQUFtQixHQUFDTCxtQkFBTyxDQUFDLHdGQUFELENBQS9COztBQUEyRSxJQUFJTSxZQUFZLEdBQUNOLG1CQUFPLENBQUMsdUVBQUQsQ0FBeEI7O0FBQTJDLElBQUlPLG9CQUFvQixHQUFDUCxtQkFBTyxDQUFDLHlGQUFELENBQWhDOztBQUE0RCxNQUFNUSxXQUFXLEdBQUMsSUFBSUMsR0FBSixFQUFsQjtBQUE0QixNQUFNQyxTQUFTLEdBQUMsSUFBSXJDLEdBQUosRUFBaEI7QUFBMEIsTUFBTXNDLFdBQVcsR0FBQyxDQUFDLFFBQUQsRUFBVSx5QkFBVixFQUFvQyxVQUFwQyxFQUErQyxTQUEvQyxFQUF5RCxVQUF6RCxDQUFsQjs7QUFBdUYsTUFBTUMsVUFBVSxHQUFDNUYsS0FBSyxJQUFFO0FBQUMsUUFBSztBQUFDNkYsT0FBRDtBQUFLaEIsTUFBTDtBQUFRaUIsVUFBTSxHQUFDLE1BQUksQ0FBRSxDQUFyQjtBQUFzQm5GLDJCQUF0QjtBQUE4Q0QsWUFBUSxHQUFDLEVBQXZEO0FBQTBEcUY7QUFBMUQsTUFBbUUvRixLQUF4RTtBQUE4RSxRQUFNZ0csUUFBUSxHQUFDbkIsRUFBRSxJQUFFZ0IsR0FBbkI7O0FBQXVCLE1BQUdMLFdBQVcsQ0FBQ1MsR0FBWixDQUFnQkosR0FBaEIsQ0FBSCxFQUF3QjtBQUFDLFFBQUcsQ0FBQ0gsU0FBUyxDQUFDTyxHQUFWLENBQWNELFFBQWQsQ0FBSixFQUE0QjtBQUFDTixlQUFTLENBQUNRLEdBQVYsQ0FBY0YsUUFBZCxFQUFELENBQXlCOztBQUMxNkJSLGlCQUFXLENBQUNXLEdBQVosQ0FBZ0JOLEdBQWhCLEVBQXFCbEMsSUFBckIsQ0FBMEJtQyxNQUExQixFQUFpQ0MsT0FBakM7QUFBMkM7O0FBQUE7QUFBUTs7QUFBQSxRQUFNOUYsRUFBRSxHQUFDQyxRQUFRLENBQUNDLGFBQVQsQ0FBdUIsUUFBdkIsQ0FBVDtBQUEwQyxRQUFNaUcsV0FBVyxHQUFDLElBQUkzQyxPQUFKLENBQVksQ0FBQ0MsT0FBRCxFQUFTMkMsTUFBVCxLQUFrQjtBQUFDcEcsTUFBRSxDQUFDcUcsZ0JBQUgsQ0FBb0IsTUFBcEIsRUFBMkIsWUFBVTtBQUFDNUMsYUFBTzs7QUFBRyxVQUFHb0MsTUFBSCxFQUFVO0FBQUNBLGNBQU0sQ0FBQ1MsSUFBUCxDQUFZLElBQVo7QUFBbUI7QUFBQyxLQUEvRTtBQUFpRnRHLE1BQUUsQ0FBQ3FHLGdCQUFILENBQW9CLE9BQXBCLEVBQTRCLFlBQVU7QUFBQ0QsWUFBTTs7QUFBRyxVQUFHTixPQUFILEVBQVc7QUFBQ0EsZUFBTztBQUFJO0FBQUMsS0FBeEU7QUFBMkUsR0FBM0wsQ0FBbEI7O0FBQStNLE1BQUdGLEdBQUgsRUFBTztBQUFDTCxlQUFXLENBQUNnQixHQUFaLENBQWdCWCxHQUFoQixFQUFvQk8sV0FBcEI7QUFBaUNWLGFBQVMsQ0FBQ1EsR0FBVixDQUFjRixRQUFkO0FBQXlCOztBQUFBLE1BQUdyRix1QkFBSCxFQUEyQjtBQUFDVixNQUFFLENBQUNXLFNBQUgsR0FBYUQsdUJBQXVCLENBQUNFLE1BQXhCLElBQWdDLEVBQTdDO0FBQWlELEdBQTdFLE1BQWtGLElBQUdILFFBQUgsRUFBWTtBQUFDVCxNQUFFLENBQUNhLFdBQUgsR0FBZSxPQUFPSixRQUFQLEtBQWtCLFFBQWxCLEdBQTJCQSxRQUEzQixHQUFvQ0ssS0FBSyxDQUFDQyxPQUFOLENBQWNOLFFBQWQsSUFBd0JBLFFBQVEsQ0FBQ08sSUFBVCxDQUFjLEVBQWQsQ0FBeEIsR0FBMEMsRUFBN0Y7QUFBaUcsR0FBOUcsTUFBbUgsSUFBRzRFLEdBQUgsRUFBTztBQUFDNUYsTUFBRSxDQUFDNEYsR0FBSCxHQUFPQSxHQUFQO0FBQVk7O0FBQUEsT0FBSSxNQUFLLENBQUN0RCxDQUFELEVBQUdrRSxLQUFILENBQVQsSUFBcUJDLE1BQU0sQ0FBQ0MsT0FBUCxDQUFlM0csS0FBZixDQUFyQixFQUEyQztBQUFDLFFBQUd5RyxLQUFLLEtBQUduRyxTQUFSLElBQW1CcUYsV0FBVyxDQUFDaUIsUUFBWixDQUFxQnJFLENBQXJCLENBQXRCLEVBQThDO0FBQUM7QUFBVTs7QUFBQSxVQUFNaEMsSUFBSSxHQUFDK0UsWUFBWSxDQUFDOUYsaUJBQWIsQ0FBK0IrQyxDQUEvQixLQUFtQ0EsQ0FBQyxDQUFDL0IsV0FBRixFQUE5QztBQUE4RFAsTUFBRSxDQUFDUSxZQUFILENBQWdCRixJQUFoQixFQUFxQmtHLEtBQXJCO0FBQTZCOztBQUFBdkcsVUFBUSxDQUFDMkcsSUFBVCxDQUFjQyxXQUFkLENBQTBCN0csRUFBMUI7QUFBK0IsQ0FEeEU7O0FBQ3lFLFNBQVM4RyxzQkFBVCxDQUFnQy9HLEtBQWhDLEVBQXNDO0FBQUMsUUFBSztBQUFDZ0gsWUFBUSxHQUFDO0FBQVYsTUFBOEJoSCxLQUFuQzs7QUFBeUMsTUFBR2dILFFBQVEsS0FBRyxrQkFBZCxFQUFpQztBQUFDcEIsY0FBVSxDQUFDNUYsS0FBRCxDQUFWO0FBQW1CLEdBQXJELE1BQTBELElBQUdnSCxRQUFRLEtBQUcsWUFBZCxFQUEyQjtBQUFDQyxVQUFNLENBQUNYLGdCQUFQLENBQXdCLE1BQXhCLEVBQStCLE1BQUk7QUFBQyxPQUFDLEdBQUVmLG9CQUFvQixDQUFDdEIsbUJBQXhCLEVBQTZDLE1BQUkyQixVQUFVLENBQUM1RixLQUFELENBQTNEO0FBQXFFLEtBQXpHO0FBQTRHO0FBQUM7O0FBQUEsU0FBU2tILGNBQVQsQ0FBd0JsSCxLQUF4QixFQUE4QjtBQUFDLE1BQUdFLFFBQVEsQ0FBQ2lILFVBQVQsS0FBc0IsVUFBekIsRUFBb0M7QUFBQyxLQUFDLEdBQUU1QixvQkFBb0IsQ0FBQ3RCLG1CQUF4QixFQUE2QyxNQUFJMkIsVUFBVSxDQUFDNUYsS0FBRCxDQUEzRDtBQUFxRSxHQUExRyxNQUE4RztBQUFDaUgsVUFBTSxDQUFDWCxnQkFBUCxDQUF3QixNQUF4QixFQUErQixNQUFJO0FBQUMsT0FBQyxHQUFFZixvQkFBb0IsQ0FBQ3RCLG1CQUF4QixFQUE2QyxNQUFJMkIsVUFBVSxDQUFDNUYsS0FBRCxDQUEzRDtBQUFxRSxLQUF6RztBQUE0RztBQUFDOztBQUFBLFNBQVNpRixnQkFBVCxDQUEwQm1DLGlCQUExQixFQUE0QztBQUFDQSxtQkFBaUIsQ0FBQ3ZFLE9BQWxCLENBQTBCa0Usc0JBQTFCO0FBQW1EOztBQUFBLFNBQVNNLE1BQVQsQ0FBZ0JySCxLQUFoQixFQUFzQjtBQUFDLFFBQUs7QUFBQzZGLE9BQUcsR0FBQyxFQUFMO0FBQVFDLFVBQU0sR0FBQyxNQUFJLENBQUUsQ0FBckI7QUFBc0JrQixZQUFRLEdBQUMsa0JBQS9CO0FBQWtEakI7QUFBbEQsTUFBMkQvRixLQUFoRTtBQUFBLFFBQXNFc0gsU0FBUyxHQUFDLENBQUMsR0FBRW5DLDhCQUE4QixDQUFDb0MsT0FBbEMsRUFBMkN2SCxLQUEzQyxFQUFpRCxDQUFDLEtBQUQsRUFBTyxRQUFQLEVBQWdCLHlCQUFoQixFQUEwQyxVQUExQyxFQUFxRCxTQUFyRCxDQUFqRCxDQUFoRixDQUFELENBQW1NOztBQUM5bUQsUUFBSztBQUFDd0gsaUJBQUQ7QUFBZUM7QUFBZixNQUF3QixDQUFDLEdBQUVyQyxNQUFNLENBQUNzQyxVQUFWLEVBQXNCckMsbUJBQW1CLENBQUNzQyxrQkFBMUMsQ0FBN0I7QUFBMkYsR0FBQyxHQUFFdkMsTUFBTSxDQUFDd0MsU0FBVixFQUFxQixNQUFJO0FBQUMsUUFBR1osUUFBUSxLQUFHLGtCQUFkLEVBQWlDO0FBQUNwQixnQkFBVSxDQUFDNUYsS0FBRCxDQUFWO0FBQW1CLEtBQXJELE1BQTBELElBQUdnSCxRQUFRLEtBQUcsWUFBZCxFQUEyQjtBQUFDRSxvQkFBYyxDQUFDbEgsS0FBRCxDQUFkO0FBQXVCO0FBQUMsR0FBeEksRUFBeUksQ0FBQ0EsS0FBRCxFQUFPZ0gsUUFBUCxDQUF6STs7QUFBMkosTUFBR0EsUUFBUSxLQUFHLG1CQUFkLEVBQWtDO0FBQUMsUUFBR1EsYUFBSCxFQUFpQjtBQUFDQyxhQUFPLENBQUNJLGlCQUFSLEdBQTBCLENBQUNKLE9BQU8sQ0FBQ0ksaUJBQVIsSUFBMkIsRUFBNUIsRUFBZ0NDLE1BQWhDLENBQXVDLENBQUMsQ0FBQyxHQUFFNUMsU0FBUyxDQUFDcUMsT0FBYixFQUFzQjtBQUFDMUIsV0FBRDtBQUFLQyxjQUFMO0FBQVlDO0FBQVosT0FBdEIsRUFBMkN1QixTQUEzQyxDQUFELENBQXZDLENBQTFCO0FBQTBIRSxtQkFBYSxDQUFDQyxPQUFELENBQWI7QUFBd0I7QUFBQzs7QUFBQSxTQUFPLElBQVA7QUFBYTs7QUFBQSxJQUFJTSxRQUFRLEdBQUNWLE1BQWI7QUFBb0IvSCxlQUFBLEdBQWdCeUksUUFBaEIsQzs7Ozs7Ozs7Ozs7QUNGbGQ7Ozs7Ozs7Ozs7OztBQUFBekksa0JBQUEsR0FBbUIsSUFBbkI7QUFBd0JBLFlBQUEsR0FBYTBJLElBQWI7QUFBa0IxSSxZQUFBLEdBQWEySSxJQUFiO0FBQWtCM0ksa0JBQUEsR0FBbUJBLFlBQUEsR0FBYUEsZUFBQSxHQUFnQixLQUFLLENBQXJEOztBQUF1RCxJQUFJNEksVUFBVSxHQUFDbkQsc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsOEJBQUQsQ0FBUixDQUFyQzs7QUFBNkQsSUFBSUksTUFBTSxHQUFDK0MsdUJBQXVCLENBQUNuRCxtQkFBTyxDQUFDLG9CQUFELENBQVIsQ0FBbEM7O0FBQXFELElBQUlvRCxPQUFPLEdBQUNyRCxzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyw0Q0FBRCxDQUFSLENBQWxDOztBQUFpRSxJQUFJcUQsVUFBVSxHQUFDckQsbUJBQU8sQ0FBQyxrRUFBRCxDQUF0Qjs7QUFBdUQsSUFBSXNELGdCQUFnQixHQUFDdEQsbUJBQU8sQ0FBQyxnRkFBRCxDQUE1Qjs7QUFBb0UsSUFBSXVELE1BQU0sR0FBQ3ZELG1CQUFPLENBQUMsMERBQUQsQ0FBbEI7O0FBQStDMUYsdUJBQUEsR0FBd0JpSixNQUFNLENBQUNDLGVBQS9CO0FBQStDbEosNEJBQUEsR0FBNkJpSixNQUFNLENBQUNFLG9CQUFwQztBQUF5RG5KLHFCQUFBLEdBQXNCaUosTUFBTSxDQUFDRyxhQUE3Qjs7QUFBMkMsSUFBSUMsYUFBYSxHQUFDM0QsbUJBQU8sQ0FBQyxrRkFBRCxDQUF6Qjs7QUFBa0UsSUFBSTRELE9BQU8sR0FBQzVELG1CQUFPLENBQUMsZ0VBQUQsQ0FBbkI7O0FBQW1ELElBQUk2RCxXQUFXLEdBQUM3RCxtQkFBTyxDQUFDLDJFQUFELENBQXZCOztBQUFnRCxJQUFJOEQsT0FBTyxHQUFDL0Qsc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsbUVBQUQsQ0FBUixDQUFsQzs7QUFBZ0UsU0FBUytELHdCQUFULEdBQW1DO0FBQUMsTUFBRyxPQUFPQyxPQUFQLEtBQWlCLFVBQXBCLEVBQStCLE9BQU8sSUFBUDtBQUFZLE1BQUlDLEtBQUssR0FBQyxJQUFJRCxPQUFKLEVBQVY7O0FBQXdCRCwwQkFBd0IsR0FBQyxZQUFVO0FBQUMsV0FBT0UsS0FBUDtBQUFjLEdBQWxEOztBQUFtRCxTQUFPQSxLQUFQO0FBQWM7O0FBQUEsU0FBU2QsdUJBQVQsQ0FBaUNlLEdBQWpDLEVBQXFDO0FBQUMsTUFBR0EsR0FBRyxJQUFFQSxHQUFHLENBQUNDLFVBQVosRUFBdUI7QUFBQyxXQUFPRCxHQUFQO0FBQVk7O0FBQUEsTUFBR0EsR0FBRyxLQUFHLElBQU4sSUFBWSxPQUFPQSxHQUFQLEtBQWEsUUFBYixJQUF1QixPQUFPQSxHQUFQLEtBQWEsVUFBbkQsRUFBOEQ7QUFBQyxXQUFNO0FBQUMzQixhQUFPLEVBQUMyQjtBQUFULEtBQU47QUFBcUI7O0FBQUEsTUFBSUQsS0FBSyxHQUFDRix3QkFBd0IsRUFBbEM7O0FBQXFDLE1BQUdFLEtBQUssSUFBRUEsS0FBSyxDQUFDaEQsR0FBTixDQUFVaUQsR0FBVixDQUFWLEVBQXlCO0FBQUMsV0FBT0QsS0FBSyxDQUFDOUMsR0FBTixDQUFVK0MsR0FBVixDQUFQO0FBQXVCOztBQUFBLE1BQUlFLE1BQU0sR0FBQyxFQUFYO0FBQWMsTUFBSUMscUJBQXFCLEdBQUMzQyxNQUFNLENBQUM0QyxjQUFQLElBQXVCNUMsTUFBTSxDQUFDNkMsd0JBQXhEOztBQUFpRixPQUFJLElBQUlDLEdBQVIsSUFBZU4sR0FBZixFQUFtQjtBQUFDLFFBQUd4QyxNQUFNLENBQUMrQyxTQUFQLENBQWlCcEosY0FBakIsQ0FBZ0NrRyxJQUFoQyxDQUFxQzJDLEdBQXJDLEVBQXlDTSxHQUF6QyxDQUFILEVBQWlEO0FBQUMsVUFBSUUsSUFBSSxHQUFDTCxxQkFBcUIsR0FBQzNDLE1BQU0sQ0FBQzZDLHdCQUFQLENBQWdDTCxHQUFoQyxFQUFvQ00sR0FBcEMsQ0FBRCxHQUEwQyxJQUF4RTs7QUFBNkUsVUFBR0UsSUFBSSxLQUFHQSxJQUFJLENBQUN2RCxHQUFMLElBQVV1RCxJQUFJLENBQUNsRCxHQUFsQixDQUFQLEVBQThCO0FBQUNFLGNBQU0sQ0FBQzRDLGNBQVAsQ0FBc0JGLE1BQXRCLEVBQTZCSSxHQUE3QixFQUFpQ0UsSUFBakM7QUFBd0MsT0FBdkUsTUFBMkU7QUFBQ04sY0FBTSxDQUFDSSxHQUFELENBQU4sR0FBWU4sR0FBRyxDQUFDTSxHQUFELENBQWY7QUFBc0I7QUFBQztBQUFDOztBQUFBSixRQUFNLENBQUM3QixPQUFQLEdBQWUyQixHQUFmOztBQUFtQixNQUFHRCxLQUFILEVBQVM7QUFBQ0EsU0FBSyxDQUFDekMsR0FBTixDQUFVMEMsR0FBVixFQUFjRSxNQUFkO0FBQXVCOztBQUFBLFNBQU9BLE1BQVA7QUFBZTs7QUFBQSxTQUFTckUsc0JBQVQsQ0FBZ0NtRSxHQUFoQyxFQUFvQztBQUFDLFNBQU9BLEdBQUcsSUFBRUEsR0FBRyxDQUFDQyxVQUFULEdBQW9CRCxHQUFwQixHQUF3QjtBQUFDM0IsV0FBTyxFQUFDMkI7QUFBVCxHQUEvQjtBQUE4Qzs7QUFBQSxTQUFTUyxnQkFBVCxDQUEwQkMsYUFBMUIsRUFBd0NDLFFBQXhDLEVBQWlEQyxTQUFqRCxFQUEyRDtBQUFDLFFBQU1DLFdBQVcsR0FBQyxDQUFDLEdBQUVwQixhQUFhLENBQUNxQixZQUFqQixFQUErQkosYUFBL0IsRUFBNkMsT0FBN0MsQ0FBbEI7QUFBd0UsUUFBTUssU0FBUyxHQUFDSCxTQUFTLEdBQUMsRUFBRCxHQUFJLENBQUMsR0FBRW5CLGFBQWEsQ0FBQ3FCLFlBQWpCLEVBQStCSixhQUEvQixFQUE2Q0MsUUFBN0MsQ0FBN0I7QUFBb0YsU0FBTTtBQUFDRSxlQUFEO0FBQWFFLGFBQWI7QUFBdUJDLFlBQVEsRUFBQyxDQUFDLEdBQUcsSUFBSTdHLEdBQUosQ0FBUSxDQUFDLEdBQUcwRyxXQUFKLEVBQWdCLEdBQUdFLFNBQW5CLENBQVIsQ0FBSjtBQUFoQyxHQUFOO0FBQW9GOztBQUFBLFNBQVNFLGtCQUFULENBQTRCQyxPQUE1QixFQUFvQ3BLLEtBQXBDLEVBQTBDO0FBQUM7QUFDcGpFO0FBQ0EsUUFBSztBQUFDcUssZUFBRDtBQUFhVCxpQkFBYjtBQUEyQlUsaUNBQTNCO0FBQXlEQztBQUF6RCxNQUFrRkgsT0FBdkY7QUFBK0YsU0FBT1IsYUFBYSxDQUFDWSxhQUFkLENBQTRCbkksTUFBNUIsQ0FBbUNvSSxRQUFRLElBQUVBLFFBQVEsQ0FBQ0MsUUFBVCxDQUFrQixLQUFsQixLQUEwQixDQUFDRCxRQUFRLENBQUNDLFFBQVQsQ0FBa0IsWUFBbEIsQ0FBeEUsRUFBeUd0SSxHQUF6RyxDQUE2R3FJLFFBQVEsSUFBRSxhQUFhckYsTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QixRQUE3QixFQUFzQztBQUFDcUosT0FBRyxFQUFDaUIsUUFBTDtBQUFjRSxTQUFLLEVBQUMsQ0FBQ0osdUJBQXJCO0FBQTZDSyxTQUFLLEVBQUM1SyxLQUFLLENBQUM0SyxLQUF6RDtBQUErREMsZUFBVyxFQUFDN0ssS0FBSyxDQUFDNkssV0FBTixJQUFtQkMsU0FBOUY7QUFBOEhqTCxZQUFRLEVBQUMsSUFBdkk7QUFBNElnRyxPQUFHLEVBQUUsR0FBRXdFLFdBQVksVUFBU0ksUUFBUyxHQUFFSCw2QkFBOEI7QUFBak4sR0FBdEMsQ0FBcEksQ0FBUDtBQUF3WTs7QUFBQSxTQUFTUyxpQkFBVCxDQUEyQlgsT0FBM0IsRUFBbUNwSyxLQUFuQyxFQUF5QztBQUFDLFFBQUs7QUFBQ2dMLGdCQUFEO0FBQWNUO0FBQWQsTUFBdUNILE9BQTVDO0FBQW9ELFNBQU0sQ0FBQ1ksWUFBWSxDQUFDbkQsaUJBQWIsSUFBZ0MsRUFBakMsRUFBcUN6RixHQUFyQyxDQUF5QzZJLElBQUksSUFBRTtBQUFDLFVBQUs7QUFBQ2pFO0FBQUQsUUFBMEJpRSxJQUEvQjtBQUFBLFVBQWtCQyxXQUFsQiw0QkFBK0JELElBQS9COztBQUFvQyxXQUFNLGFBQWE3RixNQUFNLENBQUNtQyxPQUFQLENBQWVwSCxhQUFmLENBQTZCLFFBQTdCLEVBQXNDdUcsTUFBTSxDQUFDeUUsTUFBUCxDQUFjLEVBQWQsRUFBaUJELFdBQWpCLEVBQTZCO0FBQUNQLFdBQUssRUFBQyxDQUFDSix1QkFBUjtBQUFnQ0ssV0FBSyxFQUFDNUssS0FBSyxDQUFDNEssS0FBNUM7QUFBa0RDLGlCQUFXLEVBQUM3SyxLQUFLLENBQUM2SyxXQUFOLElBQW1CQyxTQUErQk07QUFBaEgsS0FBN0IsQ0FBdEMsQ0FBbkI7QUFBMk0sR0FBL1IsQ0FBTjtBQUF3Uzs7QUFBQSxTQUFTQyxnQkFBVCxDQUEwQmpCLE9BQTFCLEVBQWtDcEssS0FBbEMsRUFBd0NzTCxLQUF4QyxFQUE4QztBQUFDLFFBQUs7QUFBQ0Msa0JBQUQ7QUFBZ0JsQixlQUFoQjtBQUE0Qm1CLGlCQUE1QjtBQUEwQ2xCLGlDQUExQztBQUF3RUM7QUFBeEUsTUFBaUdILE9BQXRHO0FBQThHLFNBQU9tQixjQUFjLENBQUNuSixHQUFmLENBQW1CNkksSUFBSSxJQUFFO0FBQUMsUUFBRyxDQUFDQSxJQUFJLENBQUNQLFFBQUwsQ0FBYyxLQUFkLENBQUQsSUFBdUJZLEtBQUssQ0FBQ3BCLFFBQU4sQ0FBZXRELFFBQWYsQ0FBd0JxRSxJQUF4QixDQUExQixFQUF3RCxPQUFPLElBQVA7QUFBWSxXQUFNLGFBQWE3RixNQUFNLENBQUNtQyxPQUFQLENBQWVwSCxhQUFmLENBQTZCLFFBQTdCLEVBQXNDO0FBQUNzTCxXQUFLLEVBQUMsQ0FBQ0QsYUFBRCxJQUFnQmpCLHVCQUF2QjtBQUErQ0ksV0FBSyxFQUFDLENBQUNKLHVCQUF0RDtBQUE4RWYsU0FBRyxFQUFDeUIsSUFBbEY7QUFBdUZwRixTQUFHLEVBQUUsR0FBRXdFLFdBQVksVUFBU3FCLFNBQVMsQ0FBQ1QsSUFBRCxDQUFPLEdBQUVYLDZCQUE4QixFQUFuSztBQUFxS00sV0FBSyxFQUFDNUssS0FBSyxDQUFDNEssS0FBakw7QUFBdUxDLGlCQUFXLEVBQUM3SyxLQUFLLENBQUM2SyxXQUFOLElBQW1CQyxTQUErQk07QUFBclAsS0FBdEMsQ0FBbkI7QUFBa1QsR0FBaFosQ0FBUDtBQUEwWjs7QUFBQSxTQUFTTyxVQUFULENBQW9CdkIsT0FBcEIsRUFBNEJwSyxLQUE1QixFQUFrQ3NMLEtBQWxDLEVBQXdDO0FBQUMsTUFBSU0scUJBQUo7O0FBQTBCLFFBQUs7QUFBQ3ZCLGVBQUQ7QUFBYVQsaUJBQWI7QUFBMkI0QixpQkFBM0I7QUFBeUNsQixpQ0FBekM7QUFBdUVDO0FBQXZFLE1BQWdHSCxPQUFyRztBQUE2RyxRQUFNeUIsYUFBYSxHQUFDUCxLQUFLLENBQUNwQixRQUFOLENBQWU3SCxNQUFmLENBQXNCNEksSUFBSSxJQUFFQSxJQUFJLENBQUNQLFFBQUwsQ0FBYyxLQUFkLENBQTVCLENBQXBCO0FBQXNFLFFBQU1vQixrQkFBa0IsR0FBQyxDQUFDRixxQkFBcUIsR0FBQ2hDLGFBQWEsQ0FBQ21DLGdCQUFyQyxLQUF3RCxJQUF4RCxHQUE2RCxLQUFLLENBQWxFLEdBQW9FSCxxQkFBcUIsQ0FBQ3ZKLE1BQXRCLENBQTZCNEksSUFBSSxJQUFFQSxJQUFJLENBQUNQLFFBQUwsQ0FBYyxLQUFkLENBQW5DLENBQTdGO0FBQXNKLFNBQU0sQ0FBQyxHQUFHbUIsYUFBSixFQUFrQixHQUFHQyxrQkFBckIsRUFBeUMxSixHQUF6QyxDQUE2QzZJLElBQUksSUFBRTtBQUFDLFdBQU0sYUFBYTdGLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkIsUUFBN0IsRUFBc0M7QUFBQ3FKLFNBQUcsRUFBQ3lCLElBQUw7QUFBVXBGLFNBQUcsRUFBRSxHQUFFd0UsV0FBWSxVQUFTcUIsU0FBUyxDQUFDVCxJQUFELENBQU8sR0FBRVgsNkJBQThCLEVBQXRGO0FBQXdGTSxXQUFLLEVBQUM1SyxLQUFLLENBQUM0SyxLQUFwRztBQUEwR2EsV0FBSyxFQUFDLENBQUNELGFBQUQsSUFBZ0JqQix1QkFBaEk7QUFBd0pJLFdBQUssRUFBQyxDQUFDSix1QkFBL0o7QUFBdUxNLGlCQUFXLEVBQUM3SyxLQUFLLENBQUM2SyxXQUFOLElBQW1CQyxTQUErQk07QUFBclAsS0FBdEMsQ0FBbkI7QUFBa1QsR0FBdFcsQ0FBTjtBQUErVztBQUFBO0FBQy9wRTtBQUNBO0FBQ0E7OztBQUFHLE1BQU1ZLFFBQU4sU0FBdUI1RyxNQUFNLENBQUM2RyxTQUE5QixDQUF1QztBQUFDO0FBQzNDO0FBQ0E7QUFDQTtBQUFLLGVBQWFDLGVBQWIsQ0FBNkJDLEdBQTdCLEVBQWlDO0FBQUMsVUFBTUMsVUFBVSxHQUFDQyxHQUFHLElBQUU7QUFBQyxhQUFPck0sS0FBSyxJQUFFLGFBQWFvRixNQUFNLENBQUNtQyxPQUFQLENBQWVwSCxhQUFmLENBQTZCa00sR0FBN0IsRUFBaUNyTSxLQUFqQyxDQUEzQjtBQUFvRSxLQUEzRjs7QUFBNEYsVUFBSztBQUFDc00sVUFBRDtBQUFNL0k7QUFBTixRQUFZLE1BQU00SSxHQUFHLENBQUNJLFVBQUosQ0FBZTtBQUFDSDtBQUFELEtBQWYsQ0FBdkI7QUFBb0QsVUFBTUksTUFBTSxHQUFDLENBQUMsR0FBRyxDQUFDLEdBQUVwRSxPQUFPLENBQUNiLE9BQVgsR0FBSixDQUFiO0FBQXdDLFdBQU07QUFBQytFLFVBQUQ7QUFBTS9JLFVBQU47QUFBV2lKO0FBQVgsS0FBTjtBQUEwQjs7QUFBQSxTQUFPQyxjQUFQLENBQXNCQyxpQkFBdEIsRUFBd0MxTSxLQUF4QyxFQUE4QztBQUFDLFdBQU0sYUFBYW9GLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkJtSSxnQkFBZ0IsQ0FBQ0UsZUFBakIsQ0FBaUNtRSxRQUE5RCxFQUF1RTtBQUFDbEcsV0FBSyxFQUFDekc7QUFBUCxLQUF2RSxFQUFxRixhQUFhb0YsTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QnVNLGlCQUE3QixFQUErQzFNLEtBQS9DLENBQWxHLENBQW5CO0FBQTZLOztBQUFBNE0sUUFBTSxHQUFFO0FBQUMsV0FBTSxhQUFheEgsTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QjZILElBQTdCLEVBQWtDLElBQWxDLEVBQXVDLGFBQWE1QyxNQUFNLENBQUNtQyxPQUFQLENBQWVwSCxhQUFmLENBQTZCME0sSUFBN0IsRUFBa0MsSUFBbEMsQ0FBcEQsRUFBNEYsYUFBYXpILE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkIsTUFBN0IsRUFBb0MsSUFBcEMsRUFBeUMsYUFBYWlGLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkI4SCxJQUE3QixFQUFrQyxJQUFsQyxDQUF0RCxFQUE4RixhQUFhN0MsTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QjJNLFVBQTdCLEVBQXdDLElBQXhDLENBQTNHLENBQXpHLENBQW5CO0FBQXdSOztBQUg1c0I7O0FBRzZzQnhOLGVBQUEsR0FBZ0IwTSxRQUFoQjs7QUFBeUIsU0FBU2hFLElBQVQsQ0FBY2hJLEtBQWQsRUFBb0I7QUFBQyxRQUFLO0FBQUM4SixhQUFEO0FBQVdpRCx5QkFBWDtBQUFpQ0M7QUFBakMsTUFBeUMsQ0FBQyxHQUFFNUgsTUFBTSxDQUFDc0MsVUFBVixFQUFzQlksZ0JBQWdCLENBQUNFLGVBQXZDLENBQTlDO0FBQXNHdUUsdUJBQXFCLENBQUMvRSxJQUF0QixHQUEyQixJQUEzQjtBQUFnQyxTQUFNLGFBQWE1QyxNQUFNLENBQUNtQyxPQUFQLENBQWVwSCxhQUFmLENBQTZCLE1BQTdCLEVBQW9DdUcsTUFBTSxDQUFDeUUsTUFBUCxDQUFjLEVBQWQsRUFBaUJuTCxLQUFqQixFQUF1QjtBQUFDaU4sUUFBSSxFQUFDak4sS0FBSyxDQUFDaU4sSUFBTixJQUFZRCxNQUFaLElBQW9CMU0sU0FBMUI7QUFBb0M0TSxPQUFHLEVBQUNwRCxTQUFTLEdBQUMsRUFBRCxHQUFJeEosU0FBckQ7QUFBK0QsdUJBQWtCd0osU0FBUyxRQUFULEdBQStDLEVBQS9DLEdBQWtEeEo7QUFBbkksR0FBdkIsQ0FBcEMsQ0FBbkI7QUFBK047O0FBQUEsTUFBTXVNLElBQU4sU0FBbUJ6SCxNQUFNLENBQUM2RyxTQUExQixDQUFtQztBQUFDa0IsYUFBVyxDQUFDLEdBQUdDLElBQUosRUFBUztBQUFDLFVBQU0sR0FBR0EsSUFBVDtBQUFlLFNBQUtoRCxPQUFMLEdBQWEsS0FBSyxDQUFsQjtBQUFxQjs7QUFBQWlELGFBQVcsQ0FBQy9CLEtBQUQsRUFBTztBQUFDLFVBQUs7QUFBQ2pCLGlCQUFEO0FBQWFDLG1DQUFiO0FBQTJDaUI7QUFBM0MsUUFBMkQsS0FBS25CLE9BQXJFO0FBQTZFLFVBQU1rRCxRQUFRLEdBQUNoQyxLQUFLLENBQUNwQixRQUFOLENBQWU3SCxNQUFmLENBQXNCa0wsQ0FBQyxJQUFFQSxDQUFDLENBQUM3QyxRQUFGLENBQVcsTUFBWCxDQUF6QixDQUFmO0FBQTRELFVBQU1YLFdBQVcsR0FBQyxJQUFJMUcsR0FBSixDQUFRaUksS0FBSyxDQUFDdkIsV0FBZCxDQUFsQixDQUExSSxDQUF1TDtBQUNoN0M7O0FBQ0EsUUFBSXlELGFBQWEsR0FBQyxJQUFJbkssR0FBSixDQUFRLEVBQVIsQ0FBbEI7QUFBOEIsUUFBSW9LLGVBQWUsR0FBQzFNLEtBQUssQ0FBQzJNLElBQU4sQ0FBVyxJQUFJckssR0FBSixDQUFRa0ksY0FBYyxDQUFDbEosTUFBZixDQUFzQjRJLElBQUksSUFBRUEsSUFBSSxDQUFDUCxRQUFMLENBQWMsTUFBZCxDQUE1QixDQUFSLENBQVgsQ0FBcEI7O0FBQTRGLFFBQUcrQyxlQUFlLENBQUNoTCxNQUFuQixFQUEwQjtBQUFDLFlBQU1rTCxRQUFRLEdBQUMsSUFBSXRLLEdBQUosQ0FBUWlLLFFBQVIsQ0FBZjtBQUFpQ0cscUJBQWUsR0FBQ0EsZUFBZSxDQUFDcEwsTUFBaEIsQ0FBdUJrTCxDQUFDLElBQUUsRUFBRUksUUFBUSxDQUFDMUgsR0FBVCxDQUFhc0gsQ0FBYixLQUFpQnhELFdBQVcsQ0FBQzlELEdBQVosQ0FBZ0JzSCxDQUFoQixDQUFuQixDQUExQixDQUFoQjtBQUFrRkMsbUJBQWEsR0FBQyxJQUFJbkssR0FBSixDQUFRb0ssZUFBUixDQUFkO0FBQXVDSCxjQUFRLENBQUNwTCxJQUFULENBQWMsR0FBR3VMLGVBQWpCO0FBQW1DOztBQUFBLFFBQUlHLGVBQWUsR0FBQyxFQUFwQjtBQUF1Qk4sWUFBUSxDQUFDekssT0FBVCxDQUFpQm9JLElBQUksSUFBRTtBQUFDLFlBQU00QyxZQUFZLEdBQUM5RCxXQUFXLENBQUM5RCxHQUFaLENBQWdCZ0YsSUFBaEIsQ0FBbkI7O0FBQXlDLFVBQUcsSUFBSCxFQUFvQztBQUFDMkMsdUJBQWUsQ0FBQzFMLElBQWhCLEVBQXFCLGFBQWFrRCxNQUFNLENBQUNtQyxPQUFQLENBQWVwSCxhQUFmLENBQTZCLE1BQTdCLEVBQW9DO0FBQUNxSixhQUFHLEVBQUUsR0FBRXlCLElBQUssVUFBYjtBQUF1QkwsZUFBSyxFQUFDLEtBQUs1SyxLQUFMLENBQVc0SyxLQUF4QztBQUE4Q2tELGFBQUcsRUFBQyxTQUFsRDtBQUE0RGhLLGNBQUksRUFBRSxHQUFFdUcsV0FBWSxVQUFTcUIsU0FBUyxDQUFDVCxJQUFELENBQU8sR0FBRVgsNkJBQThCLEVBQXpJO0FBQTJJeUQsWUFBRSxFQUFDLE9BQTlJO0FBQXNKbEQscUJBQVcsRUFBQyxLQUFLN0ssS0FBTCxDQUFXNkssV0FBWCxJQUF3QkMsU0FBK0JNO0FBQXpOLFNBQXBDLENBQWxDO0FBQW9TOztBQUFBLFlBQU00QyxlQUFlLEdBQUNSLGFBQWEsQ0FBQ3ZILEdBQWQsQ0FBa0JnRixJQUFsQixDQUF0QjtBQUE4QzJDLHFCQUFlLENBQUMxTCxJQUFoQixFQUFxQixhQUFha0QsTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QixNQUE3QixFQUFvQztBQUFDcUosV0FBRyxFQUFDeUIsSUFBTDtBQUFVTCxhQUFLLEVBQUMsS0FBSzVLLEtBQUwsQ0FBVzRLLEtBQTNCO0FBQWlDa0QsV0FBRyxFQUFDLFlBQXJDO0FBQWtEaEssWUFBSSxFQUFFLEdBQUV1RyxXQUFZLFVBQVNxQixTQUFTLENBQUNULElBQUQsQ0FBTyxHQUFFWCw2QkFBOEIsRUFBL0g7QUFBaUlPLG1CQUFXLEVBQUMsS0FBSzdLLEtBQUwsQ0FBVzZLLFdBQVgsSUFBd0JDLFNBQXJLO0FBQXFNLG9CQUFXa0QsZUFBZSxHQUFDMU4sU0FBRCxHQUFXdU4sWUFBWSxHQUFDLEVBQUQsR0FBSXZOLFNBQTFQO0FBQW9RLG9CQUFXME4sZUFBZSxHQUFDMU4sU0FBRCxHQUFXdU4sWUFBWSxHQUFDdk4sU0FBRCxHQUFXO0FBQWhVLE9BQXBDLENBQWxDO0FBQTZZLEtBQXIwQjs7QUFBdTBCLFFBQUcsS0FBSCxFQUEyRSxFQUE0RDs7QUFBQSxXQUFPc04sZUFBZSxDQUFDbkwsTUFBaEIsS0FBeUIsQ0FBekIsR0FBMkIsSUFBM0IsR0FBZ0NtTCxlQUF2QztBQUF3RDs7QUFBQUsseUJBQXVCLEdBQUU7QUFBQyxVQUFLO0FBQUMxQyxvQkFBRDtBQUFnQmxCLGlCQUFoQjtBQUE0QkM7QUFBNUIsUUFBMkQsS0FBS0YsT0FBckU7QUFBNkUsV0FBT21CLGNBQWMsQ0FBQ25KLEdBQWYsQ0FBbUI2SSxJQUFJLElBQUU7QUFBQyxVQUFHLENBQUNBLElBQUksQ0FBQ1AsUUFBTCxDQUFjLEtBQWQsQ0FBSixFQUF5QjtBQUFDLGVBQU8sSUFBUDtBQUFhOztBQUFBLGFBQU0sYUFBYXRGLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkIsTUFBN0IsRUFBb0M7QUFBQzJOLFdBQUcsRUFBQyxTQUFMO0FBQWV0RSxXQUFHLEVBQUN5QixJQUFuQjtBQUF3Qm5ILFlBQUksRUFBRSxHQUFFdUcsV0FBWSxVQUFTcUIsU0FBUyxDQUFDVCxJQUFELENBQU8sR0FBRVgsNkJBQThCLEVBQXJHO0FBQXVHeUQsVUFBRSxFQUFDLFFBQTFHO0FBQW1IbkQsYUFBSyxFQUFDLEtBQUs1SyxLQUFMLENBQVc0SyxLQUFwSTtBQUEwSUMsbUJBQVcsRUFBQyxLQUFLN0ssS0FBTCxDQUFXNkssV0FBWCxJQUF3QkMsU0FBK0JNO0FBQTdNLE9BQXBDLENBQW5CO0FBQXdRLEtBQXpVLEVBQTBVO0FBQTFVLEtBQzU5Qy9JLE1BRDQ5QyxDQUNyOUM2TCxPQURxOUMsQ0FBUDtBQUNwOEM7O0FBQUFDLHFCQUFtQixDQUFDN0MsS0FBRCxFQUFPO0FBQUMsVUFBSztBQUFDakIsaUJBQUQ7QUFBYUMsbUNBQWI7QUFBMkNVO0FBQTNDLFFBQXlELEtBQUtaLE9BQW5FO0FBQTJFLFVBQU1nRSxZQUFZLEdBQUM5QyxLQUFLLENBQUNwQixRQUFOLENBQWU3SCxNQUFmLENBQXNCNEksSUFBSSxJQUFFO0FBQUMsYUFBT0EsSUFBSSxDQUFDUCxRQUFMLENBQWMsS0FBZCxDQUFQO0FBQTZCLEtBQTFELENBQW5CO0FBQStFLFdBQU0sQ0FBQyxHQUFHLENBQUNNLFlBQVksQ0FBQ25ELGlCQUFiLElBQWdDLEVBQWpDLEVBQXFDekYsR0FBckMsQ0FBeUM2SSxJQUFJLElBQUUsYUFBYTdGLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkIsTUFBN0IsRUFBb0M7QUFBQ3FKLFNBQUcsRUFBQ3lCLElBQUksQ0FBQ3BGLEdBQVY7QUFBYytFLFdBQUssRUFBQyxLQUFLNUssS0FBTCxDQUFXNEssS0FBL0I7QUFBcUNrRCxTQUFHLEVBQUMsU0FBekM7QUFBbURoSyxVQUFJLEVBQUNtSCxJQUFJLENBQUNwRixHQUE3RDtBQUFpRWtJLFFBQUUsRUFBQyxRQUFwRTtBQUE2RWxELGlCQUFXLEVBQUMsS0FBSzdLLEtBQUwsQ0FBVzZLLFdBQVgsSUFBd0JDLFNBQStCTTtBQUFoSixLQUFwQyxDQUE1RCxDQUFKLEVBQXdQLEdBQUdnRCxZQUFZLENBQUNoTSxHQUFiLENBQWlCNkksSUFBSSxJQUFFLGFBQWE3RixNQUFNLENBQUNtQyxPQUFQLENBQWVwSCxhQUFmLENBQTZCLE1BQTdCLEVBQW9DO0FBQUNxSixTQUFHLEVBQUN5QixJQUFMO0FBQVVMLFdBQUssRUFBQyxLQUFLNUssS0FBTCxDQUFXNEssS0FBM0I7QUFBaUNrRCxTQUFHLEVBQUMsU0FBckM7QUFBK0NoSyxVQUFJLEVBQUUsR0FBRXVHLFdBQVksVUFBU3FCLFNBQVMsQ0FBQ1QsSUFBRCxDQUFPLEdBQUVYLDZCQUE4QixFQUE1SDtBQUE4SHlELFFBQUUsRUFBQyxRQUFqSTtBQUEwSWxELGlCQUFXLEVBQUMsS0FBSzdLLEtBQUwsQ0FBVzZLLFdBQVgsSUFBd0JDLFNBQStCTTtBQUE3TSxLQUFwQyxDQUFwQyxDQUEzUCxDQUFOO0FBQTRoQjs7QUFBQUMsa0JBQWdCLENBQUNDLEtBQUQsRUFBTztBQUFDLFdBQU9ELGdCQUFnQixDQUFDLEtBQUtqQixPQUFOLEVBQWMsS0FBS3BLLEtBQW5CLEVBQXlCc0wsS0FBekIsQ0FBdkI7QUFBd0Q7O0FBQUFQLG1CQUFpQixHQUFFO0FBQUMsV0FBT0EsaUJBQWlCLENBQUMsS0FBS1gsT0FBTixFQUFjLEtBQUtwSyxLQUFuQixDQUF4QjtBQUFtRDs7QUFBQTJMLFlBQVUsQ0FBQ0wsS0FBRCxFQUFPO0FBQUMsV0FBT0ssVUFBVSxDQUFDLEtBQUt2QixPQUFOLEVBQWMsS0FBS3BLLEtBQW5CLEVBQXlCc0wsS0FBekIsQ0FBakI7QUFBa0Q7O0FBQUFuQixvQkFBa0IsR0FBRTtBQUFDLFdBQU9BLGtCQUFrQixDQUFDLEtBQUtDLE9BQU4sRUFBYyxLQUFLcEssS0FBbkIsQ0FBekI7QUFBb0Q7O0FBQUFxTyxpQ0FBK0IsQ0FBQzNOLFFBQUQsRUFBVTtBQUFDLFVBQUs7QUFBQ3NLO0FBQUQsUUFBZSxLQUFLWixPQUF6QjtBQUFpQyxVQUFNaEQsaUJBQWlCLEdBQUMsRUFBeEI7QUFBMkIsVUFBTWtILGdCQUFnQixHQUFDLEVBQXZCOztBQUEwQmxKLFVBQU0sQ0FBQ21DLE9BQVAsQ0FBZWdILFFBQWYsQ0FBd0IxTCxPQUF4QixDQUFnQ25DLFFBQWhDLEVBQXlDOE4sS0FBSyxJQUFFO0FBQUMsVUFBR0EsS0FBSyxDQUFDek8sSUFBTixLQUFhK0ksT0FBTyxDQUFDdkIsT0FBeEIsRUFBZ0M7QUFBQyxZQUFHaUgsS0FBSyxDQUFDeE8sS0FBTixDQUFZZ0gsUUFBWixLQUF1QixtQkFBMUIsRUFBOEM7QUFBQ2dFLHNCQUFZLENBQUNuRCxpQkFBYixHQUErQixDQUFDbUQsWUFBWSxDQUFDbkQsaUJBQWIsSUFBZ0MsRUFBakMsRUFBcUNDLE1BQXJDLENBQTRDLG1CQUFLMEcsS0FBSyxDQUFDeE8sS0FBWCxFQUE1QyxDQUEvQjtBQUErRjtBQUFRLFNBQXRKLE1BQTJKLElBQUcsQ0FBQyxZQUFELEVBQWMsa0JBQWQsRUFBa0M0RyxRQUFsQyxDQUEyQzRILEtBQUssQ0FBQ3hPLEtBQU4sQ0FBWWdILFFBQXZELENBQUgsRUFBb0U7QUFBQ0ksMkJBQWlCLENBQUNsRixJQUFsQixDQUF1QnNNLEtBQUssQ0FBQ3hPLEtBQTdCO0FBQW9DO0FBQVE7QUFBQzs7QUFBQXNPLHNCQUFnQixDQUFDcE0sSUFBakIsQ0FBc0JzTSxLQUF0QjtBQUE4QixLQUE3WDs7QUFBK1gsU0FBS3BFLE9BQUwsQ0FBYXFFLGFBQWIsQ0FBMkJ6RCxZQUEzQixHQUF3QzVELGlCQUF4QztBQUEwRCxXQUFPa0gsZ0JBQVA7QUFBeUI7O0FBQUFJLHFCQUFtQixDQUFDQyxJQUFELEVBQU07QUFBQyxXQUFPdkosTUFBTSxDQUFDbUMsT0FBUCxDQUFlZ0gsUUFBZixDQUF3Qm5NLEdBQXhCLENBQTRCdU0sSUFBNUIsRUFBaUNDLENBQUMsSUFBRTtBQUFDLFVBQUdBLENBQUMsQ0FBQzdPLElBQUYsS0FBUyxNQUFULElBQWlCNk8sQ0FBQyxDQUFDNU8sS0FBRixDQUFRLE1BQVIsQ0FBakIsSUFBa0NxSSxVQUFVLENBQUN3Ryx3QkFBWCxDQUFvQ0MsSUFBcEMsQ0FBeUMsQ0FBQztBQUFDQztBQUFELE9BQUQsS0FBU0gsQ0FBQyxDQUFDNU8sS0FBRixDQUFRLE1BQVIsRUFBZ0JnUCxVQUFoQixDQUEyQkQsR0FBM0IsQ0FBbEQsQ0FBckMsRUFBd0g7QUFBQyxjQUFNRSxRQUFRLHFCQUFNTCxDQUFDLENBQUM1TyxLQUFGLElBQVMsRUFBZixDQUFkOztBQUFrQ2lQLGdCQUFRLENBQUMsV0FBRCxDQUFSLEdBQXNCQSxRQUFRLENBQUMsTUFBRCxDQUE5QjtBQUF1Q0EsZ0JBQVEsQ0FBQyxNQUFELENBQVIsR0FBaUIzTyxTQUFqQjtBQUEyQixlQUFNLGFBQWE4RSxNQUFNLENBQUNtQyxPQUFQLENBQWUySCxZQUFmLENBQTRCTixDQUE1QixFQUE4QkssUUFBOUIsQ0FBbkI7QUFBNEQsT0FBelIsTUFBOFIsSUFBR0wsQ0FBQyxDQUFDNU8sS0FBRixJQUFTNE8sQ0FBQyxDQUFDNU8sS0FBRixDQUFRLFVBQVIsQ0FBWixFQUFnQztBQUFDNE8sU0FBQyxDQUFDNU8sS0FBRixDQUFRLFVBQVIsSUFBb0IsS0FBSzBPLG1CQUFMLENBQXlCRSxDQUFDLENBQUM1TyxLQUFGLENBQVEsVUFBUixDQUF6QixDQUFwQjtBQUFtRTs7QUFBQSxhQUFPNE8sQ0FBUDtBQUFVLEtBQWpiLENBQVA7QUFBMmI7O0FBQUFoQyxRQUFNLEdBQUU7QUFBQyxRQUFJdUMsaUJBQUosRUFBc0JDLGtCQUF0Qjs7QUFBeUMsVUFBSztBQUFDNUMsWUFBRDtBQUFRNkMsYUFBUjtBQUFnQnZGLGVBQWhCO0FBQTBCd0YsZUFBMUI7QUFBb0NDLG1CQUFwQztBQUFrRGQsbUJBQWxEO0FBQWdFZSxxQkFBaEU7QUFBZ0ZDLGNBQWhGO0FBQXlGQyx3QkFBekY7QUFBNEdDLHdCQUE1RztBQUErSHBGO0FBQS9ILFFBQXdKLEtBQUtILE9BQWxLO0FBQTBLLFVBQU13RixnQkFBZ0IsR0FBQ0Ysa0JBQWtCLEtBQUcsS0FBNUM7QUFBa0QsVUFBTUcsZ0JBQWdCLEdBQUNGLGtCQUFrQixLQUFHLEtBQXJCLElBQTRCLENBQUNwRix1QkFBcEQ7QUFBNEUsU0FBS0gsT0FBTCxDQUFhMkMscUJBQWIsQ0FBbUNGLElBQW5DLEdBQXdDLElBQXhDO0FBQTZDLFFBQUc7QUFBQ3RKO0FBQUQsUUFBTyxLQUFLNkcsT0FBZjtBQUF1QixRQUFJMEYsV0FBVyxHQUFDLEVBQWhCO0FBQW1CLFFBQUlDLGlCQUFpQixHQUFDLEVBQXRCOztBQUF5QixRQUFHeE0sSUFBSCxFQUFRO0FBQUNBLFVBQUksQ0FBQ1YsT0FBTCxDQUFhK0wsQ0FBQyxJQUFFO0FBQUMsWUFBR0EsQ0FBQyxJQUFFQSxDQUFDLENBQUM3TyxJQUFGLEtBQVMsTUFBWixJQUFvQjZPLENBQUMsQ0FBQzVPLEtBQUYsQ0FBUSxLQUFSLE1BQWlCLFNBQXJDLElBQWdENE8sQ0FBQyxDQUFDNU8sS0FBRixDQUFRLElBQVIsTUFBZ0IsT0FBbkUsRUFBMkU7QUFBQzhQLHFCQUFXLENBQUM1TixJQUFaLENBQWlCME0sQ0FBakI7QUFBcUIsU0FBakcsTUFBcUc7QUFBQ0EsV0FBQyxJQUFFbUIsaUJBQWlCLENBQUM3TixJQUFsQixDQUF1QjBNLENBQXZCLENBQUg7QUFBOEI7QUFBQyxPQUF0SjtBQUF3SnJMLFVBQUksR0FBQ3VNLFdBQVcsQ0FBQ2hJLE1BQVosQ0FBbUJpSSxpQkFBbkIsQ0FBTDtBQUE0Qzs7QUFBQSxRQUFJclAsUUFBUSxHQUFDMEUsTUFBTSxDQUFDbUMsT0FBUCxDQUFlZ0gsUUFBZixDQUF3QnlCLE9BQXhCLENBQWdDLEtBQUtoUSxLQUFMLENBQVdVLFFBQTNDLEVBQXFEMkIsTUFBckQsQ0FBNEQ2TCxPQUE1RCxDQUFiLENBQS9vQixDQUFpdUI7OztBQUN2eEYsY0FBdUM7QUFBQ3hOLGNBQVEsR0FBQzBFLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZWdILFFBQWYsQ0FBd0JuTSxHQUF4QixDQUE0QjFCLFFBQTVCLEVBQXFDOE4sS0FBSyxJQUFFO0FBQUMsWUFBSXlCLFlBQUo7O0FBQWlCLGNBQU1DLGFBQWEsR0FBQzFCLEtBQUssSUFBRSxJQUFQLEdBQVksS0FBSyxDQUFqQixHQUFtQixDQUFDeUIsWUFBWSxHQUFDekIsS0FBSyxDQUFDeE8sS0FBcEIsS0FBNEIsSUFBNUIsR0FBaUMsS0FBSyxDQUF0QyxHQUF3Q2lRLFlBQVksQ0FBQyxtQkFBRCxDQUEzRjs7QUFBaUgsWUFBRyxDQUFDQyxhQUFKLEVBQWtCO0FBQUMsY0FBSUMsYUFBSjs7QUFBa0IsY0FBRyxDQUFDM0IsS0FBSyxJQUFFLElBQVAsR0FBWSxLQUFLLENBQWpCLEdBQW1CQSxLQUFLLENBQUN6TyxJQUExQixNQUFrQyxPQUFyQyxFQUE2QztBQUFDeUIsbUJBQU8sQ0FBQzRPLElBQVIsQ0FBYSxrSEFBYjtBQUFrSSxXQUFoTCxNQUFxTCxJQUFHLENBQUM1QixLQUFLLElBQUUsSUFBUCxHQUFZLEtBQUssQ0FBakIsR0FBbUJBLEtBQUssQ0FBQ3pPLElBQTFCLE1BQWtDLE1BQWxDLElBQTBDLENBQUN5TyxLQUFLLElBQUUsSUFBUCxHQUFZLEtBQUssQ0FBakIsR0FBbUIsQ0FBQzJCLGFBQWEsR0FBQzNCLEtBQUssQ0FBQ3hPLEtBQXJCLEtBQTZCLElBQTdCLEdBQWtDLEtBQUssQ0FBdkMsR0FBeUNtUSxhQUFhLENBQUNFLElBQTNFLE1BQW1GLFVBQWhJLEVBQTJJO0FBQUM3TyxtQkFBTyxDQUFDNE8sSUFBUixDQUFhLHFJQUFiO0FBQXFKO0FBQUM7O0FBQUEsZUFBTzVCLEtBQVA7QUFBYyxPQUF6ckIsQ0FBVDtBQUFvc0IsVUFBRyxLQUFLeE8sS0FBTCxDQUFXNkssV0FBZCxFQUEwQnJKLE9BQU8sQ0FBQzRPLElBQVIsQ0FBYSxvSEFBYjtBQUFvSTs7QUFBQSxRQUFHLEtBQUgsRUFBdUYsRUFBOEM7O0FBQUExUCxZQUFRLEdBQUMsS0FBSzJOLCtCQUFMLENBQXFDM04sUUFBckMsQ0FBVDtBQUF3RCxRQUFJNFAsYUFBYSxHQUFDLEtBQWxCO0FBQXdCLFFBQUlDLGVBQWUsR0FBQyxLQUFwQixDQUR1OUIsQ0FDNzdCOztBQUN6bkNoTixRQUFJLEdBQUM2QixNQUFNLENBQUNtQyxPQUFQLENBQWVnSCxRQUFmLENBQXdCbk0sR0FBeEIsQ0FBNEJtQixJQUFJLElBQUUsRUFBbEMsRUFBcUNpTCxLQUFLLElBQUU7QUFBQyxVQUFHLENBQUNBLEtBQUosRUFBVSxPQUFPQSxLQUFQO0FBQWEsWUFBSztBQUFDek8sWUFBRDtBQUFNQztBQUFOLFVBQWF3TyxLQUFsQjs7QUFBd0IsVUFBRzFFLFNBQUgsRUFBYTtBQUFDLFlBQUkwRyxPQUFPLEdBQUMsRUFBWjs7QUFBZSxZQUFHelEsSUFBSSxLQUFHLE1BQVAsSUFBZUMsS0FBSyxDQUFDcVEsSUFBTixLQUFhLFVBQS9CLEVBQTBDO0FBQUNHLGlCQUFPLEdBQUMsaUJBQVI7QUFBMkIsU0FBdEUsTUFBMkUsSUFBR3pRLElBQUksS0FBRyxNQUFQLElBQWVDLEtBQUssQ0FBQzhOLEdBQU4sS0FBWSxXQUE5QixFQUEwQztBQUFDeUMseUJBQWUsR0FBQyxJQUFoQjtBQUFzQixTQUFqRSxNQUFzRSxJQUFHeFEsSUFBSSxLQUFHLFFBQVYsRUFBbUI7QUFBQztBQUNuUztBQUNBO0FBQ0E7QUFDQSxjQUFHQyxLQUFLLENBQUM2RixHQUFOLElBQVc3RixLQUFLLENBQUM2RixHQUFOLENBQVU0SyxPQUFWLENBQWtCLFlBQWxCLElBQWdDLENBQUMsQ0FBNUMsSUFBK0N6USxLQUFLLENBQUNXLHVCQUFOLEtBQWdDLENBQUNYLEtBQUssQ0FBQ0QsSUFBUCxJQUFhQyxLQUFLLENBQUNELElBQU4sS0FBYSxpQkFBMUQsQ0FBbEQsRUFBK0g7QUFBQ3lRLG1CQUFPLEdBQUMsU0FBUjtBQUFrQjlKLGtCQUFNLENBQUNnSyxJQUFQLENBQVkxUSxLQUFaLEVBQW1CNkMsT0FBbkIsQ0FBMkI4TixJQUFJLElBQUU7QUFBQ0gscUJBQU8sSUFBRyxJQUFHRyxJQUFLLEtBQUkzUSxLQUFLLENBQUMyUSxJQUFELENBQU8sR0FBbEM7QUFBc0MsYUFBeEU7QUFBMEVILG1CQUFPLElBQUUsSUFBVDtBQUFlO0FBQUM7O0FBQUEsWUFBR0EsT0FBSCxFQUFXO0FBQUNoUCxpQkFBTyxDQUFDNE8sSUFBUixDQUFjLDhCQUE2QjVCLEtBQUssQ0FBQ3pPLElBQUssMkJBQTBCeVEsT0FBUSxPQUFNL0IsYUFBYSxDQUFDbUMsSUFBSyx3REFBakg7QUFBMEssaUJBQU8sSUFBUDtBQUFhO0FBQUMsT0FKL1UsTUFJbVY7QUFBQztBQUNyYixZQUFHN1EsSUFBSSxLQUFHLE1BQVAsSUFBZUMsS0FBSyxDQUFDOE4sR0FBTixLQUFZLFNBQTlCLEVBQXdDO0FBQUN3Qyx1QkFBYSxHQUFDLElBQWQ7QUFBb0I7QUFBQzs7QUFBQSxhQUFPOUIsS0FBUDtBQUFjLEtBTHZFLENBQUwsQ0FGc2pFLENBT3grRDs7QUFDOUUsVUFBTXFDLFNBQVMsR0FBQzlQLEtBQUssQ0FBQ0MsT0FBTixDQUFjd0wsTUFBZCxJQUFzQkEsTUFBdEIsR0FBNkIsRUFBN0M7O0FBQWdELFFBQUcxQyxTQUFTLElBQUUwQyxNQUFYLElBQW1CO0FBQ3RFQSxVQUFNLENBQUN4TSxLQUQ0QyxJQUNyQztBQUNkZSxTQUFLLENBQUNDLE9BQU4sQ0FBY3dMLE1BQU0sQ0FBQ3hNLEtBQVAsQ0FBYVUsUUFBM0IsQ0FGZ0QsRUFFWDtBQUFDLFlBQU1vUSxTQUFTLEdBQUM3USxFQUFFLElBQUU7QUFBQyxZQUFJOFEsU0FBSixFQUFjQyxxQkFBZDs7QUFBb0MsZUFBTy9RLEVBQUUsSUFBRSxJQUFKLEdBQVMsS0FBSyxDQUFkLEdBQWdCLENBQUM4USxTQUFTLEdBQUM5USxFQUFFLENBQUNELEtBQWQsS0FBc0IsSUFBdEIsR0FBMkIsS0FBSyxDQUFoQyxHQUFrQyxDQUFDZ1IscUJBQXFCLEdBQUNELFNBQVMsQ0FBQ3BRLHVCQUFqQyxLQUEyRCxJQUEzRCxHQUFnRSxLQUFLLENBQXJFLEdBQXVFcVEscUJBQXFCLENBQUNuUSxNQUF0SjtBQUE4SixPQUF2TixDQUFELENBQXlOOzs7QUFDOVAyTCxZQUFNLENBQUN4TSxLQUFQLENBQWFVLFFBQWIsQ0FBc0JtQyxPQUF0QixDQUE4QjJMLEtBQUssSUFBRTtBQUFDLFlBQUd6TixLQUFLLENBQUNDLE9BQU4sQ0FBY3dOLEtBQWQsQ0FBSCxFQUF3QjtBQUFDQSxlQUFLLENBQUMzTCxPQUFOLENBQWM1QyxFQUFFLElBQUU2USxTQUFTLENBQUM3USxFQUFELENBQVQsSUFBZTRRLFNBQVMsQ0FBQzNPLElBQVYsQ0FBZWpDLEVBQWYsQ0FBakM7QUFBc0QsU0FBL0UsTUFBb0YsSUFBRzZRLFNBQVMsQ0FBQ3RDLEtBQUQsQ0FBWixFQUFvQjtBQUFDcUMsbUJBQVMsQ0FBQzNPLElBQVYsQ0FBZXNNLEtBQWY7QUFBdUI7QUFBQyxPQUF2SztBQUEwSzs7QUFBQSxVQUFNbEQsS0FBSyxHQUFDM0IsZ0JBQWdCLENBQUMsS0FBS1MsT0FBTCxDQUFhUixhQUFkLEVBQTRCLEtBQUtRLE9BQUwsQ0FBYXFFLGFBQWIsQ0FBMkJtQyxJQUF2RCxFQUE0RDlHLFNBQTVELENBQTVCO0FBQW1HLFdBQU0sYUFBYTFFLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkIsTUFBN0IsRUFBb0MsS0FBS0gsS0FBekMsRUFBK0MsS0FBS29LLE9BQUwsQ0FBYW9CLGFBQWIsSUFBNEIsYUFBYXBHLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkJpRixNQUFNLENBQUNtQyxPQUFQLENBQWUwSixRQUE1QyxFQUFxRCxJQUFyRCxFQUEwRCxhQUFhN0wsTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QixPQUE3QixFQUFxQztBQUFDLDZCQUFzQixJQUF2QjtBQUE0Qix5QkFBa0IySixTQUFTLEdBQUMsTUFBRCxHQUFReEosU0FBL0Q7QUFBeUVLLDZCQUF1QixFQUFDO0FBQUNFLGNBQU0sRUFBRTtBQUFUO0FBQWpHLEtBQXJDLENBQXZFLEVBQTZPLGFBQWF1RSxNQUFNLENBQUNtQyxPQUFQLENBQWVwSCxhQUFmLENBQTZCLFVBQTdCLEVBQXdDO0FBQUMsNkJBQXNCLElBQXZCO0FBQTRCLHlCQUFrQjJKLFNBQVMsR0FBQyxNQUFELEdBQVF4SjtBQUEvRCxLQUF4QyxFQUFrSCxhQUFhOEUsTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QixPQUE3QixFQUFxQztBQUFDUSw2QkFBdUIsRUFBQztBQUFDRSxjQUFNLEVBQUU7QUFBVDtBQUF6QixLQUFyQyxDQUEvSCxDQUExUCxDQUF4RixFQUFrakJILFFBQWxqQixFQUEyakJvSyxNQUFBLElBQW1DLGFBQWExRixDQUEzbUIsRUFBOHFCN0IsSUFBOXFCLEVBQW1yQixhQUFhNkIsTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QixNQUE3QixFQUFvQztBQUFDa1EsVUFBSSxFQUFDLGlCQUFOO0FBQXdCek8sYUFBTyxFQUFDd0QsTUFBTSxDQUFDbUMsT0FBUCxDQUFlZ0gsUUFBZixDQUF3QjJDLEtBQXhCLENBQThCM04sSUFBSSxJQUFFLEVBQXBDLEVBQXdDTCxRQUF4QztBQUFoQyxLQUFwQyxDQUFoc0IsRUFBeXpCNEcsU0FBUyxJQUFFLGFBQWExRSxNQUFNLENBQUNtQyxPQUFQLENBQWVwSCxhQUFmLENBQTZCaUYsTUFBTSxDQUFDbUMsT0FBUCxDQUFlMEosUUFBNUMsRUFBcUQsSUFBckQsRUFBMEQsYUFBYTdMLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkIsTUFBN0IsRUFBb0M7QUFBQ2tRLFVBQUksRUFBQyxVQUFOO0FBQWlCek8sYUFBTyxFQUFDO0FBQXpCLEtBQXBDLENBQXZFLEVBQTJMLENBQUMyTyxlQUFELElBQWtCLGFBQWFuTCxNQUFNLENBQUNtQyxPQUFQLENBQWVwSCxhQUFmLENBQTZCLE1BQTdCLEVBQW9DO0FBQUMyTixTQUFHLEVBQUMsV0FBTDtBQUFpQmhLLFVBQUksRUFBQ3lMLGFBQWEsR0FBQyxDQUFDLEdBQUUzRyxPQUFPLENBQUN1SSxZQUFYLEVBQXlCM0IsZUFBekI7QUFBcEMsS0FBcEMsQ0FBMU4sRUFBOFUsYUFBYXBLLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkIsTUFBN0IsRUFBb0M7QUFBQzJOLFNBQUcsRUFBQyxTQUFMO0FBQWVDLFFBQUUsRUFBQyxRQUFsQjtBQUEyQmpLLFVBQUksRUFBQztBQUFoQyxLQUFwQyxDQUEzVixFQUFvYzBJLE1BQU0sSUFBRSxhQUFhcEgsTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QixPQUE3QixFQUFxQztBQUFDLG9CQUFhLEVBQWQ7QUFBaUJRLDZCQUF1QixFQUFDO0FBQUNFLGNBQU0sRUFBQ2dRLFNBQVMsQ0FBQ3pPLEdBQVYsQ0FBY2dQLEtBQUssSUFBRUEsS0FBSyxDQUFDcFIsS0FBTixDQUFZVyx1QkFBWixDQUFvQ0UsTUFBekQsRUFBaUVJLElBQWpFLENBQXNFLEVBQXRFLEVBQTBFb1EsT0FBMUUsQ0FBa0YsZ0NBQWxGLEVBQW1ILEVBQW5ILEVBQXVIQSxPQUF2SCxDQUErSCwwQkFBL0gsRUFBMEosRUFBMUo7QUFBUjtBQUF6QyxLQUFyQyxDQUF6ZCxFQUFndEIsYUFBYWpNLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkIsT0FBN0IsRUFBcUM7QUFBQyx5QkFBa0IsRUFBbkI7QUFBc0JRLDZCQUF1QixFQUFDO0FBQUNFLGNBQU0sRUFBRTtBQUFUO0FBQTlDLEtBQXJDLENBQTd0QixFQUFvNUMsYUFBYXVFLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkIsVUFBN0IsRUFBd0MsSUFBeEMsRUFBNkMsYUFBYWlGLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkIsT0FBN0IsRUFBcUM7QUFBQyx5QkFBa0IsRUFBbkI7QUFBc0JRLDZCQUF1QixFQUFDO0FBQUNFLGNBQU0sRUFBRTtBQUFUO0FBQTlDLEtBQXJDLENBQTFELENBQWo2QyxFQUErb0QsYUFBYXVFLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkIsUUFBN0IsRUFBc0M7QUFBQ3NMLFdBQUssRUFBQyxJQUFQO0FBQVk1RixTQUFHLEVBQUM7QUFBaEIsS0FBdEMsQ0FBNXBELENBQWoxQixFQUF5a0YsQ0FBQ2lFLFNBQUQsSUFBWSxhQUFhMUUsTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QmlGLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZTBKLFFBQTVDLEVBQXFELElBQXJELEVBQTBELENBQUNYLGFBQUQsSUFBZ0JoQixTQUFoQixJQUEyQixhQUFhbEssTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QixNQUE3QixFQUFvQztBQUFDMk4sU0FBRyxFQUFDLFNBQUw7QUFBZWhLLFVBQUksRUFBQ3lMLGFBQWEsR0FBQytCLFVBQVUsQ0FBQ2pDLE9BQUQsRUFBU0csZUFBVDtBQUE1QyxLQUFwQyxDQUFsRyxFQUE4TSxTQUFrQyxLQUFLbkMsV0FBTCxDQUFpQi9CLEtBQWpCLENBQWhQLEVBQXdRLFNBQWtDLGFBQWFsRyxNQUFNLENBQUNtQyxPQUFQLENBQWVwSCxhQUFmLENBQTZCLFVBQTdCLEVBQXdDO0FBQUMsb0JBQWEsQ0FBQ2dQLGlCQUFpQixHQUFDLEtBQUtuUCxLQUFMLENBQVc0SyxLQUE5QixLQUFzQyxJQUF0QyxHQUEyQ3VFLGlCQUEzQyxHQUE2RDtBQUEzRSxLQUF4QyxDQUF2VCxFQUErYXJFLE1BQUEsSUFBb0MsYUFBYTFGLENBQWhlLEVBQWlpQixDQUFDd0ssZ0JBQUQsSUFBbUIsQ0FBQ0MsZ0JBQXBCLElBQXNDLEtBQUs1Qix1QkFBTCxFQUF2a0IsRUFBc21CLENBQUMyQixnQkFBRCxJQUFtQixDQUFDQyxnQkFBcEIsSUFBc0MsS0FBSzFCLG1CQUFMLENBQXlCN0MsS0FBekIsQ0FBNW9CLEVBQTRxQixDQUFDZix1QkFBRCxJQUEwQixDQUFDcUYsZ0JBQTNCLElBQTZDLEtBQUt6RixrQkFBTCxFQUF6dEIsRUFBbXZCLENBQUNJLHVCQUFELElBQTBCLENBQUNxRixnQkFBM0IsSUFBNkMsS0FBSzdFLGlCQUFMLEVBQWh5QixFQUF5ekIsQ0FBQ1IsdUJBQUQsSUFBMEIsQ0FBQ3FGLGdCQUEzQixJQUE2QyxLQUFLdkUsZ0JBQUwsQ0FBc0JDLEtBQXRCLENBQXQyQixFQUFtNEIsQ0FBQ2YsdUJBQUQsSUFBMEIsQ0FBQ3FGLGdCQUEzQixJQUE2QyxLQUFLakUsVUFBTCxDQUFnQkwsS0FBaEIsQ0FBaDdCLEVBQXU4QlIsTUFBQSxJQUFpQyxDQUF4K0IsRUFBZ2dDQSxNQUFBLElBQWlDLGFBQWExRixDQUE5aUMsRUFBd3FDLEtBQUtnRixPQUFMLENBQWFvQixhQUFiO0FBQTRCO0FBQWM7QUFDcGxJO0FBQ0E7QUFDQXBHLFVBQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkIsVUFBN0IsRUFBd0M7QUFBQzBFLFFBQUUsRUFBQztBQUFKLEtBQXhDLENBSGs0RixFQUd6ekYySCxNQUFNLElBQUUsSUFIaXpGLENBQWxtRixFQUd6TSxhQUFhcEgsTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QmlGLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZTBKLFFBQTVDLEVBQXFELEVBQXJELEVBQXdELElBQUl4QixRQUFRLElBQUUsRUFBZCxDQUF4RCxDQUg0TCxDQUFuQjtBQUc1Rjs7QUFqQjQvQjs7QUFpQjMvQm5RLFlBQUEsR0FBYXVOLElBQWI7QUFBa0JBLElBQUksQ0FBQzBFLFdBQUwsR0FBaUJqSixnQkFBZ0IsQ0FBQ0UsZUFBbEM7QUFBa0RxRSxJQUFJLENBQUMyRSxTQUFMLEdBQWU7QUFBQzVHLE9BQUssRUFBQzFDLFVBQVUsQ0FBQ1gsT0FBWCxDQUFtQmtLLE1BQTFCO0FBQWlDNUcsYUFBVyxFQUFDM0MsVUFBVSxDQUFDWCxPQUFYLENBQW1Ca0s7QUFBaEUsQ0FBZjs7QUFBdUYsU0FBU3hKLElBQVQsR0FBZTtBQUFDLFFBQUs7QUFBQzZCLGFBQUQ7QUFBV3dDLFFBQVg7QUFBZ0JTO0FBQWhCLE1BQXVDLENBQUMsR0FBRTNILE1BQU0sQ0FBQ3NDLFVBQVYsRUFBc0JZLGdCQUFnQixDQUFDRSxlQUF2QyxDQUE1QztBQUFvR3VFLHVCQUFxQixDQUFDOUUsSUFBdEIsR0FBMkIsSUFBM0I7QUFBZ0MsTUFBRzZCLFNBQUgsRUFBYSxPQUFNLGFBQWExRSxNQUFNLENBQUNtQyxPQUFQLENBQWVwSCxhQUFmLENBQTZCaUYsTUFBTSxDQUFDbUMsT0FBUCxDQUFlMEosUUFBNUMsRUFBcUQsSUFBckQsRUFBMEQ1SSxVQUFVLENBQUNxSixpQkFBckUsQ0FBbkI7QUFBMkcsU0FBTSxhQUFhdE0sTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QixLQUE3QixFQUFtQztBQUFDMEUsTUFBRSxFQUFDLFFBQUo7QUFBYWxFLDJCQUF1QixFQUFDO0FBQUNFLFlBQU0sRUFBQ3lMO0FBQVI7QUFBckMsR0FBbkMsQ0FBbkI7QUFBNEc7O0FBQUEsTUFBTVEsVUFBTixTQUF5QjFILE1BQU0sQ0FBQzZHLFNBQWhDLENBQXlDO0FBQUNrQixhQUFXLENBQUMsR0FBR0MsSUFBSixFQUFTO0FBQUMsVUFBTSxHQUFHQSxJQUFUO0FBQWUsU0FBS2hELE9BQUwsR0FBYSxLQUFLLENBQWxCO0FBQXFCOztBQUFBaUIsa0JBQWdCLENBQUNDLEtBQUQsRUFBTztBQUFDLFdBQU9ELGdCQUFnQixDQUFDLEtBQUtqQixPQUFOLEVBQWMsS0FBS3BLLEtBQW5CLEVBQXlCc0wsS0FBekIsQ0FBdkI7QUFBd0Q7O0FBQUFQLG1CQUFpQixHQUFFO0FBQUMsV0FBT0EsaUJBQWlCLENBQUMsS0FBS1gsT0FBTixFQUFjLEtBQUtwSyxLQUFuQixDQUF4QjtBQUFtRDs7QUFBQTJMLFlBQVUsQ0FBQ0wsS0FBRCxFQUFPO0FBQUMsV0FBT0ssVUFBVSxDQUFDLEtBQUt2QixPQUFOLEVBQWMsS0FBS3BLLEtBQW5CLEVBQXlCc0wsS0FBekIsQ0FBakI7QUFBa0Q7O0FBQUFuQixvQkFBa0IsR0FBRTtBQUFDLFdBQU9BLGtCQUFrQixDQUFDLEtBQUtDLE9BQU4sRUFBYyxLQUFLcEssS0FBbkIsQ0FBekI7QUFBb0Q7O0FBQUEsU0FBTzJSLHFCQUFQLENBQTZCQyxhQUE3QixFQUEyQztBQUFDLFVBQUs7QUFBQ25EO0FBQUQsUUFBZ0JtRCxhQUFyQjs7QUFBbUMsUUFBRztBQUFDLFlBQU1DLElBQUksR0FBQ0MsSUFBSSxDQUFDQyxTQUFMLENBQWV0RCxhQUFmLENBQVg7QUFBeUMsYUFBTSxDQUFDLEdBQUU1RixXQUFXLENBQUNtSixvQkFBZixFQUFxQ0gsSUFBckMsQ0FBTjtBQUFrRCxLQUEvRixDQUErRixPQUFNSSxHQUFOLEVBQVU7QUFBQyxVQUFHQSxHQUFHLENBQUNDLE9BQUosQ0FBWXpCLE9BQVosQ0FBb0Isb0JBQXBCLENBQUgsRUFBNkM7QUFBQyxjQUFNLElBQUkwQixLQUFKLENBQVcsMkRBQTBEMUQsYUFBYSxDQUFDbUMsSUFBSyx3REFBeEYsQ0FBTjtBQUF3Sjs7QUFBQSxZQUFNcUIsR0FBTjtBQUFXO0FBQUM7O0FBQUFyRixRQUFNLEdBQUU7QUFBQyxVQUFLO0FBQUN2QyxpQkFBRDtBQUFhUCxlQUFiO0FBQXVCRixtQkFBdkI7QUFBcUM4Rix3QkFBckM7QUFBd0QzQywyQkFBeEQ7QUFBOEV6QyxtQ0FBOUU7QUFBNEdDO0FBQTVHLFFBQXFJLEtBQUtILE9BQS9JO0FBQXVKLFVBQU13RixnQkFBZ0IsR0FBQ0Ysa0JBQWtCLEtBQUcsS0FBNUM7QUFBa0QzQyx5QkFBcUIsQ0FBQ0QsVUFBdEIsR0FBaUMsSUFBakM7O0FBQXNDLFFBQUdoRCxTQUFILEVBQWE7QUFBQyxpQkFBdUMsRUFBYzs7QUFBQSxZQUFNc0ksV0FBVyxHQUFDLENBQUMsR0FBR3hJLGFBQWEsQ0FBQ3lJLFFBQWxCLEVBQTJCLEdBQUd6SSxhQUFhLENBQUNZLGFBQTVDLEVBQTBELEdBQUdaLGFBQWEsQ0FBQ3dJLFdBQTNFLENBQWxCO0FBQTBHLGFBQU0sYUFBYWhOLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkJpRixNQUFNLENBQUNtQyxPQUFQLENBQWUwSixRQUE1QyxFQUFxRCxJQUFyRCxFQUEwRHJCLGdCQUFnQixHQUFDLElBQUQsR0FBTSxhQUFheEssTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QixRQUE3QixFQUFzQztBQUFDMEUsVUFBRSxFQUFDLGVBQUo7QUFBb0I5RSxZQUFJLEVBQUMsa0JBQXpCO0FBQTRDNkssYUFBSyxFQUFDLEtBQUs1SyxLQUFMLENBQVc0SyxLQUE3RDtBQUFtRUMsbUJBQVcsRUFBQyxLQUFLN0ssS0FBTCxDQUFXNkssV0FBWCxJQUF3QkMsU0FBdkc7QUFBdUluSywrQkFBdUIsRUFBQztBQUFDRSxnQkFBTSxFQUFDaU0sVUFBVSxDQUFDNkUscUJBQVgsQ0FBaUMsS0FBS3ZILE9BQXRDO0FBQVIsU0FBL0o7QUFBdU4sMkJBQWtCO0FBQXpPLE9BQXRDLENBQTdGLEVBQW1YZ0ksV0FBVyxDQUFDaFEsR0FBWixDQUFnQjZJLElBQUksSUFBRSxhQUFhN0YsTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QixRQUE3QixFQUFzQztBQUFDcUosV0FBRyxFQUFDeUIsSUFBTDtBQUFVcEYsV0FBRyxFQUFFLEdBQUV3RSxXQUFZLFVBQVNZLElBQUssR0FBRVgsNkJBQThCLEVBQTNFO0FBQTZFTSxhQUFLLEVBQUMsS0FBSzVLLEtBQUwsQ0FBVzRLLEtBQTlGO0FBQW9HQyxtQkFBVyxFQUFDLEtBQUs3SyxLQUFMLENBQVc2SyxXQUFYLElBQXdCQyxTQUF4STtBQUF3SywyQkFBa0I7QUFBMUwsT0FBdEMsQ0FBbkMsQ0FBblgsQ0FBbkI7QUFBbXBCOztBQUFBLGNBQXVDO0FBQUMsVUFBRyxLQUFLOUssS0FBTCxDQUFXNkssV0FBZCxFQUEwQnJKLE9BQU8sQ0FBQzRPLElBQVIsQ0FBYSwwSEFBYjtBQUEwSTs7QUFBQSxVQUFNOUUsS0FBSyxHQUFDM0IsZ0JBQWdCLENBQUMsS0FBS1MsT0FBTCxDQUFhUixhQUFkLEVBQTRCLEtBQUtRLE9BQUwsQ0FBYXFFLGFBQWIsQ0FBMkJtQyxJQUF2RCxFQUE0RDlHLFNBQTVELENBQTVCO0FBQW1HLFdBQU0sYUFBYTFFLE1BQU0sQ0FBQ21DLE9BQVAsQ0FBZXBILGFBQWYsQ0FBNkJpRixNQUFNLENBQUNtQyxPQUFQLENBQWUwSixRQUE1QyxFQUFxRCxJQUFyRCxFQUEwRCxDQUFDckIsZ0JBQUQsSUFBbUJoRyxhQUFhLENBQUN5SSxRQUFqQyxHQUEwQ3pJLGFBQWEsQ0FBQ3lJLFFBQWQsQ0FBdUJqUSxHQUF2QixDQUEyQjZJLElBQUksSUFBRSxhQUFhN0YsTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QixRQUE3QixFQUFzQztBQUFDcUosU0FBRyxFQUFDeUIsSUFBTDtBQUFVcEYsU0FBRyxFQUFFLEdBQUV3RSxXQUFZLFVBQVNxQixTQUFTLENBQUNULElBQUQsQ0FBTyxHQUFFWCw2QkFBOEIsRUFBdEY7QUFBd0ZNLFdBQUssRUFBQyxLQUFLNUssS0FBTCxDQUFXNEssS0FBekc7QUFBK0dDLGlCQUFXLEVBQUMsS0FBSzdLLEtBQUwsQ0FBVzZLLFdBQVgsSUFBd0JDLFNBQStCTTtBQUFsTCxLQUF0QyxDQUE5QyxDQUExQyxHQUFvVCxJQUE5VyxFQUFtWHdFLGdCQUFnQixHQUFDLElBQUQsR0FBTSxhQUFheEssTUFBTSxDQUFDbUMsT0FBUCxDQUFlcEgsYUFBZixDQUE2QixRQUE3QixFQUFzQztBQUFDMEUsUUFBRSxFQUFDLGVBQUo7QUFBb0I5RSxVQUFJLEVBQUMsa0JBQXpCO0FBQTRDNkssV0FBSyxFQUFDLEtBQUs1SyxLQUFMLENBQVc0SyxLQUE3RDtBQUFtRUMsaUJBQVcsRUFBQyxLQUFLN0ssS0FBTCxDQUFXNkssV0FBWCxJQUF3QkMsU0FBdkc7QUFBdUluSyw2QkFBdUIsRUFBQztBQUFDRSxjQUFNLEVBQUNpTSxVQUFVLENBQUM2RSxxQkFBWCxDQUFpQyxLQUFLdkgsT0FBdEM7QUFBUjtBQUEvSixLQUF0QyxDQUF0WixFQUFxcEJHLHVCQUF1QixJQUFFLENBQUNxRixnQkFBMUIsSUFBNEMsS0FBS3pGLGtCQUFMLEVBQWpzQixFQUEydEJJLHVCQUF1QixJQUFFLENBQUNxRixnQkFBMUIsSUFBNEMsS0FBSzdFLGlCQUFMLEVBQXZ3QixFQUFneUJSLHVCQUF1QixJQUFFLENBQUNxRixnQkFBMUIsSUFBNEMsS0FBS3ZFLGdCQUFMLENBQXNCQyxLQUF0QixDQUE1MEIsRUFBeTJCZix1QkFBdUIsSUFBRSxDQUFDcUYsZ0JBQTFCLElBQTRDLEtBQUtqRSxVQUFMLENBQWdCTCxLQUFoQixDQUFyNUIsQ0FBbkI7QUFBaThCOztBQUFqaEc7O0FBQWtoR2hNLGtCQUFBLEdBQW1Cd04sVUFBbkI7QUFBOEJBLFVBQVUsQ0FBQ3lFLFdBQVgsR0FBdUJqSixnQkFBZ0IsQ0FBQ0UsZUFBeEM7QUFBd0RzRSxVQUFVLENBQUMwRSxTQUFYLEdBQXFCO0FBQUM1RyxPQUFLLEVBQUMxQyxVQUFVLENBQUNYLE9BQVgsQ0FBbUJrSyxNQUExQjtBQUFpQzVHLGFBQVcsRUFBQzNDLFVBQVUsQ0FBQ1gsT0FBWCxDQUFtQmtLO0FBQWhFLENBQXJCO0FBQTZGM0UsVUFBVSxDQUFDd0YsaUJBQVgsR0FBNkIsMFRBQTdCOztBQUF3VixTQUFTaEIsVUFBVCxDQUFvQmpDLE9BQXBCLEVBQTRCa0QsTUFBNUIsRUFBbUM7QUFBQyxTQUFPbEQsT0FBTyxJQUFHLEdBQUVrRCxNQUFPLEdBQUVBLE1BQU0sQ0FBQzNMLFFBQVAsQ0FBZ0IsR0FBaEIsSUFBcUIsR0FBckIsR0FBeUIsR0FBSSxPQUF6RDtBQUFpRSxDOzs7Ozs7Ozs7OztBQ3pCbjJJLGtCQUFrQixNQUFNLDRCQUE0QixzQkFBc0I7QUFDdkY7QUFDQSxxQkFBcUIsaUZBQWlGLHdDQUF3QyxtQ0FBbUM7QUFDakwsc0M7Ozs7Ozs7Ozs7O0FDSEEsb0U7Ozs7Ozs7Ozs7O0FDQUEsMkU7Ozs7Ozs7Ozs7O0FDQUEsK0U7Ozs7Ozs7Ozs7O0FDQUEsZ0U7Ozs7Ozs7Ozs7O0FDQUEsNEU7Ozs7Ozs7Ozs7O0FDQUEsbUU7Ozs7Ozs7Ozs7O0FDQUEsd0M7Ozs7Ozs7Ozs7O0FDQUEsbUM7Ozs7Ozs7Ozs7O0FDQUEsK0MiLCJmaWxlIjoicGFnZXMvX2RvY3VtZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiZnVuY3Rpb24gX2V4dGVuZHMoKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduIHx8IGZ1bmN0aW9uICh0YXJnZXQpIHtcbiAgICBmb3IgKHZhciBpID0gMTsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIHNvdXJjZSA9IGFyZ3VtZW50c1tpXTtcblxuICAgICAgZm9yICh2YXIga2V5IGluIHNvdXJjZSkge1xuICAgICAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHNvdXJjZSwga2V5KSkge1xuICAgICAgICAgIHRhcmdldFtrZXldID0gc291cmNlW2tleV07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gdGFyZ2V0O1xuICB9O1xuXG4gIHJldHVybiBfZXh0ZW5kcy5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9leHRlbmRzOyIsImZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgXCJkZWZhdWx0XCI6IG9ialxuICB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQ7IiwiZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2Uoc291cmNlLCBleGNsdWRlZCkge1xuICBpZiAoc291cmNlID09IG51bGwpIHJldHVybiB7fTtcbiAgdmFyIHRhcmdldCA9IHt9O1xuICB2YXIgc291cmNlS2V5cyA9IE9iamVjdC5rZXlzKHNvdXJjZSk7XG4gIHZhciBrZXksIGk7XG5cbiAgZm9yIChpID0gMDsgaSA8IHNvdXJjZUtleXMubGVuZ3RoOyBpKyspIHtcbiAgICBrZXkgPSBzb3VyY2VLZXlzW2ldO1xuICAgIGlmIChleGNsdWRlZC5pbmRleE9mKGtleSkgPj0gMCkgY29udGludWU7XG4gICAgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTtcbiAgfVxuXG4gIHJldHVybiB0YXJnZXQ7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2U7IiwiXCJ1c2Ugc3RyaWN0XCI7ZXhwb3J0cy5fX2VzTW9kdWxlPXRydWU7ZXhwb3J0cy5kZWZhdWx0PWluaXRIZWFkTWFuYWdlcjtleHBvcnRzLkRPTUF0dHJpYnV0ZU5hbWVzPXZvaWQgMDtjb25zdCBET01BdHRyaWJ1dGVOYW1lcz17YWNjZXB0Q2hhcnNldDonYWNjZXB0LWNoYXJzZXQnLGNsYXNzTmFtZTonY2xhc3MnLGh0bWxGb3I6J2ZvcicsaHR0cEVxdWl2OidodHRwLWVxdWl2Jyxub01vZHVsZTonbm9Nb2R1bGUnfTtleHBvcnRzLkRPTUF0dHJpYnV0ZU5hbWVzPURPTUF0dHJpYnV0ZU5hbWVzO2Z1bmN0aW9uIHJlYWN0RWxlbWVudFRvRE9NKHt0eXBlLHByb3BzfSl7Y29uc3QgZWw9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0eXBlKTtmb3IoY29uc3QgcCBpbiBwcm9wcyl7aWYoIXByb3BzLmhhc093blByb3BlcnR5KHApKWNvbnRpbnVlO2lmKHA9PT0nY2hpbGRyZW4nfHxwPT09J2Rhbmdlcm91c2x5U2V0SW5uZXJIVE1MJyljb250aW51ZTsvLyB3ZSBkb24ndCByZW5kZXIgdW5kZWZpbmVkIHByb3BzIHRvIHRoZSBET01cbmlmKHByb3BzW3BdPT09dW5kZWZpbmVkKWNvbnRpbnVlO2NvbnN0IGF0dHI9RE9NQXR0cmlidXRlTmFtZXNbcF18fHAudG9Mb3dlckNhc2UoKTtpZih0eXBlPT09J3NjcmlwdCcmJihhdHRyPT09J2FzeW5jJ3x8YXR0cj09PSdkZWZlcid8fGF0dHI9PT0nbm9Nb2R1bGUnKSl7O2VsW2F0dHJdPSEhcHJvcHNbcF07fWVsc2V7ZWwuc2V0QXR0cmlidXRlKGF0dHIscHJvcHNbcF0pO319Y29uc3R7Y2hpbGRyZW4sZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUx9PXByb3BzO2lmKGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MKXtlbC5pbm5lckhUTUw9ZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUwuX19odG1sfHwnJzt9ZWxzZSBpZihjaGlsZHJlbil7ZWwudGV4dENvbnRlbnQ9dHlwZW9mIGNoaWxkcmVuPT09J3N0cmluZyc/Y2hpbGRyZW46QXJyYXkuaXNBcnJheShjaGlsZHJlbik/Y2hpbGRyZW4uam9pbignJyk6Jyc7fXJldHVybiBlbDt9ZnVuY3Rpb24gdXBkYXRlRWxlbWVudHModHlwZSxjb21wb25lbnRzKXtjb25zdCBoZWFkRWw9ZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2hlYWQnKVswXTtjb25zdCBoZWFkQ291bnRFbD1oZWFkRWwucXVlcnlTZWxlY3RvcignbWV0YVtuYW1lPW5leHQtaGVhZC1jb3VudF0nKTtpZihwcm9jZXNzLmVudi5OT0RFX0VOViE9PSdwcm9kdWN0aW9uJyl7aWYoIWhlYWRDb3VudEVsKXtjb25zb2xlLmVycm9yKCdXYXJuaW5nOiBuZXh0LWhlYWQtY291bnQgaXMgbWlzc2luZy4gaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvbmV4dC1oZWFkLWNvdW50LW1pc3NpbmcnKTtyZXR1cm47fX1jb25zdCBoZWFkQ291bnQ9TnVtYmVyKGhlYWRDb3VudEVsLmNvbnRlbnQpO2NvbnN0IG9sZFRhZ3M9W107Zm9yKGxldCBpPTAsaj1oZWFkQ291bnRFbC5wcmV2aW91c0VsZW1lbnRTaWJsaW5nO2k8aGVhZENvdW50O2krKyxqPWoucHJldmlvdXNFbGVtZW50U2libGluZyl7aWYoai50YWdOYW1lLnRvTG93ZXJDYXNlKCk9PT10eXBlKXtvbGRUYWdzLnB1c2goaik7fX1jb25zdCBuZXdUYWdzPWNvbXBvbmVudHMubWFwKHJlYWN0RWxlbWVudFRvRE9NKS5maWx0ZXIobmV3VGFnPT57Zm9yKGxldCBrPTAsbGVuPW9sZFRhZ3MubGVuZ3RoO2s8bGVuO2srKyl7Y29uc3Qgb2xkVGFnPW9sZFRhZ3Nba107aWYob2xkVGFnLmlzRXF1YWxOb2RlKG5ld1RhZykpe29sZFRhZ3Muc3BsaWNlKGssMSk7cmV0dXJuIGZhbHNlO319cmV0dXJuIHRydWU7fSk7b2xkVGFncy5mb3JFYWNoKHQ9PnQucGFyZW50Tm9kZS5yZW1vdmVDaGlsZCh0KSk7bmV3VGFncy5mb3JFYWNoKHQ9PmhlYWRFbC5pbnNlcnRCZWZvcmUodCxoZWFkQ291bnRFbCkpO2hlYWRDb3VudEVsLmNvbnRlbnQ9KGhlYWRDb3VudC1vbGRUYWdzLmxlbmd0aCtuZXdUYWdzLmxlbmd0aCkudG9TdHJpbmcoKTt9ZnVuY3Rpb24gaW5pdEhlYWRNYW5hZ2VyKCl7bGV0IHVwZGF0ZVByb21pc2U9bnVsbDtyZXR1cm57bW91bnRlZEluc3RhbmNlczpuZXcgU2V0KCksdXBkYXRlSGVhZDpoZWFkPT57Y29uc3QgcHJvbWlzZT11cGRhdGVQcm9taXNlPVByb21pc2UucmVzb2x2ZSgpLnRoZW4oKCk9PntpZihwcm9taXNlIT09dXBkYXRlUHJvbWlzZSlyZXR1cm47dXBkYXRlUHJvbWlzZT1udWxsO2NvbnN0IHRhZ3M9e307aGVhZC5mb3JFYWNoKGg9PntpZigvLyBJZiB0aGUgZm9udCB0YWcgaXMgbG9hZGVkIG9ubHkgb24gY2xpZW50IG5hdmlnYXRpb25cbi8vIGl0IHdvbid0IGJlIGlubGluZWQuIEluIHRoaXMgY2FzZSByZXZlcnQgdG8gdGhlIG9yaWdpbmFsIGJlaGF2aW9yXG5oLnR5cGU9PT0nbGluaycmJmgucHJvcHNbJ2RhdGEtb3B0aW1pemVkLWZvbnRzJ10mJiFkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGBzdHlsZVtkYXRhLWhyZWY9XCIke2gucHJvcHNbJ2RhdGEtaHJlZiddfVwiXWApKXtoLnByb3BzLmhyZWY9aC5wcm9wc1snZGF0YS1ocmVmJ107aC5wcm9wc1snZGF0YS1ocmVmJ109dW5kZWZpbmVkO31jb25zdCBjb21wb25lbnRzPXRhZ3NbaC50eXBlXXx8W107Y29tcG9uZW50cy5wdXNoKGgpO3RhZ3NbaC50eXBlXT1jb21wb25lbnRzO30pO2NvbnN0IHRpdGxlQ29tcG9uZW50PXRhZ3MudGl0bGU/dGFncy50aXRsZVswXTpudWxsO2xldCB0aXRsZT0nJztpZih0aXRsZUNvbXBvbmVudCl7Y29uc3R7Y2hpbGRyZW59PXRpdGxlQ29tcG9uZW50LnByb3BzO3RpdGxlPXR5cGVvZiBjaGlsZHJlbj09PSdzdHJpbmcnP2NoaWxkcmVuOkFycmF5LmlzQXJyYXkoY2hpbGRyZW4pP2NoaWxkcmVuLmpvaW4oJycpOicnO31pZih0aXRsZSE9PWRvY3VtZW50LnRpdGxlKWRvY3VtZW50LnRpdGxlPXRpdGxlO1snbWV0YScsJ2Jhc2UnLCdsaW5rJywnc3R5bGUnLCdzY3JpcHQnXS5mb3JFYWNoKHR5cGU9Pnt1cGRhdGVFbGVtZW50cyh0eXBlLHRhZ3NbdHlwZV18fFtdKTt9KTt9KTt9fTt9XG4vLyMgc291cmNlTWFwcGluZ1VSTD1oZWFkLW1hbmFnZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7ZXhwb3J0cy5fX2VzTW9kdWxlPXRydWU7ZXhwb3J0cy5jYW5jZWxJZGxlQ2FsbGJhY2s9ZXhwb3J0cy5yZXF1ZXN0SWRsZUNhbGxiYWNrPXZvaWQgMDtjb25zdCByZXF1ZXN0SWRsZUNhbGxiYWNrPXR5cGVvZiBzZWxmIT09J3VuZGVmaW5lZCcmJnNlbGYucmVxdWVzdElkbGVDYWxsYmFja3x8ZnVuY3Rpb24oY2Ipe2xldCBzdGFydD1EYXRlLm5vdygpO3JldHVybiBzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7Y2Ioe2RpZFRpbWVvdXQ6ZmFsc2UsdGltZVJlbWFpbmluZzpmdW5jdGlvbigpe3JldHVybiBNYXRoLm1heCgwLDUwLShEYXRlLm5vdygpLXN0YXJ0KSk7fX0pO30sMSk7fTtleHBvcnRzLnJlcXVlc3RJZGxlQ2FsbGJhY2s9cmVxdWVzdElkbGVDYWxsYmFjaztjb25zdCBjYW5jZWxJZGxlQ2FsbGJhY2s9dHlwZW9mIHNlbGYhPT0ndW5kZWZpbmVkJyYmc2VsZi5jYW5jZWxJZGxlQ2FsbGJhY2t8fGZ1bmN0aW9uKGlkKXtyZXR1cm4gY2xlYXJUaW1lb3V0KGlkKTt9O2V4cG9ydHMuY2FuY2VsSWRsZUNhbGxiYWNrPWNhbmNlbElkbGVDYWxsYmFjaztcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlcXVlc3QtaWRsZS1jYWxsYmFjay5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjt2YXIgX2ludGVyb3BSZXF1aXJlRGVmYXVsdD1yZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHRcIik7ZXhwb3J0cy5fX2VzTW9kdWxlPXRydWU7ZXhwb3J0cy5pbml0U2NyaXB0TG9hZGVyPWluaXRTY3JpcHRMb2FkZXI7ZXhwb3J0cy5kZWZhdWx0PXZvaWQgMDt2YXIgX2V4dGVuZHMyPV9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvZXh0ZW5kc1wiKSk7dmFyIF9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlMj1faW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2VcIikpO3ZhciBfcmVhY3Q9cmVxdWlyZShcInJlYWN0XCIpO3ZhciBfaGVhZE1hbmFnZXJDb250ZXh0PXJlcXVpcmUoXCIuLi9uZXh0LXNlcnZlci9saWIvaGVhZC1tYW5hZ2VyLWNvbnRleHRcIik7dmFyIF9oZWFkTWFuYWdlcj1yZXF1aXJlKFwiLi9oZWFkLW1hbmFnZXJcIik7dmFyIF9yZXF1ZXN0SWRsZUNhbGxiYWNrPXJlcXVpcmUoXCIuL3JlcXVlc3QtaWRsZS1jYWxsYmFja1wiKTtjb25zdCBTY3JpcHRDYWNoZT1uZXcgTWFwKCk7Y29uc3QgTG9hZENhY2hlPW5ldyBTZXQoKTtjb25zdCBpZ25vcmVQcm9wcz1bJ29uTG9hZCcsJ2Rhbmdlcm91c2x5U2V0SW5uZXJIVE1MJywnY2hpbGRyZW4nLCdvbkVycm9yJywnc3RyYXRlZ3knXTtjb25zdCBsb2FkU2NyaXB0PXByb3BzPT57Y29uc3R7c3JjLGlkLG9uTG9hZD0oKT0+e30sZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUwsY2hpbGRyZW49Jycsb25FcnJvcn09cHJvcHM7Y29uc3QgY2FjaGVLZXk9aWR8fHNyYztpZihTY3JpcHRDYWNoZS5oYXMoc3JjKSl7aWYoIUxvYWRDYWNoZS5oYXMoY2FjaGVLZXkpKXtMb2FkQ2FjaGUuYWRkKGNhY2hlS2V5KTsvLyBFeGVjdXRlIG9uTG9hZCBzaW5jZSB0aGUgc2NyaXB0IGxvYWRpbmcgaGFzIGJlZ3VuXG5TY3JpcHRDYWNoZS5nZXQoc3JjKS50aGVuKG9uTG9hZCxvbkVycm9yKTt9cmV0dXJuO31jb25zdCBlbD1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtjb25zdCBsb2FkUHJvbWlzZT1uZXcgUHJvbWlzZSgocmVzb2x2ZSxyZWplY3QpPT57ZWwuYWRkRXZlbnRMaXN0ZW5lcignbG9hZCcsZnVuY3Rpb24oKXtyZXNvbHZlKCk7aWYob25Mb2FkKXtvbkxvYWQuY2FsbCh0aGlzKTt9fSk7ZWwuYWRkRXZlbnRMaXN0ZW5lcignZXJyb3InLGZ1bmN0aW9uKCl7cmVqZWN0KCk7aWYob25FcnJvcil7b25FcnJvcigpO319KTt9KTtpZihzcmMpe1NjcmlwdENhY2hlLnNldChzcmMsbG9hZFByb21pc2UpO0xvYWRDYWNoZS5hZGQoY2FjaGVLZXkpO31pZihkYW5nZXJvdXNseVNldElubmVySFRNTCl7ZWwuaW5uZXJIVE1MPWRhbmdlcm91c2x5U2V0SW5uZXJIVE1MLl9faHRtbHx8Jyc7fWVsc2UgaWYoY2hpbGRyZW4pe2VsLnRleHRDb250ZW50PXR5cGVvZiBjaGlsZHJlbj09PSdzdHJpbmcnP2NoaWxkcmVuOkFycmF5LmlzQXJyYXkoY2hpbGRyZW4pP2NoaWxkcmVuLmpvaW4oJycpOicnO31lbHNlIGlmKHNyYyl7ZWwuc3JjPXNyYzt9Zm9yKGNvbnN0W2ssdmFsdWVdb2YgT2JqZWN0LmVudHJpZXMocHJvcHMpKXtpZih2YWx1ZT09PXVuZGVmaW5lZHx8aWdub3JlUHJvcHMuaW5jbHVkZXMoaykpe2NvbnRpbnVlO31jb25zdCBhdHRyPV9oZWFkTWFuYWdlci5ET01BdHRyaWJ1dGVOYW1lc1trXXx8ay50b0xvd2VyQ2FzZSgpO2VsLnNldEF0dHJpYnV0ZShhdHRyLHZhbHVlKTt9ZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChlbCk7fTtmdW5jdGlvbiBoYW5kbGVDbGllbnRTY3JpcHRMb2FkKHByb3BzKXtjb25zdHtzdHJhdGVneT0nYWZ0ZXJJbnRlcmFjdGl2ZSd9PXByb3BzO2lmKHN0cmF0ZWd5PT09J2FmdGVySW50ZXJhY3RpdmUnKXtsb2FkU2NyaXB0KHByb3BzKTt9ZWxzZSBpZihzdHJhdGVneT09PSdsYXp5T25sb2FkJyl7d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCgpPT57KDAsX3JlcXVlc3RJZGxlQ2FsbGJhY2sucmVxdWVzdElkbGVDYWxsYmFjaykoKCk9PmxvYWRTY3JpcHQocHJvcHMpKTt9KTt9fWZ1bmN0aW9uIGxvYWRMYXp5U2NyaXB0KHByb3BzKXtpZihkb2N1bWVudC5yZWFkeVN0YXRlPT09J2NvbXBsZXRlJyl7KDAsX3JlcXVlc3RJZGxlQ2FsbGJhY2sucmVxdWVzdElkbGVDYWxsYmFjaykoKCk9PmxvYWRTY3JpcHQocHJvcHMpKTt9ZWxzZXt3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbG9hZCcsKCk9PnsoMCxfcmVxdWVzdElkbGVDYWxsYmFjay5yZXF1ZXN0SWRsZUNhbGxiYWNrKSgoKT0+bG9hZFNjcmlwdChwcm9wcykpO30pO319ZnVuY3Rpb24gaW5pdFNjcmlwdExvYWRlcihzY3JpcHRMb2FkZXJJdGVtcyl7c2NyaXB0TG9hZGVySXRlbXMuZm9yRWFjaChoYW5kbGVDbGllbnRTY3JpcHRMb2FkKTt9ZnVuY3Rpb24gU2NyaXB0KHByb3BzKXtjb25zdHtzcmM9Jycsb25Mb2FkPSgpPT57fSxzdHJhdGVneT0nYWZ0ZXJJbnRlcmFjdGl2ZScsb25FcnJvcn09cHJvcHMscmVzdFByb3BzPSgwLF9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlMi5kZWZhdWx0KShwcm9wcyxbXCJzcmNcIixcIm9uTG9hZFwiLFwiZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUxcIixcInN0cmF0ZWd5XCIsXCJvbkVycm9yXCJdKTsvLyBDb250ZXh0IGlzIGF2YWlsYWJsZSBvbmx5IGR1cmluZyBTU1JcbmNvbnN0e3VwZGF0ZVNjcmlwdHMsc2NyaXB0c309KDAsX3JlYWN0LnVzZUNvbnRleHQpKF9oZWFkTWFuYWdlckNvbnRleHQuSGVhZE1hbmFnZXJDb250ZXh0KTsoMCxfcmVhY3QudXNlRWZmZWN0KSgoKT0+e2lmKHN0cmF0ZWd5PT09J2FmdGVySW50ZXJhY3RpdmUnKXtsb2FkU2NyaXB0KHByb3BzKTt9ZWxzZSBpZihzdHJhdGVneT09PSdsYXp5T25sb2FkJyl7bG9hZExhenlTY3JpcHQocHJvcHMpO319LFtwcm9wcyxzdHJhdGVneV0pO2lmKHN0cmF0ZWd5PT09J2JlZm9yZUludGVyYWN0aXZlJyl7aWYodXBkYXRlU2NyaXB0cyl7c2NyaXB0cy5iZWZvcmVJbnRlcmFjdGl2ZT0oc2NyaXB0cy5iZWZvcmVJbnRlcmFjdGl2ZXx8W10pLmNvbmNhdChbKDAsX2V4dGVuZHMyLmRlZmF1bHQpKHtzcmMsb25Mb2FkLG9uRXJyb3J9LHJlc3RQcm9wcyldKTt1cGRhdGVTY3JpcHRzKHNjcmlwdHMpO319cmV0dXJuIG51bGw7fXZhciBfZGVmYXVsdD1TY3JpcHQ7ZXhwb3J0cy5kZWZhdWx0PV9kZWZhdWx0O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2NyaXB0LmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO2V4cG9ydHMuX19lc01vZHVsZT10cnVlO2V4cG9ydHMuSHRtbD1IdG1sO2V4cG9ydHMuTWFpbj1NYWluO2V4cG9ydHMuTmV4dFNjcmlwdD1leHBvcnRzLkhlYWQ9ZXhwb3J0cy5kZWZhdWx0PXZvaWQgMDt2YXIgX3Byb3BUeXBlcz1faW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJwcm9wLXR5cGVzXCIpKTt2YXIgX3JlYWN0PV9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkKHJlcXVpcmUoXCJyZWFjdFwiKSk7dmFyIF9zZXJ2ZXI9X2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwic3R5bGVkLWpzeC9zZXJ2ZXJcIikpO3ZhciBfY29uc3RhbnRzPXJlcXVpcmUoXCIuLi9uZXh0LXNlcnZlci9saWIvY29uc3RhbnRzXCIpO3ZhciBfZG9jdW1lbnRDb250ZXh0PXJlcXVpcmUoXCIuLi9uZXh0LXNlcnZlci9saWIvZG9jdW1lbnQtY29udGV4dFwiKTt2YXIgX3V0aWxzPXJlcXVpcmUoXCIuLi9uZXh0LXNlcnZlci9saWIvdXRpbHNcIik7ZXhwb3J0cy5Eb2N1bWVudENvbnRleHQ9X3V0aWxzLkRvY3VtZW50Q29udGV4dDtleHBvcnRzLkRvY3VtZW50SW5pdGlhbFByb3BzPV91dGlscy5Eb2N1bWVudEluaXRpYWxQcm9wcztleHBvcnRzLkRvY3VtZW50UHJvcHM9X3V0aWxzLkRvY3VtZW50UHJvcHM7dmFyIF9nZXRQYWdlRmlsZXM9cmVxdWlyZShcIi4uL25leHQtc2VydmVyL3NlcnZlci9nZXQtcGFnZS1maWxlc1wiKTt2YXIgX3V0aWxzMj1yZXF1aXJlKFwiLi4vbmV4dC1zZXJ2ZXIvc2VydmVyL3V0aWxzXCIpO3ZhciBfaHRtbGVzY2FwZT1yZXF1aXJlKFwiLi4vc2VydmVyL2h0bWxlc2NhcGVcIik7dmFyIF9zY3JpcHQ9X2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi4vY2xpZW50L3NjcmlwdFwiKSk7ZnVuY3Rpb24gX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlKCl7aWYodHlwZW9mIFdlYWtNYXAhPT1cImZ1bmN0aW9uXCIpcmV0dXJuIG51bGw7dmFyIGNhY2hlPW5ldyBXZWFrTWFwKCk7X2dldFJlcXVpcmVXaWxkY2FyZENhY2hlPWZ1bmN0aW9uKCl7cmV0dXJuIGNhY2hlO307cmV0dXJuIGNhY2hlO31mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZChvYmope2lmKG9iaiYmb2JqLl9fZXNNb2R1bGUpe3JldHVybiBvYmo7fWlmKG9iaj09PW51bGx8fHR5cGVvZiBvYmohPT1cIm9iamVjdFwiJiZ0eXBlb2Ygb2JqIT09XCJmdW5jdGlvblwiKXtyZXR1cm57ZGVmYXVsdDpvYmp9O312YXIgY2FjaGU9X2dldFJlcXVpcmVXaWxkY2FyZENhY2hlKCk7aWYoY2FjaGUmJmNhY2hlLmhhcyhvYmopKXtyZXR1cm4gY2FjaGUuZ2V0KG9iaik7fXZhciBuZXdPYmo9e307dmFyIGhhc1Byb3BlcnR5RGVzY3JpcHRvcj1PYmplY3QuZGVmaW5lUHJvcGVydHkmJk9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7Zm9yKHZhciBrZXkgaW4gb2JqKXtpZihPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLGtleSkpe3ZhciBkZXNjPWhhc1Byb3BlcnR5RGVzY3JpcHRvcj9PYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG9iaixrZXkpOm51bGw7aWYoZGVzYyYmKGRlc2MuZ2V0fHxkZXNjLnNldCkpe09iamVjdC5kZWZpbmVQcm9wZXJ0eShuZXdPYmosa2V5LGRlc2MpO31lbHNle25ld09ialtrZXldPW9ialtrZXldO319fW5ld09iai5kZWZhdWx0PW9iajtpZihjYWNoZSl7Y2FjaGUuc2V0KG9iaixuZXdPYmopO31yZXR1cm4gbmV3T2JqO31mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iail7cmV0dXJuIG9iaiYmb2JqLl9fZXNNb2R1bGU/b2JqOntkZWZhdWx0Om9ian07fWZ1bmN0aW9uIGdldERvY3VtZW50RmlsZXMoYnVpbGRNYW5pZmVzdCxwYXRobmFtZSxpbkFtcE1vZGUpe2NvbnN0IHNoYXJlZEZpbGVzPSgwLF9nZXRQYWdlRmlsZXMuZ2V0UGFnZUZpbGVzKShidWlsZE1hbmlmZXN0LCcvX2FwcCcpO2NvbnN0IHBhZ2VGaWxlcz1pbkFtcE1vZGU/W106KDAsX2dldFBhZ2VGaWxlcy5nZXRQYWdlRmlsZXMpKGJ1aWxkTWFuaWZlc3QscGF0aG5hbWUpO3JldHVybntzaGFyZWRGaWxlcyxwYWdlRmlsZXMsYWxsRmlsZXM6Wy4uLm5ldyBTZXQoWy4uLnNoYXJlZEZpbGVzLC4uLnBhZ2VGaWxlc10pXX07fWZ1bmN0aW9uIGdldFBvbHlmaWxsU2NyaXB0cyhjb250ZXh0LHByb3BzKXsvLyBwb2x5ZmlsbHMuanMgaGFzIHRvIGJlIHJlbmRlcmVkIGFzIG5vbW9kdWxlIHdpdGhvdXQgYXN5bmNcbi8vIEl0IGFsc28gaGFzIHRvIGJlIHRoZSBmaXJzdCBzY3JpcHQgdG8gbG9hZFxuY29uc3R7YXNzZXRQcmVmaXgsYnVpbGRNYW5pZmVzdCxkZXZPbmx5Q2FjaGVCdXN0ZXJRdWVyeVN0cmluZyxkaXNhYmxlT3B0aW1pemVkTG9hZGluZ309Y29udGV4dDtyZXR1cm4gYnVpbGRNYW5pZmVzdC5wb2x5ZmlsbEZpbGVzLmZpbHRlcihwb2x5ZmlsbD0+cG9seWZpbGwuZW5kc1dpdGgoJy5qcycpJiYhcG9seWZpbGwuZW5kc1dpdGgoJy5tb2R1bGUuanMnKSkubWFwKHBvbHlmaWxsPT4vKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiLHtrZXk6cG9seWZpbGwsZGVmZXI6IWRpc2FibGVPcHRpbWl6ZWRMb2FkaW5nLG5vbmNlOnByb3BzLm5vbmNlLGNyb3NzT3JpZ2luOnByb3BzLmNyb3NzT3JpZ2lufHxwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOLG5vTW9kdWxlOnRydWUsc3JjOmAke2Fzc2V0UHJlZml4fS9fbmV4dC8ke3BvbHlmaWxsfSR7ZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmd9YH0pKTt9ZnVuY3Rpb24gZ2V0UHJlTmV4dFNjcmlwdHMoY29udGV4dCxwcm9wcyl7Y29uc3R7c2NyaXB0TG9hZGVyLGRpc2FibGVPcHRpbWl6ZWRMb2FkaW5nfT1jb250ZXh0O3JldHVybihzY3JpcHRMb2FkZXIuYmVmb3JlSW50ZXJhY3RpdmV8fFtdKS5tYXAoZmlsZT0+e2NvbnN0e3N0cmF0ZWd5LC4uLnNjcmlwdFByb3BzfT1maWxlO3JldHVybi8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIsT2JqZWN0LmFzc2lnbih7fSxzY3JpcHRQcm9wcyx7ZGVmZXI6IWRpc2FibGVPcHRpbWl6ZWRMb2FkaW5nLG5vbmNlOnByb3BzLm5vbmNlLGNyb3NzT3JpZ2luOnByb3BzLmNyb3NzT3JpZ2lufHxwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOfSkpO30pO31mdW5jdGlvbiBnZXREeW5hbWljQ2h1bmtzKGNvbnRleHQscHJvcHMsZmlsZXMpe2NvbnN0e2R5bmFtaWNJbXBvcnRzLGFzc2V0UHJlZml4LGlzRGV2ZWxvcG1lbnQsZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmcsZGlzYWJsZU9wdGltaXplZExvYWRpbmd9PWNvbnRleHQ7cmV0dXJuIGR5bmFtaWNJbXBvcnRzLm1hcChmaWxlPT57aWYoIWZpbGUuZW5kc1dpdGgoJy5qcycpfHxmaWxlcy5hbGxGaWxlcy5pbmNsdWRlcyhmaWxlKSlyZXR1cm4gbnVsbDtyZXR1cm4vKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiLHthc3luYzohaXNEZXZlbG9wbWVudCYmZGlzYWJsZU9wdGltaXplZExvYWRpbmcsZGVmZXI6IWRpc2FibGVPcHRpbWl6ZWRMb2FkaW5nLGtleTpmaWxlLHNyYzpgJHthc3NldFByZWZpeH0vX25leHQvJHtlbmNvZGVVUkkoZmlsZSl9JHtkZXZPbmx5Q2FjaGVCdXN0ZXJRdWVyeVN0cmluZ31gLG5vbmNlOnByb3BzLm5vbmNlLGNyb3NzT3JpZ2luOnByb3BzLmNyb3NzT3JpZ2lufHxwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOfSk7fSk7fWZ1bmN0aW9uIGdldFNjcmlwdHMoY29udGV4dCxwcm9wcyxmaWxlcyl7dmFyIF9idWlsZE1hbmlmZXN0JGxvd1ByaTtjb25zdHthc3NldFByZWZpeCxidWlsZE1hbmlmZXN0LGlzRGV2ZWxvcG1lbnQsZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmcsZGlzYWJsZU9wdGltaXplZExvYWRpbmd9PWNvbnRleHQ7Y29uc3Qgbm9ybWFsU2NyaXB0cz1maWxlcy5hbGxGaWxlcy5maWx0ZXIoZmlsZT0+ZmlsZS5lbmRzV2l0aCgnLmpzJykpO2NvbnN0IGxvd1ByaW9yaXR5U2NyaXB0cz0oX2J1aWxkTWFuaWZlc3QkbG93UHJpPWJ1aWxkTWFuaWZlc3QubG93UHJpb3JpdHlGaWxlcyk9PW51bGw/dm9pZCAwOl9idWlsZE1hbmlmZXN0JGxvd1ByaS5maWx0ZXIoZmlsZT0+ZmlsZS5lbmRzV2l0aCgnLmpzJykpO3JldHVyblsuLi5ub3JtYWxTY3JpcHRzLC4uLmxvd1ByaW9yaXR5U2NyaXB0c10ubWFwKGZpbGU9PntyZXR1cm4vKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiLHtrZXk6ZmlsZSxzcmM6YCR7YXNzZXRQcmVmaXh9L19uZXh0LyR7ZW5jb2RlVVJJKGZpbGUpfSR7ZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmd9YCxub25jZTpwcm9wcy5ub25jZSxhc3luYzohaXNEZXZlbG9wbWVudCYmZGlzYWJsZU9wdGltaXplZExvYWRpbmcsZGVmZXI6IWRpc2FibGVPcHRpbWl6ZWRMb2FkaW5nLGNyb3NzT3JpZ2luOnByb3BzLmNyb3NzT3JpZ2lufHxwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOfSk7fSk7fS8qKlxuICogYERvY3VtZW50YCBjb21wb25lbnQgaGFuZGxlcyB0aGUgaW5pdGlhbCBgZG9jdW1lbnRgIG1hcmt1cCBhbmQgcmVuZGVycyBvbmx5IG9uIHRoZSBzZXJ2ZXIgc2lkZS5cbiAqIENvbW1vbmx5IHVzZWQgZm9yIGltcGxlbWVudGluZyBzZXJ2ZXIgc2lkZSByZW5kZXJpbmcgZm9yIGBjc3MtaW4tanNgIGxpYnJhcmllcy5cbiAqL2NsYXNzIERvY3VtZW50IGV4dGVuZHMgX3JlYWN0LkNvbXBvbmVudHsvKipcbiAgICogYGdldEluaXRpYWxQcm9wc2AgaG9vayByZXR1cm5zIHRoZSBjb250ZXh0IG9iamVjdCB3aXRoIHRoZSBhZGRpdGlvbiBvZiBgcmVuZGVyUGFnZWAuXG4gICAqIGByZW5kZXJQYWdlYCBjYWxsYmFjayBleGVjdXRlcyBgUmVhY3RgIHJlbmRlcmluZyBsb2dpYyBzeW5jaHJvbm91c2x5IHRvIHN1cHBvcnQgc2VydmVyLXJlbmRlcmluZyB3cmFwcGVyc1xuICAgKi9zdGF0aWMgYXN5bmMgZ2V0SW5pdGlhbFByb3BzKGN0eCl7Y29uc3QgZW5oYW5jZUFwcD1BcHA9PntyZXR1cm4gcHJvcHM9Pi8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KEFwcCxwcm9wcyk7fTtjb25zdHtodG1sLGhlYWR9PWF3YWl0IGN0eC5yZW5kZXJQYWdlKHtlbmhhbmNlQXBwfSk7Y29uc3Qgc3R5bGVzPVsuLi4oMCxfc2VydmVyLmRlZmF1bHQpKCldO3JldHVybntodG1sLGhlYWQsc3R5bGVzfTt9c3RhdGljIHJlbmRlckRvY3VtZW50KERvY3VtZW50Q29tcG9uZW50LHByb3BzKXtyZXR1cm4vKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChfZG9jdW1lbnRDb250ZXh0LkRvY3VtZW50Q29udGV4dC5Qcm92aWRlcix7dmFsdWU6cHJvcHN9LC8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KERvY3VtZW50Q29tcG9uZW50LHByb3BzKSk7fXJlbmRlcigpe3JldHVybi8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KEh0bWwsbnVsbCwvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChIZWFkLG51bGwpLC8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwiYm9keVwiLG51bGwsLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoTWFpbixudWxsKSwvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChOZXh0U2NyaXB0LG51bGwpKSk7fX1leHBvcnRzLmRlZmF1bHQ9RG9jdW1lbnQ7ZnVuY3Rpb24gSHRtbChwcm9wcyl7Y29uc3R7aW5BbXBNb2RlLGRvY0NvbXBvbmVudHNSZW5kZXJlZCxsb2NhbGV9PSgwLF9yZWFjdC51c2VDb250ZXh0KShfZG9jdW1lbnRDb250ZXh0LkRvY3VtZW50Q29udGV4dCk7ZG9jQ29tcG9uZW50c1JlbmRlcmVkLkh0bWw9dHJ1ZTtyZXR1cm4vKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImh0bWxcIixPYmplY3QuYXNzaWduKHt9LHByb3BzLHtsYW5nOnByb3BzLmxhbmd8fGxvY2FsZXx8dW5kZWZpbmVkLGFtcDppbkFtcE1vZGU/Jyc6dW5kZWZpbmVkLFwiZGF0YS1hbXBkZXZtb2RlXCI6aW5BbXBNb2RlJiZwcm9jZXNzLmVudi5OT0RFX0VOViE9PSdwcm9kdWN0aW9uJz8nJzp1bmRlZmluZWR9KSk7fWNsYXNzIEhlYWQgZXh0ZW5kcyBfcmVhY3QuQ29tcG9uZW50e2NvbnN0cnVjdG9yKC4uLmFyZ3Mpe3N1cGVyKC4uLmFyZ3MpO3RoaXMuY29udGV4dD12b2lkIDA7fWdldENzc0xpbmtzKGZpbGVzKXtjb25zdHthc3NldFByZWZpeCxkZXZPbmx5Q2FjaGVCdXN0ZXJRdWVyeVN0cmluZyxkeW5hbWljSW1wb3J0c309dGhpcy5jb250ZXh0O2NvbnN0IGNzc0ZpbGVzPWZpbGVzLmFsbEZpbGVzLmZpbHRlcihmPT5mLmVuZHNXaXRoKCcuY3NzJykpO2NvbnN0IHNoYXJlZEZpbGVzPW5ldyBTZXQoZmlsZXMuc2hhcmVkRmlsZXMpOy8vIFVubWFuYWdlZCBmaWxlcyBhcmUgQ1NTIGZpbGVzIHRoYXQgd2lsbCBiZSBoYW5kbGVkIGRpcmVjdGx5IGJ5IHRoZVxuLy8gd2VicGFjayBydW50aW1lIChgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5gKS5cbmxldCB1bm1hbmdlZEZpbGVzPW5ldyBTZXQoW10pO2xldCBkeW5hbWljQ3NzRmlsZXM9QXJyYXkuZnJvbShuZXcgU2V0KGR5bmFtaWNJbXBvcnRzLmZpbHRlcihmaWxlPT5maWxlLmVuZHNXaXRoKCcuY3NzJykpKSk7aWYoZHluYW1pY0Nzc0ZpbGVzLmxlbmd0aCl7Y29uc3QgZXhpc3Rpbmc9bmV3IFNldChjc3NGaWxlcyk7ZHluYW1pY0Nzc0ZpbGVzPWR5bmFtaWNDc3NGaWxlcy5maWx0ZXIoZj0+IShleGlzdGluZy5oYXMoZil8fHNoYXJlZEZpbGVzLmhhcyhmKSkpO3VubWFuZ2VkRmlsZXM9bmV3IFNldChkeW5hbWljQ3NzRmlsZXMpO2Nzc0ZpbGVzLnB1c2goLi4uZHluYW1pY0Nzc0ZpbGVzKTt9bGV0IGNzc0xpbmtFbGVtZW50cz1bXTtjc3NGaWxlcy5mb3JFYWNoKGZpbGU9Pntjb25zdCBpc1NoYXJlZEZpbGU9c2hhcmVkRmlsZXMuaGFzKGZpbGUpO2lmKCFwcm9jZXNzLmVudi5fX05FWFRfT1BUSU1JWkVfQ1NTKXtjc3NMaW5rRWxlbWVudHMucHVzaCgvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImxpbmtcIix7a2V5OmAke2ZpbGV9LXByZWxvYWRgLG5vbmNlOnRoaXMucHJvcHMubm9uY2UscmVsOlwicHJlbG9hZFwiLGhyZWY6YCR7YXNzZXRQcmVmaXh9L19uZXh0LyR7ZW5jb2RlVVJJKGZpbGUpfSR7ZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmd9YCxhczpcInN0eWxlXCIsY3Jvc3NPcmlnaW46dGhpcy5wcm9wcy5jcm9zc09yaWdpbnx8cHJvY2Vzcy5lbnYuX19ORVhUX0NST1NTX09SSUdJTn0pKTt9Y29uc3QgaXNVbm1hbmFnZWRGaWxlPXVubWFuZ2VkRmlsZXMuaGFzKGZpbGUpO2Nzc0xpbmtFbGVtZW50cy5wdXNoKC8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwibGlua1wiLHtrZXk6ZmlsZSxub25jZTp0aGlzLnByb3BzLm5vbmNlLHJlbDpcInN0eWxlc2hlZXRcIixocmVmOmAke2Fzc2V0UHJlZml4fS9fbmV4dC8ke2VuY29kZVVSSShmaWxlKX0ke2Rldk9ubHlDYWNoZUJ1c3RlclF1ZXJ5U3RyaW5nfWAsY3Jvc3NPcmlnaW46dGhpcy5wcm9wcy5jcm9zc09yaWdpbnx8cHJvY2Vzcy5lbnYuX19ORVhUX0NST1NTX09SSUdJTixcImRhdGEtbi1nXCI6aXNVbm1hbmFnZWRGaWxlP3VuZGVmaW5lZDppc1NoYXJlZEZpbGU/Jyc6dW5kZWZpbmVkLFwiZGF0YS1uLXBcIjppc1VubWFuYWdlZEZpbGU/dW5kZWZpbmVkOmlzU2hhcmVkRmlsZT91bmRlZmluZWQ6Jyd9KSk7fSk7aWYocHJvY2Vzcy5lbnYuTk9ERV9FTlYhPT0nZGV2ZWxvcG1lbnQnJiZwcm9jZXNzLmVudi5fX05FWFRfT1BUSU1JWkVfRk9OVFMpe2Nzc0xpbmtFbGVtZW50cz10aGlzLm1ha2VTdHlsZXNoZWV0SW5lcnQoY3NzTGlua0VsZW1lbnRzKTt9cmV0dXJuIGNzc0xpbmtFbGVtZW50cy5sZW5ndGg9PT0wP251bGw6Y3NzTGlua0VsZW1lbnRzO31nZXRQcmVsb2FkRHluYW1pY0NodW5rcygpe2NvbnN0e2R5bmFtaWNJbXBvcnRzLGFzc2V0UHJlZml4LGRldk9ubHlDYWNoZUJ1c3RlclF1ZXJ5U3RyaW5nfT10aGlzLmNvbnRleHQ7cmV0dXJuIGR5bmFtaWNJbXBvcnRzLm1hcChmaWxlPT57aWYoIWZpbGUuZW5kc1dpdGgoJy5qcycpKXtyZXR1cm4gbnVsbDt9cmV0dXJuLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJsaW5rXCIse3JlbDpcInByZWxvYWRcIixrZXk6ZmlsZSxocmVmOmAke2Fzc2V0UHJlZml4fS9fbmV4dC8ke2VuY29kZVVSSShmaWxlKX0ke2Rldk9ubHlDYWNoZUJ1c3RlclF1ZXJ5U3RyaW5nfWAsYXM6XCJzY3JpcHRcIixub25jZTp0aGlzLnByb3BzLm5vbmNlLGNyb3NzT3JpZ2luOnRoaXMucHJvcHMuY3Jvc3NPcmlnaW58fHByb2Nlc3MuZW52Ll9fTkVYVF9DUk9TU19PUklHSU59KTt9KS8vIEZpbHRlciBvdXQgbnVsbGVkIHNjcmlwdHNcbi5maWx0ZXIoQm9vbGVhbik7fWdldFByZWxvYWRNYWluTGlua3MoZmlsZXMpe2NvbnN0e2Fzc2V0UHJlZml4LGRldk9ubHlDYWNoZUJ1c3RlclF1ZXJ5U3RyaW5nLHNjcmlwdExvYWRlcn09dGhpcy5jb250ZXh0O2NvbnN0IHByZWxvYWRGaWxlcz1maWxlcy5hbGxGaWxlcy5maWx0ZXIoZmlsZT0+e3JldHVybiBmaWxlLmVuZHNXaXRoKCcuanMnKTt9KTtyZXR1cm5bLi4uKHNjcmlwdExvYWRlci5iZWZvcmVJbnRlcmFjdGl2ZXx8W10pLm1hcChmaWxlPT4vKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImxpbmtcIix7a2V5OmZpbGUuc3JjLG5vbmNlOnRoaXMucHJvcHMubm9uY2UscmVsOlwicHJlbG9hZFwiLGhyZWY6ZmlsZS5zcmMsYXM6XCJzY3JpcHRcIixjcm9zc09yaWdpbjp0aGlzLnByb3BzLmNyb3NzT3JpZ2lufHxwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOfSkpLC4uLnByZWxvYWRGaWxlcy5tYXAoZmlsZT0+LyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJsaW5rXCIse2tleTpmaWxlLG5vbmNlOnRoaXMucHJvcHMubm9uY2UscmVsOlwicHJlbG9hZFwiLGhyZWY6YCR7YXNzZXRQcmVmaXh9L19uZXh0LyR7ZW5jb2RlVVJJKGZpbGUpfSR7ZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmd9YCxhczpcInNjcmlwdFwiLGNyb3NzT3JpZ2luOnRoaXMucHJvcHMuY3Jvc3NPcmlnaW58fHByb2Nlc3MuZW52Ll9fTkVYVF9DUk9TU19PUklHSU59KSldO31nZXREeW5hbWljQ2h1bmtzKGZpbGVzKXtyZXR1cm4gZ2V0RHluYW1pY0NodW5rcyh0aGlzLmNvbnRleHQsdGhpcy5wcm9wcyxmaWxlcyk7fWdldFByZU5leHRTY3JpcHRzKCl7cmV0dXJuIGdldFByZU5leHRTY3JpcHRzKHRoaXMuY29udGV4dCx0aGlzLnByb3BzKTt9Z2V0U2NyaXB0cyhmaWxlcyl7cmV0dXJuIGdldFNjcmlwdHModGhpcy5jb250ZXh0LHRoaXMucHJvcHMsZmlsZXMpO31nZXRQb2x5ZmlsbFNjcmlwdHMoKXtyZXR1cm4gZ2V0UG9seWZpbGxTY3JpcHRzKHRoaXMuY29udGV4dCx0aGlzLnByb3BzKTt9aGFuZGxlRG9jdW1lbnRTY3JpcHRMb2FkZXJJdGVtcyhjaGlsZHJlbil7Y29uc3R7c2NyaXB0TG9hZGVyfT10aGlzLmNvbnRleHQ7Y29uc3Qgc2NyaXB0TG9hZGVySXRlbXM9W107Y29uc3QgZmlsdGVyZWRDaGlsZHJlbj1bXTtfcmVhY3QuZGVmYXVsdC5DaGlsZHJlbi5mb3JFYWNoKGNoaWxkcmVuLGNoaWxkPT57aWYoY2hpbGQudHlwZT09PV9zY3JpcHQuZGVmYXVsdCl7aWYoY2hpbGQucHJvcHMuc3RyYXRlZ3k9PT0nYmVmb3JlSW50ZXJhY3RpdmUnKXtzY3JpcHRMb2FkZXIuYmVmb3JlSW50ZXJhY3RpdmU9KHNjcmlwdExvYWRlci5iZWZvcmVJbnRlcmFjdGl2ZXx8W10pLmNvbmNhdChbey4uLmNoaWxkLnByb3BzfV0pO3JldHVybjt9ZWxzZSBpZihbJ2xhenlPbmxvYWQnLCdhZnRlckludGVyYWN0aXZlJ10uaW5jbHVkZXMoY2hpbGQucHJvcHMuc3RyYXRlZ3kpKXtzY3JpcHRMb2FkZXJJdGVtcy5wdXNoKGNoaWxkLnByb3BzKTtyZXR1cm47fX1maWx0ZXJlZENoaWxkcmVuLnB1c2goY2hpbGQpO30pO3RoaXMuY29udGV4dC5fX05FWFRfREFUQV9fLnNjcmlwdExvYWRlcj1zY3JpcHRMb2FkZXJJdGVtcztyZXR1cm4gZmlsdGVyZWRDaGlsZHJlbjt9bWFrZVN0eWxlc2hlZXRJbmVydChub2RlKXtyZXR1cm4gX3JlYWN0LmRlZmF1bHQuQ2hpbGRyZW4ubWFwKG5vZGUsYz0+e2lmKGMudHlwZT09PSdsaW5rJyYmYy5wcm9wc1snaHJlZiddJiZfY29uc3RhbnRzLk9QVElNSVpFRF9GT05UX1BST1ZJREVSUy5zb21lKCh7dXJsfSk9PmMucHJvcHNbJ2hyZWYnXS5zdGFydHNXaXRoKHVybCkpKXtjb25zdCBuZXdQcm9wcz17Li4uKGMucHJvcHN8fHt9KX07bmV3UHJvcHNbJ2RhdGEtaHJlZiddPW5ld1Byb3BzWydocmVmJ107bmV3UHJvcHNbJ2hyZWYnXT11bmRlZmluZWQ7cmV0dXJuLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNsb25lRWxlbWVudChjLG5ld1Byb3BzKTt9ZWxzZSBpZihjLnByb3BzJiZjLnByb3BzWydjaGlsZHJlbiddKXtjLnByb3BzWydjaGlsZHJlbiddPXRoaXMubWFrZVN0eWxlc2hlZXRJbmVydChjLnByb3BzWydjaGlsZHJlbiddKTt9cmV0dXJuIGM7fSk7fXJlbmRlcigpe3ZhciBfdGhpcyRwcm9wcyRub25jZSxfdGhpcyRwcm9wcyRub25jZTI7Y29uc3R7c3R5bGVzLGFtcFBhdGgsaW5BbXBNb2RlLGh5YnJpZEFtcCxjYW5vbmljYWxCYXNlLF9fTkVYVF9EQVRBX18sZGFuZ2Vyb3VzQXNQYXRoLGhlYWRUYWdzLHVuc3RhYmxlX3J1bnRpbWVKUyx1bnN0YWJsZV9Kc1ByZWxvYWQsZGlzYWJsZU9wdGltaXplZExvYWRpbmd9PXRoaXMuY29udGV4dDtjb25zdCBkaXNhYmxlUnVudGltZUpTPXVuc3RhYmxlX3J1bnRpbWVKUz09PWZhbHNlO2NvbnN0IGRpc2FibGVKc1ByZWxvYWQ9dW5zdGFibGVfSnNQcmVsb2FkPT09ZmFsc2V8fCFkaXNhYmxlT3B0aW1pemVkTG9hZGluZzt0aGlzLmNvbnRleHQuZG9jQ29tcG9uZW50c1JlbmRlcmVkLkhlYWQ9dHJ1ZTtsZXR7aGVhZH09dGhpcy5jb250ZXh0O2xldCBjc3NQcmVsb2Fkcz1bXTtsZXQgb3RoZXJIZWFkRWxlbWVudHM9W107aWYoaGVhZCl7aGVhZC5mb3JFYWNoKGM9PntpZihjJiZjLnR5cGU9PT0nbGluaycmJmMucHJvcHNbJ3JlbCddPT09J3ByZWxvYWQnJiZjLnByb3BzWydhcyddPT09J3N0eWxlJyl7Y3NzUHJlbG9hZHMucHVzaChjKTt9ZWxzZXtjJiZvdGhlckhlYWRFbGVtZW50cy5wdXNoKGMpO319KTtoZWFkPWNzc1ByZWxvYWRzLmNvbmNhdChvdGhlckhlYWRFbGVtZW50cyk7fWxldCBjaGlsZHJlbj1fcmVhY3QuZGVmYXVsdC5DaGlsZHJlbi50b0FycmF5KHRoaXMucHJvcHMuY2hpbGRyZW4pLmZpbHRlcihCb29sZWFuKTsvLyBzaG93IGEgd2FybmluZyBpZiBIZWFkIGNvbnRhaW5zIDx0aXRsZT4gKG9ubHkgaW4gZGV2ZWxvcG1lbnQpXG5pZihwcm9jZXNzLmVudi5OT0RFX0VOViE9PSdwcm9kdWN0aW9uJyl7Y2hpbGRyZW49X3JlYWN0LmRlZmF1bHQuQ2hpbGRyZW4ubWFwKGNoaWxkcmVuLGNoaWxkPT57dmFyIF9jaGlsZCRwcm9wcztjb25zdCBpc1JlYWN0SGVsbWV0PWNoaWxkPT1udWxsP3ZvaWQgMDooX2NoaWxkJHByb3BzPWNoaWxkLnByb3BzKT09bnVsbD92b2lkIDA6X2NoaWxkJHByb3BzWydkYXRhLXJlYWN0LWhlbG1ldCddO2lmKCFpc1JlYWN0SGVsbWV0KXt2YXIgX2NoaWxkJHByb3BzMjtpZigoY2hpbGQ9PW51bGw/dm9pZCAwOmNoaWxkLnR5cGUpPT09J3RpdGxlJyl7Y29uc29sZS53YXJuKFwiV2FybmluZzogPHRpdGxlPiBzaG91bGQgbm90IGJlIHVzZWQgaW4gX2RvY3VtZW50LmpzJ3MgPEhlYWQ+LiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9uby1kb2N1bWVudC10aXRsZVwiKTt9ZWxzZSBpZigoY2hpbGQ9PW51bGw/dm9pZCAwOmNoaWxkLnR5cGUpPT09J21ldGEnJiYoY2hpbGQ9PW51bGw/dm9pZCAwOihfY2hpbGQkcHJvcHMyPWNoaWxkLnByb3BzKT09bnVsbD92b2lkIDA6X2NoaWxkJHByb3BzMi5uYW1lKT09PSd2aWV3cG9ydCcpe2NvbnNvbGUud2FybihcIldhcm5pbmc6IHZpZXdwb3J0IG1ldGEgdGFncyBzaG91bGQgbm90IGJlIHVzZWQgaW4gX2RvY3VtZW50LmpzJ3MgPEhlYWQ+LiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9uby1kb2N1bWVudC12aWV3cG9ydC1tZXRhXCIpO319cmV0dXJuIGNoaWxkO30pO2lmKHRoaXMucHJvcHMuY3Jvc3NPcmlnaW4pY29uc29sZS53YXJuKCdXYXJuaW5nOiBgSGVhZGAgYXR0cmlidXRlIGBjcm9zc09yaWdpbmAgaXMgZGVwcmVjYXRlZC4gaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvZG9jLWNyb3Nzb3JpZ2luLWRlcHJlY2F0ZWQnKTt9aWYocHJvY2Vzcy5lbnYuTk9ERV9FTlYhPT0nZGV2ZWxvcG1lbnQnJiZwcm9jZXNzLmVudi5fX05FWFRfT1BUSU1JWkVfRk9OVFMmJiFpbkFtcE1vZGUpe2NoaWxkcmVuPXRoaXMubWFrZVN0eWxlc2hlZXRJbmVydChjaGlsZHJlbik7fWNoaWxkcmVuPXRoaXMuaGFuZGxlRG9jdW1lbnRTY3JpcHRMb2FkZXJJdGVtcyhjaGlsZHJlbik7bGV0IGhhc0FtcGh0bWxSZWw9ZmFsc2U7bGV0IGhhc0Nhbm9uaWNhbFJlbD1mYWxzZTsvLyBzaG93IHdhcm5pbmcgYW5kIHJlbW92ZSBjb25mbGljdGluZyBhbXAgaGVhZCB0YWdzXG5oZWFkPV9yZWFjdC5kZWZhdWx0LkNoaWxkcmVuLm1hcChoZWFkfHxbXSxjaGlsZD0+e2lmKCFjaGlsZClyZXR1cm4gY2hpbGQ7Y29uc3R7dHlwZSxwcm9wc309Y2hpbGQ7aWYoaW5BbXBNb2RlKXtsZXQgYmFkUHJvcD0nJztpZih0eXBlPT09J21ldGEnJiZwcm9wcy5uYW1lPT09J3ZpZXdwb3J0Jyl7YmFkUHJvcD0nbmFtZT1cInZpZXdwb3J0XCInO31lbHNlIGlmKHR5cGU9PT0nbGluaycmJnByb3BzLnJlbD09PSdjYW5vbmljYWwnKXtoYXNDYW5vbmljYWxSZWw9dHJ1ZTt9ZWxzZSBpZih0eXBlPT09J3NjcmlwdCcpey8vIG9ubHkgYmxvY2sgaWZcbi8vIDEuIGl0IGhhcyBhIHNyYyBhbmQgaXNuJ3QgcG9pbnRpbmcgdG8gYW1wcHJvamVjdCdzIENETlxuLy8gMi4gaXQgaXMgdXNpbmcgZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUwgd2l0aG91dCBhIHR5cGUgb3Jcbi8vIGEgdHlwZSBvZiB0ZXh0L2phdmFzY3JpcHRcbmlmKHByb3BzLnNyYyYmcHJvcHMuc3JjLmluZGV4T2YoJ2FtcHByb2plY3QnKTwtMXx8cHJvcHMuZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUwmJighcHJvcHMudHlwZXx8cHJvcHMudHlwZT09PSd0ZXh0L2phdmFzY3JpcHQnKSl7YmFkUHJvcD0nPHNjcmlwdCc7T2JqZWN0LmtleXMocHJvcHMpLmZvckVhY2gocHJvcD0+e2JhZFByb3ArPWAgJHtwcm9wfT1cIiR7cHJvcHNbcHJvcF19XCJgO30pO2JhZFByb3ArPScvPic7fX1pZihiYWRQcm9wKXtjb25zb2xlLndhcm4oYEZvdW5kIGNvbmZsaWN0aW5nIGFtcCB0YWcgXCIke2NoaWxkLnR5cGV9XCIgd2l0aCBjb25mbGljdGluZyBwcm9wICR7YmFkUHJvcH0gaW4gJHtfX05FWFRfREFUQV9fLnBhZ2V9LiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9jb25mbGljdGluZy1hbXAtdGFnYCk7cmV0dXJuIG51bGw7fX1lbHNley8vIG5vbi1hbXAgbW9kZVxuaWYodHlwZT09PSdsaW5rJyYmcHJvcHMucmVsPT09J2FtcGh0bWwnKXtoYXNBbXBodG1sUmVsPXRydWU7fX1yZXR1cm4gY2hpbGQ7fSk7Ly8gdHJ5IHRvIHBhcnNlIHN0eWxlcyBmcm9tIGZyYWdtZW50IGZvciBiYWNrd2FyZHMgY29tcGF0XG5jb25zdCBjdXJTdHlsZXM9QXJyYXkuaXNBcnJheShzdHlsZXMpP3N0eWxlczpbXTtpZihpbkFtcE1vZGUmJnN0eWxlcyYmLy8gQHRzLWlnbm9yZSBQcm9wZXJ0eSAncHJvcHMnIGRvZXMgbm90IGV4aXN0IG9uIHR5cGUgUmVhY3RFbGVtZW50XG5zdHlsZXMucHJvcHMmJi8vIEB0cy1pZ25vcmUgUHJvcGVydHkgJ3Byb3BzJyBkb2VzIG5vdCBleGlzdCBvbiB0eXBlIFJlYWN0RWxlbWVudFxuQXJyYXkuaXNBcnJheShzdHlsZXMucHJvcHMuY2hpbGRyZW4pKXtjb25zdCBoYXNTdHlsZXM9ZWw9Pnt2YXIgX2VsJHByb3BzLF9lbCRwcm9wcyRkYW5nZXJvdXNseTtyZXR1cm4gZWw9PW51bGw/dm9pZCAwOihfZWwkcHJvcHM9ZWwucHJvcHMpPT1udWxsP3ZvaWQgMDooX2VsJHByb3BzJGRhbmdlcm91c2x5PV9lbCRwcm9wcy5kYW5nZXJvdXNseVNldElubmVySFRNTCk9PW51bGw/dm9pZCAwOl9lbCRwcm9wcyRkYW5nZXJvdXNseS5fX2h0bWw7fTsvLyBAdHMtaWdub3JlIFByb3BlcnR5ICdwcm9wcycgZG9lcyBub3QgZXhpc3Qgb24gdHlwZSBSZWFjdEVsZW1lbnRcbnN0eWxlcy5wcm9wcy5jaGlsZHJlbi5mb3JFYWNoKGNoaWxkPT57aWYoQXJyYXkuaXNBcnJheShjaGlsZCkpe2NoaWxkLmZvckVhY2goZWw9Pmhhc1N0eWxlcyhlbCkmJmN1clN0eWxlcy5wdXNoKGVsKSk7fWVsc2UgaWYoaGFzU3R5bGVzKGNoaWxkKSl7Y3VyU3R5bGVzLnB1c2goY2hpbGQpO319KTt9Y29uc3QgZmlsZXM9Z2V0RG9jdW1lbnRGaWxlcyh0aGlzLmNvbnRleHQuYnVpbGRNYW5pZmVzdCx0aGlzLmNvbnRleHQuX19ORVhUX0RBVEFfXy5wYWdlLGluQW1wTW9kZSk7cmV0dXJuLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJoZWFkXCIsdGhpcy5wcm9wcyx0aGlzLmNvbnRleHQuaXNEZXZlbG9wbWVudCYmLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoX3JlYWN0LmRlZmF1bHQuRnJhZ21lbnQsbnVsbCwvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcInN0eWxlXCIse1wiZGF0YS1uZXh0LWhpZGUtZm91Y1wiOnRydWUsXCJkYXRhLWFtcGRldm1vZGVcIjppbkFtcE1vZGU/J3RydWUnOnVuZGVmaW5lZCxkYW5nZXJvdXNseVNldElubmVySFRNTDp7X19odG1sOmBib2R5e2Rpc3BsYXk6bm9uZX1gfX0pLC8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwibm9zY3JpcHRcIix7XCJkYXRhLW5leHQtaGlkZS1mb3VjXCI6dHJ1ZSxcImRhdGEtYW1wZGV2bW9kZVwiOmluQW1wTW9kZT8ndHJ1ZSc6dW5kZWZpbmVkfSwvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcInN0eWxlXCIse2Rhbmdlcm91c2x5U2V0SW5uZXJIVE1MOntfX2h0bWw6YGJvZHl7ZGlzcGxheTpibG9ja31gfX0pKSksY2hpbGRyZW4scHJvY2Vzcy5lbnYuX19ORVhUX09QVElNSVpFX0ZPTlRTJiYvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcIm1ldGFcIix7bmFtZTpcIm5leHQtZm9udC1wcmVjb25uZWN0XCJ9KSxoZWFkLC8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwibWV0YVwiLHtuYW1lOlwibmV4dC1oZWFkLWNvdW50XCIsY29udGVudDpfcmVhY3QuZGVmYXVsdC5DaGlsZHJlbi5jb3VudChoZWFkfHxbXSkudG9TdHJpbmcoKX0pLGluQW1wTW9kZSYmLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoX3JlYWN0LmRlZmF1bHQuRnJhZ21lbnQsbnVsbCwvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcIm1ldGFcIix7bmFtZTpcInZpZXdwb3J0XCIsY29udGVudDpcIndpZHRoPWRldmljZS13aWR0aCxtaW5pbXVtLXNjYWxlPTEsaW5pdGlhbC1zY2FsZT0xXCJ9KSwhaGFzQ2Fub25pY2FsUmVsJiYvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImxpbmtcIix7cmVsOlwiY2Fub25pY2FsXCIsaHJlZjpjYW5vbmljYWxCYXNlKygwLF91dGlsczIuY2xlYW5BbXBQYXRoKShkYW5nZXJvdXNBc1BhdGgpfSksLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJsaW5rXCIse3JlbDpcInByZWxvYWRcIixhczpcInNjcmlwdFwiLGhyZWY6XCJodHRwczovL2Nkbi5hbXBwcm9qZWN0Lm9yZy92MC5qc1wifSksc3R5bGVzJiYvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcInN0eWxlXCIse1wiYW1wLWN1c3RvbVwiOlwiXCIsZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw6e19faHRtbDpjdXJTdHlsZXMubWFwKHN0eWxlPT5zdHlsZS5wcm9wcy5kYW5nZXJvdXNseVNldElubmVySFRNTC5fX2h0bWwpLmpvaW4oJycpLnJlcGxhY2UoL1xcL1xcKiMgc291cmNlTWFwcGluZ1VSTD0uKlxcKlxcLy9nLCcnKS5yZXBsYWNlKC9cXC9cXCpAIHNvdXJjZVVSTD0uKj9cXCpcXC8vZywnJyl9fSksLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJzdHlsZVwiLHtcImFtcC1ib2lsZXJwbGF0ZVwiOlwiXCIsZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw6e19faHRtbDpgYm9keXstd2Via2l0LWFuaW1hdGlvbjotYW1wLXN0YXJ0IDhzIHN0ZXBzKDEsZW5kKSAwcyAxIG5vcm1hbCBib3RoOy1tb3otYW5pbWF0aW9uOi1hbXAtc3RhcnQgOHMgc3RlcHMoMSxlbmQpIDBzIDEgbm9ybWFsIGJvdGg7LW1zLWFuaW1hdGlvbjotYW1wLXN0YXJ0IDhzIHN0ZXBzKDEsZW5kKSAwcyAxIG5vcm1hbCBib3RoO2FuaW1hdGlvbjotYW1wLXN0YXJ0IDhzIHN0ZXBzKDEsZW5kKSAwcyAxIG5vcm1hbCBib3RofUAtd2Via2l0LWtleWZyYW1lcyAtYW1wLXN0YXJ0e2Zyb217dmlzaWJpbGl0eTpoaWRkZW59dG97dmlzaWJpbGl0eTp2aXNpYmxlfX1ALW1vei1rZXlmcmFtZXMgLWFtcC1zdGFydHtmcm9te3Zpc2liaWxpdHk6aGlkZGVufXRve3Zpc2liaWxpdHk6dmlzaWJsZX19QC1tcy1rZXlmcmFtZXMgLWFtcC1zdGFydHtmcm9te3Zpc2liaWxpdHk6aGlkZGVufXRve3Zpc2liaWxpdHk6dmlzaWJsZX19QC1vLWtleWZyYW1lcyAtYW1wLXN0YXJ0e2Zyb217dmlzaWJpbGl0eTpoaWRkZW59dG97dmlzaWJpbGl0eTp2aXNpYmxlfX1Aa2V5ZnJhbWVzIC1hbXAtc3RhcnR7ZnJvbXt2aXNpYmlsaXR5OmhpZGRlbn10b3t2aXNpYmlsaXR5OnZpc2libGV9fWB9fSksLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJub3NjcmlwdFwiLG51bGwsLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJzdHlsZVwiLHtcImFtcC1ib2lsZXJwbGF0ZVwiOlwiXCIsZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw6e19faHRtbDpgYm9keXstd2Via2l0LWFuaW1hdGlvbjpub25lOy1tb3otYW5pbWF0aW9uOm5vbmU7LW1zLWFuaW1hdGlvbjpub25lO2FuaW1hdGlvbjpub25lfWB9fSkpLC8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIse2FzeW5jOnRydWUsc3JjOlwiaHR0cHM6Ly9jZG4uYW1wcHJvamVjdC5vcmcvdjAuanNcIn0pKSwhaW5BbXBNb2RlJiYvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChfcmVhY3QuZGVmYXVsdC5GcmFnbWVudCxudWxsLCFoYXNBbXBodG1sUmVsJiZoeWJyaWRBbXAmJi8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwibGlua1wiLHtyZWw6XCJhbXBodG1sXCIsaHJlZjpjYW5vbmljYWxCYXNlK2dldEFtcFBhdGgoYW1wUGF0aCxkYW5nZXJvdXNBc1BhdGgpfSksIXByb2Nlc3MuZW52Ll9fTkVYVF9PUFRJTUlaRV9DU1MmJnRoaXMuZ2V0Q3NzTGlua3MoZmlsZXMpLCFwcm9jZXNzLmVudi5fX05FWFRfT1BUSU1JWkVfQ1NTJiYvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcIm5vc2NyaXB0XCIse1wiZGF0YS1uLWNzc1wiOihfdGhpcyRwcm9wcyRub25jZT10aGlzLnByb3BzLm5vbmNlKSE9bnVsbD9fdGhpcyRwcm9wcyRub25jZTonJ30pLHByb2Nlc3MuZW52Ll9fTkVYVF9PUFRJTUlaRV9JTUFHRVMmJi8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwibWV0YVwiLHtuYW1lOlwibmV4dC1pbWFnZS1wcmVsb2FkXCJ9KSwhZGlzYWJsZVJ1bnRpbWVKUyYmIWRpc2FibGVKc1ByZWxvYWQmJnRoaXMuZ2V0UHJlbG9hZER5bmFtaWNDaHVua3MoKSwhZGlzYWJsZVJ1bnRpbWVKUyYmIWRpc2FibGVKc1ByZWxvYWQmJnRoaXMuZ2V0UHJlbG9hZE1haW5MaW5rcyhmaWxlcyksIWRpc2FibGVPcHRpbWl6ZWRMb2FkaW5nJiYhZGlzYWJsZVJ1bnRpbWVKUyYmdGhpcy5nZXRQb2x5ZmlsbFNjcmlwdHMoKSwhZGlzYWJsZU9wdGltaXplZExvYWRpbmcmJiFkaXNhYmxlUnVudGltZUpTJiZ0aGlzLmdldFByZU5leHRTY3JpcHRzKCksIWRpc2FibGVPcHRpbWl6ZWRMb2FkaW5nJiYhZGlzYWJsZVJ1bnRpbWVKUyYmdGhpcy5nZXREeW5hbWljQ2h1bmtzKGZpbGVzKSwhZGlzYWJsZU9wdGltaXplZExvYWRpbmcmJiFkaXNhYmxlUnVudGltZUpTJiZ0aGlzLmdldFNjcmlwdHMoZmlsZXMpLHByb2Nlc3MuZW52Ll9fTkVYVF9PUFRJTUlaRV9DU1MmJnRoaXMuZ2V0Q3NzTGlua3MoZmlsZXMpLHByb2Nlc3MuZW52Ll9fTkVYVF9PUFRJTUlaRV9DU1MmJi8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwibm9zY3JpcHRcIix7XCJkYXRhLW4tY3NzXCI6KF90aGlzJHByb3BzJG5vbmNlMj10aGlzLnByb3BzLm5vbmNlKSE9bnVsbD9fdGhpcyRwcm9wcyRub25jZTI6Jyd9KSx0aGlzLmNvbnRleHQuaXNEZXZlbG9wbWVudCYmLyojX19QVVJFX18qLyAvLyB0aGlzIGVsZW1lbnQgaXMgdXNlZCB0byBtb3VudCBkZXZlbG9wbWVudCBzdHlsZXMgc28gdGhlXG4vLyBvcmRlcmluZyBtYXRjaGVzIHByb2R1Y3Rpb25cbi8vIChieSBkZWZhdWx0LCBzdHlsZS1sb2FkZXIgaW5qZWN0cyBhdCB0aGUgYm90dG9tIG9mIDxoZWFkIC8+KVxuX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcIm5vc2NyaXB0XCIse2lkOlwiX19uZXh0X2Nzc19fRE9fTk9UX1VTRV9fXCJ9KSxzdHlsZXN8fG51bGwpLC8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KF9yZWFjdC5kZWZhdWx0LkZyYWdtZW50LHt9LC4uLihoZWFkVGFnc3x8W10pKSk7fX1leHBvcnRzLkhlYWQ9SGVhZDtIZWFkLmNvbnRleHRUeXBlPV9kb2N1bWVudENvbnRleHQuRG9jdW1lbnRDb250ZXh0O0hlYWQucHJvcFR5cGVzPXtub25jZTpfcHJvcFR5cGVzLmRlZmF1bHQuc3RyaW5nLGNyb3NzT3JpZ2luOl9wcm9wVHlwZXMuZGVmYXVsdC5zdHJpbmd9O2Z1bmN0aW9uIE1haW4oKXtjb25zdHtpbkFtcE1vZGUsaHRtbCxkb2NDb21wb25lbnRzUmVuZGVyZWR9PSgwLF9yZWFjdC51c2VDb250ZXh0KShfZG9jdW1lbnRDb250ZXh0LkRvY3VtZW50Q29udGV4dCk7ZG9jQ29tcG9uZW50c1JlbmRlcmVkLk1haW49dHJ1ZTtpZihpbkFtcE1vZGUpcmV0dXJuLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoX3JlYWN0LmRlZmF1bHQuRnJhZ21lbnQsbnVsbCxfY29uc3RhbnRzLkFNUF9SRU5ERVJfVEFSR0VUKTtyZXR1cm4vKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImRpdlwiLHtpZDpcIl9fbmV4dFwiLGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MOntfX2h0bWw6aHRtbH19KTt9Y2xhc3MgTmV4dFNjcmlwdCBleHRlbmRzIF9yZWFjdC5Db21wb25lbnR7Y29uc3RydWN0b3IoLi4uYXJncyl7c3VwZXIoLi4uYXJncyk7dGhpcy5jb250ZXh0PXZvaWQgMDt9Z2V0RHluYW1pY0NodW5rcyhmaWxlcyl7cmV0dXJuIGdldER5bmFtaWNDaHVua3ModGhpcy5jb250ZXh0LHRoaXMucHJvcHMsZmlsZXMpO31nZXRQcmVOZXh0U2NyaXB0cygpe3JldHVybiBnZXRQcmVOZXh0U2NyaXB0cyh0aGlzLmNvbnRleHQsdGhpcy5wcm9wcyk7fWdldFNjcmlwdHMoZmlsZXMpe3JldHVybiBnZXRTY3JpcHRzKHRoaXMuY29udGV4dCx0aGlzLnByb3BzLGZpbGVzKTt9Z2V0UG9seWZpbGxTY3JpcHRzKCl7cmV0dXJuIGdldFBvbHlmaWxsU2NyaXB0cyh0aGlzLmNvbnRleHQsdGhpcy5wcm9wcyk7fXN0YXRpYyBnZXRJbmxpbmVTY3JpcHRTb3VyY2UoZG9jdW1lbnRQcm9wcyl7Y29uc3R7X19ORVhUX0RBVEFfX309ZG9jdW1lbnRQcm9wczt0cnl7Y29uc3QgZGF0YT1KU09OLnN0cmluZ2lmeShfX05FWFRfREFUQV9fKTtyZXR1cm4oMCxfaHRtbGVzY2FwZS5odG1sRXNjYXBlSnNvblN0cmluZykoZGF0YSk7fWNhdGNoKGVycil7aWYoZXJyLm1lc3NhZ2UuaW5kZXhPZignY2lyY3VsYXIgc3RydWN0dXJlJykpe3Rocm93IG5ldyBFcnJvcihgQ2lyY3VsYXIgc3RydWN0dXJlIGluIFwiZ2V0SW5pdGlhbFByb3BzXCIgcmVzdWx0IG9mIHBhZ2UgXCIke19fTkVYVF9EQVRBX18ucGFnZX1cIi4gaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvY2lyY3VsYXItc3RydWN0dXJlYCk7fXRocm93IGVycjt9fXJlbmRlcigpe2NvbnN0e2Fzc2V0UHJlZml4LGluQW1wTW9kZSxidWlsZE1hbmlmZXN0LHVuc3RhYmxlX3J1bnRpbWVKUyxkb2NDb21wb25lbnRzUmVuZGVyZWQsZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmcsZGlzYWJsZU9wdGltaXplZExvYWRpbmd9PXRoaXMuY29udGV4dDtjb25zdCBkaXNhYmxlUnVudGltZUpTPXVuc3RhYmxlX3J1bnRpbWVKUz09PWZhbHNlO2RvY0NvbXBvbmVudHNSZW5kZXJlZC5OZXh0U2NyaXB0PXRydWU7aWYoaW5BbXBNb2RlKXtpZihwcm9jZXNzLmVudi5OT0RFX0VOVj09PSdwcm9kdWN0aW9uJyl7cmV0dXJuIG51bGw7fWNvbnN0IGFtcERldkZpbGVzPVsuLi5idWlsZE1hbmlmZXN0LmRldkZpbGVzLC4uLmJ1aWxkTWFuaWZlc3QucG9seWZpbGxGaWxlcywuLi5idWlsZE1hbmlmZXN0LmFtcERldkZpbGVzXTtyZXR1cm4vKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChfcmVhY3QuZGVmYXVsdC5GcmFnbWVudCxudWxsLGRpc2FibGVSdW50aW1lSlM/bnVsbDovKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiLHtpZDpcIl9fTkVYVF9EQVRBX19cIix0eXBlOlwiYXBwbGljYXRpb24vanNvblwiLG5vbmNlOnRoaXMucHJvcHMubm9uY2UsY3Jvc3NPcmlnaW46dGhpcy5wcm9wcy5jcm9zc09yaWdpbnx8cHJvY2Vzcy5lbnYuX19ORVhUX0NST1NTX09SSUdJTixkYW5nZXJvdXNseVNldElubmVySFRNTDp7X19odG1sOk5leHRTY3JpcHQuZ2V0SW5saW5lU2NyaXB0U291cmNlKHRoaXMuY29udGV4dCl9LFwiZGF0YS1hbXBkZXZtb2RlXCI6dHJ1ZX0pLGFtcERldkZpbGVzLm1hcChmaWxlPT4vKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiLHtrZXk6ZmlsZSxzcmM6YCR7YXNzZXRQcmVmaXh9L19uZXh0LyR7ZmlsZX0ke2Rldk9ubHlDYWNoZUJ1c3RlclF1ZXJ5U3RyaW5nfWAsbm9uY2U6dGhpcy5wcm9wcy5ub25jZSxjcm9zc09yaWdpbjp0aGlzLnByb3BzLmNyb3NzT3JpZ2lufHxwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOLFwiZGF0YS1hbXBkZXZtb2RlXCI6dHJ1ZX0pKSk7fWlmKHByb2Nlc3MuZW52Lk5PREVfRU5WIT09J3Byb2R1Y3Rpb24nKXtpZih0aGlzLnByb3BzLmNyb3NzT3JpZ2luKWNvbnNvbGUud2FybignV2FybmluZzogYE5leHRTY3JpcHRgIGF0dHJpYnV0ZSBgY3Jvc3NPcmlnaW5gIGlzIGRlcHJlY2F0ZWQuIGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL2RvYy1jcm9zc29yaWdpbi1kZXByZWNhdGVkJyk7fWNvbnN0IGZpbGVzPWdldERvY3VtZW50RmlsZXModGhpcy5jb250ZXh0LmJ1aWxkTWFuaWZlc3QsdGhpcy5jb250ZXh0Ll9fTkVYVF9EQVRBX18ucGFnZSxpbkFtcE1vZGUpO3JldHVybi8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KF9yZWFjdC5kZWZhdWx0LkZyYWdtZW50LG51bGwsIWRpc2FibGVSdW50aW1lSlMmJmJ1aWxkTWFuaWZlc3QuZGV2RmlsZXM/YnVpbGRNYW5pZmVzdC5kZXZGaWxlcy5tYXAoZmlsZT0+LyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJzY3JpcHRcIix7a2V5OmZpbGUsc3JjOmAke2Fzc2V0UHJlZml4fS9fbmV4dC8ke2VuY29kZVVSSShmaWxlKX0ke2Rldk9ubHlDYWNoZUJ1c3RlclF1ZXJ5U3RyaW5nfWAsbm9uY2U6dGhpcy5wcm9wcy5ub25jZSxjcm9zc09yaWdpbjp0aGlzLnByb3BzLmNyb3NzT3JpZ2lufHxwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOfSkpOm51bGwsZGlzYWJsZVJ1bnRpbWVKUz9udWxsOi8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIse2lkOlwiX19ORVhUX0RBVEFfX1wiLHR5cGU6XCJhcHBsaWNhdGlvbi9qc29uXCIsbm9uY2U6dGhpcy5wcm9wcy5ub25jZSxjcm9zc09yaWdpbjp0aGlzLnByb3BzLmNyb3NzT3JpZ2lufHxwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOLGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MOntfX2h0bWw6TmV4dFNjcmlwdC5nZXRJbmxpbmVTY3JpcHRTb3VyY2UodGhpcy5jb250ZXh0KX19KSxkaXNhYmxlT3B0aW1pemVkTG9hZGluZyYmIWRpc2FibGVSdW50aW1lSlMmJnRoaXMuZ2V0UG9seWZpbGxTY3JpcHRzKCksZGlzYWJsZU9wdGltaXplZExvYWRpbmcmJiFkaXNhYmxlUnVudGltZUpTJiZ0aGlzLmdldFByZU5leHRTY3JpcHRzKCksZGlzYWJsZU9wdGltaXplZExvYWRpbmcmJiFkaXNhYmxlUnVudGltZUpTJiZ0aGlzLmdldER5bmFtaWNDaHVua3MoZmlsZXMpLGRpc2FibGVPcHRpbWl6ZWRMb2FkaW5nJiYhZGlzYWJsZVJ1bnRpbWVKUyYmdGhpcy5nZXRTY3JpcHRzKGZpbGVzKSk7fX1leHBvcnRzLk5leHRTY3JpcHQ9TmV4dFNjcmlwdDtOZXh0U2NyaXB0LmNvbnRleHRUeXBlPV9kb2N1bWVudENvbnRleHQuRG9jdW1lbnRDb250ZXh0O05leHRTY3JpcHQucHJvcFR5cGVzPXtub25jZTpfcHJvcFR5cGVzLmRlZmF1bHQuc3RyaW5nLGNyb3NzT3JpZ2luOl9wcm9wVHlwZXMuZGVmYXVsdC5zdHJpbmd9O05leHRTY3JpcHQuc2FmYXJpTm9tb2R1bGVGaXg9JyFmdW5jdGlvbigpe3ZhciBlPWRvY3VtZW50LHQ9ZS5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIpO2lmKCEoXCJub01vZHVsZVwiaW4gdCkmJlwib25iZWZvcmVsb2FkXCJpbiB0KXt2YXIgbj0hMTtlLmFkZEV2ZW50TGlzdGVuZXIoXCJiZWZvcmVsb2FkXCIsZnVuY3Rpb24oZSl7aWYoZS50YXJnZXQ9PT10KW49ITA7ZWxzZSBpZighZS50YXJnZXQuaGFzQXR0cmlidXRlKFwibm9tb2R1bGVcIil8fCFuKXJldHVybjtlLnByZXZlbnREZWZhdWx0KCl9LCEwKSx0LnR5cGU9XCJtb2R1bGVcIix0LnNyYz1cIi5cIixlLmhlYWQuYXBwZW5kQ2hpbGQodCksdC5yZW1vdmUoKX19KCk7JztmdW5jdGlvbiBnZXRBbXBQYXRoKGFtcFBhdGgsYXNQYXRoKXtyZXR1cm4gYW1wUGF0aHx8YCR7YXNQYXRofSR7YXNQYXRoLmluY2x1ZGVzKCc/Jyk/JyYnOic/J31hbXA9MWA7fVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9X2RvY3VtZW50LmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO2V4cG9ydHMuX19lc01vZHVsZT10cnVlO2V4cG9ydHMuaHRtbEVzY2FwZUpzb25TdHJpbmc9aHRtbEVzY2FwZUpzb25TdHJpbmc7Ly8gVGhpcyB1dGlsaXR5IGlzIGJhc2VkIG9uIGh0dHBzOi8vZ2l0aHViLmNvbS96ZXJ0b3NoL2h0bWxlc2NhcGVcbi8vIExpY2Vuc2U6IGh0dHBzOi8vZ2l0aHViLmNvbS96ZXJ0b3NoL2h0bWxlc2NhcGUvYmxvYi8wNTI3Y2E3MTU2YTUyNGQyNTYxMDFiYjMxMGE5Zjk3MGY2MzA3OGFkL0xJQ0VOU0VcbmNvbnN0IEVTQ0FQRV9MT09LVVA9eycmJzonXFxcXHUwMDI2JywnPic6J1xcXFx1MDAzZScsJzwnOidcXFxcdTAwM2MnLCdcXHUyMDI4JzonXFxcXHUyMDI4JywnXFx1MjAyOSc6J1xcXFx1MjAyOSd9O2NvbnN0IEVTQ0FQRV9SRUdFWD0vWyY+PFxcdTIwMjhcXHUyMDI5XS9nO2Z1bmN0aW9uIGh0bWxFc2NhcGVKc29uU3RyaW5nKHN0cil7cmV0dXJuIHN0ci5yZXBsYWNlKEVTQ0FQRV9SRUdFWCxtYXRjaD0+RVNDQVBFX0xPT0tVUFttYXRjaF0pO31cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWh0bWxlc2NhcGUuanMubWFwIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9jb25zdGFudHMuanNcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvZG9jdW1lbnQtY29udGV4dC5qc1wiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9oZWFkLW1hbmFnZXItY29udGV4dC5qc1wiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi91dGlscy5qc1wiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci9nZXQtcGFnZS1maWxlcy5qc1wiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci91dGlscy5qc1wiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicHJvcC10eXBlc1wiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInN0eWxlZC1qc3gvc2VydmVyXCIpOzsiXSwic291cmNlUm9vdCI6IiJ9