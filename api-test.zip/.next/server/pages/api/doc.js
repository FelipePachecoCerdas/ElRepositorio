(function() {
var exports = {};
exports.id = "pages/api/doc";
exports.ids = ["pages/api/doc"];
exports.modules = {

/***/ "./pages/api/doc.js":
/*!**************************!*\
  !*** ./pages/api/doc.js ***!
  \**************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var next_swagger_doc__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-swagger-doc */ "next-swagger-doc");
/* harmony import */ var next_swagger_doc__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_swagger_doc__WEBPACK_IMPORTED_MODULE_0__);

const swaggerHandler = (0,next_swagger_doc__WEBPACK_IMPORTED_MODULE_0__.withSwagger)({
  openApiVersion: '3.0.0',
  title: 'Next Swagger API Example',
  version: '0.1.0',
  apiFolder: 'pages/api'
});
/* harmony default export */ __webpack_exports__["default"] = (swaggerHandler());

/***/ }),

/***/ "next-swagger-doc":
/*!***********************************!*\
  !*** external "next-swagger-doc" ***!
  \***********************************/
/***/ (function(module) {

"use strict";
module.exports = require("next-swagger-doc");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./pages/api/doc.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hcGktdGVzdC8uL3BhZ2VzL2FwaS9kb2MuanMiLCJ3ZWJwYWNrOi8vYXBpLXRlc3QvZXh0ZXJuYWwgXCJuZXh0LXN3YWdnZXItZG9jXCIiXSwibmFtZXMiOlsic3dhZ2dlckhhbmRsZXIiLCJ3aXRoU3dhZ2dlciIsIm9wZW5BcGlWZXJzaW9uIiwidGl0bGUiLCJ2ZXJzaW9uIiwiYXBpRm9sZGVyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFFQSxNQUFNQSxjQUFjLEdBQUdDLDZEQUFXLENBQUM7QUFDakNDLGdCQUFjLEVBQUUsT0FEaUI7QUFFakNDLE9BQUssRUFBRSwwQkFGMEI7QUFHakNDLFNBQU8sRUFBRSxPQUh3QjtBQUlqQ0MsV0FBUyxFQUFFO0FBSnNCLENBQUQsQ0FBbEM7QUFNQSwrREFBZUwsY0FBYyxFQUE3QixFOzs7Ozs7Ozs7OztBQ1JBLDhDIiwiZmlsZSI6InBhZ2VzL2FwaS9kb2MuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB3aXRoU3dhZ2dlciB9IGZyb20gJ25leHQtc3dhZ2dlci1kb2MnO1xyXG5cclxuY29uc3Qgc3dhZ2dlckhhbmRsZXIgPSB3aXRoU3dhZ2dlcih7XHJcbiAgb3BlbkFwaVZlcnNpb246ICczLjAuMCcsXHJcbiAgdGl0bGU6ICdOZXh0IFN3YWdnZXIgQVBJIEV4YW1wbGUnLFxyXG4gIHZlcnNpb246ICcwLjEuMCcsXHJcbiAgYXBpRm9sZGVyOiAncGFnZXMvYXBpJyxcclxufSk7XHJcbmV4cG9ydCBkZWZhdWx0IHN3YWdnZXJIYW5kbGVyKCk7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC1zd2FnZ2VyLWRvY1wiKTs7Il0sInNvdXJjZVJvb3QiOiIifQ==