(function() {
var exports = {};
exports.id = "pages/api/event";
exports.ids = ["pages/api/event"];
exports.modules = {

/***/ "./pages/api/event.js":
/*!****************************!*\
  !*** ./pages/api/event.js ***!
  \****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ handler; }
/* harmony export */ });
/**
 * @swagger
 * /api/event:
 *   get:
 *     tags: 
 *     - event
 *     summary: Gets all events
 *     description: Gets all stored events information
 *     operationId: eventGETAll
 *     consumes:
 *     - application/json
 *     produces:
 *     - application/json
 *     responses:
 *       200:
 *         description: Successful Operation
 *         schema:
 *          type: array
 *          items:
 *             $ref: '#/definitions/Event'
 *       401:
 *         description: Invalid auth token
 *     security:
 *     - auth_token: []
 */
async function handler(req, res) {
  const request = await fetch("https://api.nasa.gov/planetary/apod?api_key=e38iKVLxFahcNt2PcGEHZmc8bzLGbohlCRVVak2k");
  const data = await request.json();
  res.status(200).json(data);
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./pages/api/event.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hcGktdGVzdC8uL3BhZ2VzL2FwaS9ldmVudC5qcyJdLCJuYW1lcyI6WyJoYW5kbGVyIiwicmVxIiwicmVzIiwicmVxdWVzdCIsImZldGNoIiwiZGF0YSIsImpzb24iLCJzdGF0dXMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDZ0IsZUFBZUEsT0FBZixDQUF1QkMsR0FBdkIsRUFBNEJDLEdBQTVCLEVBQWlDO0FBQy9DLFFBQU1DLE9BQU8sR0FBRyxNQUFNQyxLQUFLLENBQUMsc0ZBQUQsQ0FBM0I7QUFDQSxRQUFNQyxJQUFJLEdBQUcsTUFBTUYsT0FBTyxDQUFDRyxJQUFSLEVBQW5CO0FBQ0FKLEtBQUcsQ0FBQ0ssTUFBSixDQUFXLEdBQVgsRUFBZ0JELElBQWhCLENBQXFCRCxJQUFyQjtBQUNELEMiLCJmaWxlIjoicGFnZXMvYXBpL2V2ZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIEBzd2FnZ2VyXHJcbiAqIC9hcGkvZXZlbnQ6XHJcbiAqICAgZ2V0OlxyXG4gKiAgICAgdGFnczogXHJcbiAqICAgICAtIGV2ZW50XHJcbiAqICAgICBzdW1tYXJ5OiBHZXRzIGFsbCBldmVudHNcclxuICogICAgIGRlc2NyaXB0aW9uOiBHZXRzIGFsbCBzdG9yZWQgZXZlbnRzIGluZm9ybWF0aW9uXHJcbiAqICAgICBvcGVyYXRpb25JZDogZXZlbnRHRVRBbGxcclxuICogICAgIGNvbnN1bWVzOlxyXG4gKiAgICAgLSBhcHBsaWNhdGlvbi9qc29uXHJcbiAqICAgICBwcm9kdWNlczpcclxuICogICAgIC0gYXBwbGljYXRpb24vanNvblxyXG4gKiAgICAgcmVzcG9uc2VzOlxyXG4gKiAgICAgICAyMDA6XHJcbiAqICAgICAgICAgZGVzY3JpcHRpb246IFN1Y2Nlc3NmdWwgT3BlcmF0aW9uXHJcbiAqICAgICAgICAgc2NoZW1hOlxyXG4gKiAgICAgICAgICB0eXBlOiBhcnJheVxyXG4gKiAgICAgICAgICBpdGVtczpcclxuICogICAgICAgICAgICAgJHJlZjogJyMvZGVmaW5pdGlvbnMvRXZlbnQnXHJcbiAqICAgICAgIDQwMTpcclxuICogICAgICAgICBkZXNjcmlwdGlvbjogSW52YWxpZCBhdXRoIHRva2VuXHJcbiAqICAgICBzZWN1cml0eTpcclxuICogICAgIC0gYXV0aF90b2tlbjogW11cclxuICovXHJcbiBleHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBoYW5kbGVyKHJlcSwgcmVzKSB7XHJcbiAgY29uc3QgcmVxdWVzdCA9IGF3YWl0IGZldGNoKFwiaHR0cHM6Ly9hcGkubmFzYS5nb3YvcGxhbmV0YXJ5L2Fwb2Q/YXBpX2tleT1lMzhpS1ZMeEZhaGNOdDJQY0dFSFptYzhiekxHYm9obENSVlZhazJrXCIpXHJcbiAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcXVlc3QuanNvbigpXHJcbiAgcmVzLnN0YXR1cygyMDApLmpzb24oZGF0YSlcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9